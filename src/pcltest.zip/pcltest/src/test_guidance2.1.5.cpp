#include <ros/ros.h>

#include <geometry_msgs/PoseStamped.h>
#include <sensor_msgs/PointCloud2.h>
#include <std_msgs/Float64.h>
#include <std_msgs/ColorRGBA.h>
#include <std_msgs/Float64MultiArray.h>
#include <visualization_msgs/Marker.h>

#include <pcl/common/centroid.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>

#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/Geometry>

#include <algorithm>
#include <cfloat>
#include <cmath>
#include <iostream>
#include <limits>
#include <map>
#include <mutex>
#include <string>
#include <vector>

using PointType = pcl::PointXYZ;
using Eigen::Vector3f;

namespace
{
constexpr float kVoxelSize = 0.2f;
constexpr float kFrontDistance = 0.2f;
constexpr float kReplanThresh = 0.5f;
constexpr float kExeFinishDist = 0.2f;
constexpr float kReplanDuration = 5.0f;
constexpr float kSearchRadius = 1.5f;
constexpr float kGoalLength = 2.0f;
}

struct CenterlinePoint
{
    Eigen::Vector3f p_body = Eigen::Vector3f::Zero();
    float confidence = 0.0f;
    bool valid = false;
};

struct TunnelCenterline
{
    std::vector<CenterlinePoint> measured_points;
    std::vector<CenterlinePoint> stable_points;

    float confidence = 0.0f;
    bool valid = false;
};

struct TunnelStructure
{
    bool valid = false;

    Eigen::Vector3f center_body = Eigen::Vector3f::Zero();
    Eigen::Vector3f direction_body = Eigen::Vector3f::UnitX();

    bool left_wall_valid = false;
    bool right_wall_valid = false;
    bool ground_valid = false;
    bool ceiling_valid = false;

    float left_dist = -1.0f;
    float right_dist = -1.0f;
    float width = -1.0f;

    float relative_height = -1.0f;
    float ceiling_relative_height = -1.0f;
    float ground_z_body = 0.0f;
    float ceiling_z_body = 0.0f;
    float center_error = 0.0f;

    float lateral_confidence = 0.0f;
    float height_confidence = 0.0f;
    float direction_confidence = 0.0f;
    float overall_confidence = 0.0f;

    int num_left_points = 0;
    int num_right_points = 0;
    int num_ground_points = 0;
    int num_ceiling_points = 0;

    TunnelCenterline centerline;
    std::vector<CenterlinePoint> left_wall_points_body;
    std::vector<CenterlinePoint> right_wall_points_body;
};

class TunnelStructureEstimator
{
public:
    using PointCloudConstPtr = pcl::PointCloud<PointType>::ConstPtr;

    struct Params
    {
        float wall_min_y = 0.4f;
        int min_wall_points = 80;

        float ground_candidate_ratio = 0.2f;
        int min_ground_points = 60;

        float ceiling_candidate_ratio = 0.2f;
        int min_ceiling_points = 60;

        float centerline_bin_start_x = 0.5f;
        float centerline_bin_end_x = 5.0f;
        float centerline_bin_size_x = 0.5f;
        int min_points_per_side = 20;
        float max_width_change = 0.5f;
        float max_center_jump = 0.4f;
        float direction_smooth_alpha = 0.8f;
    };

    TunnelStructureEstimator()
        : TunnelStructureEstimator(Params{})
    {
    }

    explicit TunnelStructureEstimator(const Params& params)
        : params_(params), last_direction_body_(Eigen::Vector3f::UnitX())
    {
    }

    TunnelStructure estimate(const PointCloudConstPtr& cloud_struct)
    {
        TunnelStructure structure;
        if (!cloud_struct || cloud_struct->empty())
        {
            if (has_last_direction_) structure.direction_body = last_direction_body_;
            return structure;
        }

        std::vector<float> left_abs_y;
        std::vector<float> right_abs_y;
        std::vector<float> all_z;
        left_abs_y.reserve(cloud_struct->size());
        right_abs_y.reserve(cloud_struct->size());
        all_z.reserve(cloud_struct->size());

        Eigen::Vector3f centroid = Eigen::Vector3f::Zero();
        size_t finite_count = 0U;
        for (const auto& p : cloud_struct->points)
        {
            if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) continue;
            centroid += Eigen::Vector3f(p.x, p.y, p.z);
            ++finite_count;
            all_z.push_back(p.z);

            if (p.y > params_.wall_min_y) left_abs_y.push_back(std::fabs(p.y));
            if (p.y < -params_.wall_min_y) right_abs_y.push_back(std::fabs(p.y));
        }

        if (finite_count == 0U)
        {
            if (has_last_direction_) structure.direction_body = last_direction_body_;
            return structure;
        }

        centroid /= static_cast<float>(finite_count);
        structure.center_body = centroid;

        structure.num_left_points = static_cast<int>(left_abs_y.size());
        structure.num_right_points = static_cast<int>(right_abs_y.size());
        structure.left_wall_valid = structure.num_left_points >= params_.min_wall_points;
        structure.right_wall_valid = structure.num_right_points >= params_.min_wall_points;

        if (structure.left_wall_valid) structure.left_dist = median(left_abs_y);
        if (structure.right_wall_valid) structure.right_dist = median(right_abs_y);

        if (structure.left_wall_valid && structure.right_wall_valid)
        {
            structure.width = structure.left_dist + structure.right_dist;
            structure.center_error = structure.left_dist - structure.right_dist;
            structure.center_body.y() = 0.5f * structure.center_error;
        }
        else if (structure.left_wall_valid)
        {
            structure.center_body.y() = structure.left_dist - params_.wall_min_y;
        }
        else if (structure.right_wall_valid)
        {
            structure.center_body.y() = -(structure.right_dist - params_.wall_min_y);
        }

        std::vector<float> z_sorted = all_z;
        std::sort(z_sorted.begin(), z_sorted.end());
        const size_t ground_count =
            std::min(z_sorted.size(),
                     std::max<size_t>(1U, static_cast<size_t>(std::ceil(params_.ground_candidate_ratio * z_sorted.size()))));
        std::vector<float> z_ground(z_sorted.begin(), z_sorted.begin() + ground_count);
        structure.num_ground_points = static_cast<int>(z_ground.size());
        structure.ground_valid = structure.num_ground_points >= params_.min_ground_points;
        if (structure.ground_valid)
        {
            const float ground_z = median(z_ground);
            structure.ground_valid = std::isfinite(ground_z) && ground_z < -0.05f;
            if (structure.ground_valid)
            {
                structure.ground_z_body = ground_z;
                structure.relative_height = -ground_z;
                structure.center_body.z() = -ground_z;
            }
        }
        structure.height_confidence = structure.ground_valid ? 1.0f : 0.0f;

        const size_t ceiling_count =
            std::min(z_sorted.size(),
                     std::max<size_t>(1U, static_cast<size_t>(std::ceil(params_.ceiling_candidate_ratio * z_sorted.size()))));
        std::vector<float> z_ceiling(z_sorted.end() - ceiling_count, z_sorted.end());
        structure.num_ceiling_points = static_cast<int>(z_ceiling.size());
        structure.ceiling_valid = structure.num_ceiling_points >= params_.min_ceiling_points;
        if (structure.ceiling_valid)
        {
            const float ceiling_z = median(z_ceiling);
            structure.ceiling_valid = std::isfinite(ceiling_z) && ceiling_z > 0.05f;
            if (structure.ceiling_valid)
            {
                structure.ceiling_z_body = ceiling_z;
                structure.ceiling_relative_height = ceiling_z;
            }
        }

        estimateCenterlineByXBins(cloud_struct, structure);

        structure.lateral_confidence =
            (structure.left_wall_valid && structure.right_wall_valid) ? 1.0f : structure.centerline.confidence;

        Eigen::Vector3f new_direction = Eigen::Vector3f::UnitX();
        int valid_centerline_points = 0;
        for (const auto& point : structure.centerline.measured_points)
        {
            if (point.valid) ++valid_centerline_points;
        }
        if (valid_centerline_points >= 3)
        {
            const CenterlinePoint* first = nullptr;
            const CenterlinePoint* last = nullptr;
            for (const auto& point : structure.centerline.measured_points)
            {
                if (!point.valid) continue;
                if (!first) first = &point;
                last = &point;
            }
            if (first && last)
            {
                new_direction = last->p_body - first->p_body;
                new_direction.z() = 0.0f;
                if (new_direction.norm() > 1e-3f && new_direction.x() > 0.0f)
                {
                    new_direction.normalize();
                    structure.direction_confidence = 1.0f;
                }
                else
                {
                    new_direction = Eigen::Vector3f::UnitX();
                    structure.direction_confidence = 0.0f;
                }
            }
        }
        else
        {
            structure.direction_confidence = 0.0f;
        }

        if (has_last_direction_)
        {
            structure.direction_body =
                normalizedOrFallback(params_.direction_smooth_alpha * last_direction_body_ +
                                         (1.0f - params_.direction_smooth_alpha) * new_direction,
                                     last_direction_body_);
        }
        else
        {
            structure.direction_body = new_direction;
        }
        last_direction_body_ = structure.direction_body;
        has_last_direction_ = true;

        structure.overall_confidence =
            0.5f * structure.lateral_confidence +
            0.25f * structure.height_confidence +
            0.25f * structure.direction_confidence;

        structure.valid = structure.left_wall_valid || structure.right_wall_valid || structure.centerline.valid;
        return structure;
    }

private:
    Params params_;
    Eigen::Vector3f last_direction_body_;
    bool has_last_direction_ = false;
    float last_reliable_width_ = -1.0f;
    bool has_last_reliable_width_ = false;

    static float median(std::vector<float> values)
    {
        if (values.empty()) return std::numeric_limits<float>::quiet_NaN();

        const size_t mid = values.size() / 2;
        std::nth_element(values.begin(), values.begin() + mid, values.end());
        float med = values[mid];
        if ((values.size() % 2U) == 0U)
        {
            const auto max_it = std::max_element(values.begin(), values.begin() + mid);
            med = 0.5f * (med + *max_it);
        }
        return med;
    }

    static Eigen::Vector3f normalizedOrFallback(const Eigen::Vector3f& v,
                                                const Eigen::Vector3f& fallback)
    {
        if (v.norm() < 1e-4f) return fallback;
        return v.normalized();
    }

    void estimateCenterlineByXBins(const PointCloudConstPtr& cloud_struct,
                                   TunnelStructure& structure)
    {
        std::map<int, std::vector<float>> bin_left_y;
        std::map<int, std::vector<float>> bin_right_y;

        for (const auto& p : cloud_struct->points)
        {
            if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) continue;
            if (p.x < params_.centerline_bin_start_x || p.x > params_.centerline_bin_end_x) continue;

            const int bin_index = static_cast<int>(
                std::floor((p.x - params_.centerline_bin_start_x) / params_.centerline_bin_size_x));

            if (p.y > params_.wall_min_y) bin_left_y[bin_index].push_back(p.y);
            if (p.y < -params_.wall_min_y) bin_right_y[bin_index].push_back(p.y);
        }

        std::vector<CenterlinePoint> raw_points;
        std::vector<CenterlinePoint> left_wall_points;
        std::vector<CenterlinePoint> right_wall_points;
        float confidence_sum = 0.0f;
        float last_center_y = 0.0f;
        bool has_last_center = false;
        bool width_updated_this_frame = false;

        const int num_bins = std::max(
            0,
            static_cast<int>(std::ceil((params_.centerline_bin_end_x - params_.centerline_bin_start_x) /
                                       params_.centerline_bin_size_x)));

        for (int bin_index = 0; bin_index < num_bins; ++bin_index)
        {
            CenterlinePoint point;
            point.p_body.x() = params_.centerline_bin_start_x +
                               (static_cast<float>(bin_index) + 0.5f) * params_.centerline_bin_size_x;

            const auto left_it = bin_left_y.find(bin_index);
            const auto right_it = bin_right_y.find(bin_index);
            const bool left_valid = left_it != bin_left_y.end() &&
                                    static_cast<int>(left_it->second.size()) >= params_.min_points_per_side;
            const bool right_valid = right_it != bin_right_y.end() &&
                                     static_cast<int>(right_it->second.size()) >= params_.min_points_per_side;

            float center_y = 0.0f;
            float bin_confidence = 0.0f;
            bool point_valid = false;
            float left_y = 0.0f;
            float right_y = 0.0f;
            bool left_point_valid = false;
            bool right_point_valid = false;

            if (left_valid && right_valid)
            {
                left_y = median(left_it->second);
                right_y = median(right_it->second);
                const float width = left_y - right_y;

                if (!has_last_reliable_width_ ||
                    std::fabs(width - last_reliable_width_) <= params_.max_width_change)
                {
                    center_y = 0.5f * (left_y + right_y);
                    bin_confidence = 1.0f;
                    point_valid = true;
                    left_point_valid = true;
                    right_point_valid = true;
                    last_reliable_width_ = width;
                    has_last_reliable_width_ = true;
                    width_updated_this_frame = true;
                }
            }
            else if (has_last_reliable_width_ && (left_valid || right_valid))
            {
                if (left_valid)
                {
                    left_y = median(left_it->second);
                    center_y = left_y - 0.5f * last_reliable_width_;
                    right_y = left_y - last_reliable_width_;
                    left_point_valid = true;
                }
                else
                {
                    right_y = median(right_it->second);
                    center_y = right_y + 0.5f * last_reliable_width_;
                    left_y = right_y + last_reliable_width_;
                    right_point_valid = true;
                }
                bin_confidence = 0.5f;
                point_valid = true;
            }

            if (point_valid && has_last_center &&
                std::fabs(center_y - last_center_y) > params_.max_center_jump)
            {
                bin_confidence *= 0.5f;
            }

            point.p_body.y() = center_y;
            point.p_body.z() = 0.0f;
            point.confidence = bin_confidence;
            point.valid = point_valid && bin_confidence > 0.0f;

            CenterlinePoint left_point;
            left_point.p_body = Eigen::Vector3f(point.p_body.x(), left_y, 0.0f);
            left_point.confidence = bin_confidence;
            left_point.valid = left_point_valid && bin_confidence > 0.0f;

            CenterlinePoint right_point;
            right_point.p_body = Eigen::Vector3f(point.p_body.x(), right_y, 0.0f);
            right_point.confidence = bin_confidence;
            right_point.valid = right_point_valid && bin_confidence > 0.0f;

            if (point.valid)
            {
                confidence_sum += point.confidence;
                last_center_y = center_y;
                has_last_center = true;
            }
            raw_points.push_back(point);
            left_wall_points.push_back(left_point);
            right_wall_points.push_back(right_point);
        }

        if (!width_updated_this_frame && structure.width > 0.0f)
        {
            last_reliable_width_ = structure.width;
            has_last_reliable_width_ = true;
        }

        std::vector<CenterlinePoint> smoothed_points = raw_points;
        for (size_t i = 0; i < raw_points.size(); ++i)
        {
            if (!raw_points[i].valid) continue;

            float accum = 0.5f * raw_points[i].p_body.y();
            float weight = 0.5f;
            if (i > 0 && raw_points[i - 1].valid)
            {
                accum += 0.25f * raw_points[i - 1].p_body.y();
                weight += 0.25f;
            }
            if (i + 1 < raw_points.size() && raw_points[i + 1].valid)
            {
                accum += 0.25f * raw_points[i + 1].p_body.y();
                weight += 0.25f;
            }
            smoothed_points[i].p_body.y() = accum / weight;
        }

        structure.centerline.measured_points = smoothed_points;
        structure.centerline.stable_points.clear();
        structure.left_wall_points_body = left_wall_points;
        structure.right_wall_points_body = right_wall_points;
        const int valid_count = static_cast<int>(std::count_if(
            smoothed_points.begin(), smoothed_points.end(),
            [](const CenterlinePoint& point) { return point.valid; }));
        structure.centerline.confidence =
            valid_count > 0 ? confidence_sum / static_cast<float>(valid_count) : 0.0f;
        structure.centerline.valid = valid_count >= 2;
    }
};

class TunnelCenterlineManager
{
public:
    enum class State
    {
        INIT = 0,
        TRACK = 1,
        HOLD = 2,
        FAIL = 3
    };

    struct Params
    {
        float stable_update_alpha = 0.8f;
        float hold_time_sec = 1.0f;
        float reliable_confidence_threshold = 0.6f;
        int min_reliable_points = 3;
    };

    TunnelCenterlineManager()
        : TunnelCenterlineManager(Params{})
    {
    }

    explicit TunnelCenterlineManager(const Params& params)
        : params_(params)
    {
    }

    TunnelCenterline update(const TunnelCenterline& measured_centerline,
                            const ros::Time& now)
    {
        if (isReliable(measured_centerline))
        {
            stable_centerline_ = blendStableCenterline(measured_centerline);
            if (stable_centerline_.stable_points.empty())
            {
                stable_centerline_.stable_points = measured_centerline.measured_points;
            }
            stable_centerline_.confidence = measured_centerline.confidence;
            stable_centerline_.valid = true;
            last_reliable_time_ = now;
            has_last_reliable_time_ = true;
            state_ = State::TRACK;
            return stable_centerline_;
        }

        if (has_last_reliable_time_ &&
            (now - last_reliable_time_).toSec() < params_.hold_time_sec &&
            !stable_centerline_.stable_points.empty())
        {
            stable_centerline_.valid = true;
            stable_centerline_.confidence *= 0.98f;
            state_ = State::HOLD;
            return stable_centerline_;
        }

        stable_centerline_.valid = false;
        stable_centerline_.confidence = 0.0f;
        state_ = State::FAIL;
        return stable_centerline_;
    }

private:
    Params params_;
    TunnelCenterline stable_centerline_;
    ros::Time last_reliable_time_;
    bool has_last_reliable_time_ = false;
    State state_ = State::INIT;

    bool isReliable(const TunnelCenterline& centerline) const
    {
        if (!centerline.valid) return false;
        if (centerline.confidence < params_.reliable_confidence_threshold) return false;

        int reliable_points = 0;
        for (const auto& point : centerline.measured_points)
        {
            if (point.valid) ++reliable_points;
        }
        return reliable_points >= params_.min_reliable_points;
    }

    TunnelCenterline blendStableCenterline(const TunnelCenterline& measured_centerline) const
    {
        if (stable_centerline_.stable_points.empty()) return measured_centerline;

        TunnelCenterline blended = measured_centerline;
        blended.stable_points.clear();
        const size_t count = std::min(stable_centerline_.stable_points.size(),
                                      measured_centerline.measured_points.size());
        blended.stable_points.reserve(count);

        for (size_t i = 0; i < count; ++i)
        {
            const auto& stable_point = stable_centerline_.stable_points[i];
            const auto& measured_point = measured_centerline.measured_points[i];

            CenterlinePoint out = measured_point;
            if (stable_point.valid && measured_point.valid)
            {
                out.p_body = params_.stable_update_alpha * stable_point.p_body +
                             (1.0f - params_.stable_update_alpha) * measured_point.p_body;
                out.confidence = params_.stable_update_alpha * stable_point.confidence +
                                 (1.0f - params_.stable_update_alpha) * measured_point.confidence;
                out.valid = true;
            }
            else if (stable_point.valid)
            {
                out = stable_point;
            }
            blended.stable_points.push_back(out);
        }

        blended.valid = !blended.stable_points.empty();
        return blended;
    }
};

class TunnelGoalSelector
{
public:
    struct Params
    {
        float lookahead_distance = 2.0f;
        float max_lateral_correction = 0.8f;
        float lateral_confidence_threshold = 0.75f;
        float height_confidence_threshold = 0.6f;
        float direction_confidence_threshold = 0.6f;
        float smooth_alpha = 0.8f;
        float max_y_step = 0.15f;
        float max_goal_step = 0.35f;
        bool use_structure_goal = false;
    };

    TunnelGoalSelector()
        : TunnelGoalSelector(Params{})
    {
    }

    explicit TunnelGoalSelector(const Params& params)
        : params_(params)
    {
    }

    bool computeStructureGoal(const TunnelCenterline& stable_centerline,
                              Eigen::Vector3f& structure_goal) const
    {
        if (!stable_centerline.valid || stable_centerline.stable_points.empty()) return false;

        for (const auto& point : stable_centerline.stable_points)
        {
            if (point.valid && point.p_body.x() >= params_.lookahead_distance)
            {
                structure_goal = point.p_body;
                return true;
            }
        }

        for (auto it = stable_centerline.stable_points.rbegin();
             it != stable_centerline.stable_points.rend(); ++it)
        {
            if (it->valid)
            {
                structure_goal = it->p_body;
                return true;
            }
        }

        return false;
    }

    Eigen::Vector3f selectGoal(const Eigen::Vector3f& pca_goal,
                               const Eigen::Vector3f& structure_goal,
                               const TunnelStructure& structure,
                               bool structure_goal_ok) const
    {
        if (params_.use_structure_goal &&
            structure_goal_ok &&
            structure.centerline.valid &&
            structure.lateral_confidence >= params_.lateral_confidence_threshold)
        {
            return structure_goal;
        }
        return pca_goal;
    }

    Eigen::Vector3f smoothAndLimitGoal(const Eigen::Vector3f& raw_goal,
                                       const Eigen::Vector3f& last_goal,
                                       bool has_last_goal) const
    {
        if (!has_last_goal) return raw_goal;

        Eigen::Vector3f out = params_.smooth_alpha * last_goal + (1.0f - params_.smooth_alpha) * raw_goal;
        out.y() = clampf(out.y(), last_goal.y() - params_.max_y_step, last_goal.y() + params_.max_y_step);

        const Eigen::Vector3f delta = out - last_goal;
        if (delta.norm() > params_.max_goal_step)
        {
            out = last_goal + delta.normalized() * params_.max_goal_step;
        }
        return out;
    }

private:
    Params params_;

    static float clampf(float value, float lo, float hi)
    {
        return std::max(lo, std::min(value, hi));
    }
};


struct TunnelHeightEstimate
{
    bool ground_valid = false;
    bool ceiling_valid = false;

    float ground_z_at_body = 0.0f;
    float ground_z_at_goal = 0.0f;
    float ceiling_z_at_body = 0.0f;
    float ceiling_z_at_goal = 0.0f;

    float ground_confidence = 0.0f;
    float ceiling_confidence = 0.0f;
    float slope_x = 0.0f;
    float slope_y = 0.0f;

    int num_ground_points = 0;
    int num_ceiling_points = 0;
};

class TunnelLocalSubmap
{
public:
    struct Params
    {
        float time_window_sec = 5.0f;
        float back_distance = 2.0f;
        float front_distance = 8.0f;
        float side_distance = 3.0f;
        float z_distance = 3.0f;
        float voxel_size = 0.20f;
        int max_points = 60000;
    };

    TunnelLocalSubmap()
        : TunnelLocalSubmap(Params{})
    {
    }

    explicit TunnelLocalSubmap(const Params& params)
        : params_(params)
    {
    }

    void update(const pcl::PointCloud<PointType>::ConstPtr& cloud_level,
                const geometry_msgs::PoseStamped& pose)
    {
        if (!cloud_level || cloud_level->empty()) return;

        const ros::Time now = ros::Time::now();
        const float yaw = yawFromPose(pose);
        const Eigen::Quaternionf q_world_yaw(Eigen::AngleAxisf(yaw, Eigen::Vector3f::UnitZ()));
        const Eigen::Vector3f pos_world(
            pose.pose.position.x,
            pose.pose.position.y,
            pose.pose.position.z);

        points_.reserve(std::min(static_cast<size_t>(params_.max_points),
                                 points_.size() + cloud_level->points.size()));
        for (const auto& p : cloud_level->points)
        {
            if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) continue;
            if (p.x < -params_.back_distance || p.x > params_.front_distance) continue;
            if (std::fabs(p.y) > params_.side_distance) continue;
            if (std::fabs(p.z) > params_.z_distance) continue;

            const Eigen::Vector3f p_level(p.x, p.y, p.z);
            const Eigen::Vector3f p_world = pos_world + q_world_yaw * p_level;

            TimedPoint tp;
            tp.point_world.x = p_world.x();
            tp.point_world.y = p_world.y();
            tp.point_world.z = p_world.z();
            tp.stamp = now;
            points_.push_back(tp);
        }

        prune(now);
    }

    pcl::PointCloud<PointType>::Ptr getLocalCloudLevel(const geometry_msgs::PoseStamped& pose) const
    {
        pcl::PointCloud<PointType>::Ptr out(new pcl::PointCloud<PointType>);
        out->reserve(points_.size());

        const float yaw = yawFromPose(pose);
        const Eigen::Quaternionf q_world_yaw(Eigen::AngleAxisf(yaw, Eigen::Vector3f::UnitZ()));
        const Eigen::Vector3f pos_world(
            pose.pose.position.x,
            pose.pose.position.y,
            pose.pose.position.z);

        for (const auto& tp : points_)
        {
            const Eigen::Vector3f p_world(tp.point_world.x, tp.point_world.y, tp.point_world.z);
            const Eigen::Vector3f p_level = q_world_yaw.conjugate() * (p_world - pos_world);

            if (p_level.x() < -params_.back_distance || p_level.x() > params_.front_distance) continue;
            if (std::fabs(p_level.y()) > params_.side_distance) continue;
            if (std::fabs(p_level.z()) > params_.z_distance) continue;

            PointType p;
            p.x = p_level.x();
            p.y = p_level.y();
            p.z = p_level.z();
            out->points.push_back(p);
        }

        out->width = out->points.size();
        out->height = 1;
        out->is_dense = true;

        if (out->empty() || params_.voxel_size <= 1e-3f) return out;

        pcl::VoxelGrid<PointType> voxel;
        voxel.setLeafSize(params_.voxel_size, params_.voxel_size, params_.voxel_size);
        voxel.setInputCloud(out);

        pcl::PointCloud<PointType>::Ptr filtered(new pcl::PointCloud<PointType>);
        voxel.filter(*filtered);
        return filtered;
    }

    size_t size() const
    {
        return points_.size();
    }

private:
    struct TimedPoint
    {
        PointType point_world;
        ros::Time stamp;
    };

    Params params_;
    std::vector<TimedPoint> points_;

    void prune(const ros::Time& now)
    {
        points_.erase(
            std::remove_if(points_.begin(), points_.end(),
                           [&](const TimedPoint& p)
                           {
                               return (now - p.stamp).toSec() > params_.time_window_sec;
                           }),
            points_.end());

        if (static_cast<int>(points_.size()) > params_.max_points)
        {
            const int remove_count = static_cast<int>(points_.size()) - params_.max_points;
            points_.erase(points_.begin(), points_.begin() + remove_count);
        }
    }

    static float yawFromPose(const geometry_msgs::PoseStamped& pose)
    {
        const Eigen::Quaternionf q(
            pose.pose.orientation.w,
            pose.pose.orientation.x,
            pose.pose.orientation.y,
            pose.pose.orientation.z);
        const Eigen::Vector3f forward = q * Eigen::Vector3f::UnitX();
        return std::atan2(forward.y(), forward.x());
    }
};

class TunnelHeightEstimator
{
public:
    struct Params
    {
        float x_min = -1.0f;
        float x_max = 6.0f;
        float x_bin_size = 0.5f;
        float center_y_abs = 0.9f;
        float z_abs_max = 3.0f;
        int min_ground_points = 40;
        int min_ceiling_points = 40;
        int min_valid_bins = 3;
        float ground_low_ratio = 0.20f;
        float ceiling_high_ratio = 0.20f;
        float smooth_alpha = 0.85f;
        float hold_time_sec = 1.5f;
        float max_abs_slope = 0.35f;
    };

    TunnelHeightEstimator()
        : TunnelHeightEstimator(Params{})
    {
    }

    explicit TunnelHeightEstimator(const Params& params)
        : params_(params)
    {
    }

    TunnelHeightEstimate estimate(const pcl::PointCloud<PointType>::ConstPtr& local_cloud,
                                  const Eigen::Vector3f& goal_body)
    {
        TunnelHeightEstimate out;
        const ros::Time now = ros::Time::now();
        if (!local_cloud || local_cloud->empty())
        {
            return holdLast(now);
        }

        std::vector<PointType> ground_candidates;
        std::vector<PointType> ceiling_candidates;
        collectExtremeCandidates(local_cloud, goal_body, ground_candidates, ceiling_candidates);

        PlaneModel ground_plane;
        if (static_cast<int>(ground_candidates.size()) >= params_.min_ground_points &&
            fitPlane(ground_candidates, ground_plane) &&
            isGroundPlaneReasonable(ground_plane, goal_body))
        {
            float z_body = ground_plane.c;
            float z_goal = evalPlane(ground_plane, goal_body.x(), goal_body.y());
            if (has_last_ground_)
            {
                z_body = params_.smooth_alpha * last_ground_z_body_ + (1.0f - params_.smooth_alpha) * z_body;
                z_goal = params_.smooth_alpha * last_ground_z_goal_ + (1.0f - params_.smooth_alpha) * z_goal;
            }

            out.ground_valid = true;
            out.ground_z_at_body = z_body;
            out.ground_z_at_goal = z_goal;
            out.ground_confidence = confidenceFromCount(static_cast<int>(ground_candidates.size()),
                                                        params_.min_ground_points);
            out.slope_x = ground_plane.a;
            out.slope_y = ground_plane.b;
            out.num_ground_points = static_cast<int>(ground_candidates.size());

            last_ground_z_body_ = z_body;
            last_ground_z_goal_ = z_goal;
            last_ground_slope_x_ = ground_plane.a;
            last_ground_slope_y_ = ground_plane.b;
            last_ground_confidence_ = out.ground_confidence;
            last_ground_points_ = out.num_ground_points;
            last_ground_time_ = now;
            has_last_ground_ = true;
        }

        PlaneModel ceiling_plane;
        if (static_cast<int>(ceiling_candidates.size()) >= params_.min_ceiling_points &&
            fitPlane(ceiling_candidates, ceiling_plane) &&
            isCeilingPlaneReasonable(ceiling_plane, goal_body))
        {
            float z_body = ceiling_plane.c;
            float z_goal = evalPlane(ceiling_plane, goal_body.x(), goal_body.y());
            if (has_last_ceiling_)
            {
                z_body = params_.smooth_alpha * last_ceiling_z_body_ + (1.0f - params_.smooth_alpha) * z_body;
                z_goal = params_.smooth_alpha * last_ceiling_z_goal_ + (1.0f - params_.smooth_alpha) * z_goal;
            }

            out.ceiling_valid = true;
            out.ceiling_z_at_body = z_body;
            out.ceiling_z_at_goal = z_goal;
            out.ceiling_confidence = confidenceFromCount(static_cast<int>(ceiling_candidates.size()),
                                                         params_.min_ceiling_points);
            out.num_ceiling_points = static_cast<int>(ceiling_candidates.size());

            last_ceiling_z_body_ = z_body;
            last_ceiling_z_goal_ = z_goal;
            last_ceiling_confidence_ = out.ceiling_confidence;
            last_ceiling_points_ = out.num_ceiling_points;
            last_ceiling_time_ = now;
            has_last_ceiling_ = true;
        }

        if (!out.ground_valid && hasRecentGround(now))
        {
            out.ground_valid = true;
            out.ground_z_at_body = last_ground_z_body_;
            out.ground_z_at_goal = last_ground_z_goal_;
            out.ground_confidence = 0.35f * last_ground_confidence_;
            out.slope_x = last_ground_slope_x_;
            out.slope_y = last_ground_slope_y_;
            out.num_ground_points = last_ground_points_;
        }

        if (!out.ceiling_valid && hasRecentCeiling(now))
        {
            out.ceiling_valid = true;
            out.ceiling_z_at_body = last_ceiling_z_body_;
            out.ceiling_z_at_goal = last_ceiling_z_goal_;
            out.ceiling_confidence = 0.35f * last_ceiling_confidence_;
            out.num_ceiling_points = last_ceiling_points_;
        }

        return out;
    }

private:
    struct PlaneModel
    {
        float a = 0.0f;
        float b = 0.0f;
        float c = 0.0f;
    };

    Params params_;

    bool has_last_ground_ = false;
    bool has_last_ceiling_ = false;
    ros::Time last_ground_time_;
    ros::Time last_ceiling_time_;
    float last_ground_z_body_ = 0.0f;
    float last_ground_z_goal_ = 0.0f;
    float last_ground_slope_x_ = 0.0f;
    float last_ground_slope_y_ = 0.0f;
    float last_ground_confidence_ = 0.0f;
    int last_ground_points_ = 0;
    float last_ceiling_z_body_ = 0.0f;
    float last_ceiling_z_goal_ = 0.0f;
    float last_ceiling_confidence_ = 0.0f;
    int last_ceiling_points_ = 0;

    void collectExtremeCandidates(const pcl::PointCloud<PointType>::ConstPtr& cloud,
                                  const Eigen::Vector3f& goal_body,
                                  std::vector<PointType>& ground_candidates,
                                  std::vector<PointType>& ceiling_candidates) const
    {
        const int num_bins = std::max(1, static_cast<int>(
            std::ceil((params_.x_max - params_.x_min) / std::max(params_.x_bin_size, 0.1f))));

        std::vector<std::vector<PointType>> ground_bins(num_bins);
        std::vector<std::vector<PointType>> ceiling_bins(num_bins);
        const float center_y = clampf(goal_body.y(), -1.5f, 1.5f);

        for (const auto& p : cloud->points)
        {
            if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) continue;
            if (p.x < params_.x_min || p.x > params_.x_max) continue;
            if (std::fabs(p.y - center_y) > params_.center_y_abs) continue;
            if (std::fabs(p.z) > params_.z_abs_max) continue;

            const int bin = clampi(static_cast<int>(std::floor((p.x - params_.x_min) /
                                                               std::max(params_.x_bin_size, 0.1f))),
                                   0,
                                   num_bins - 1);
            if (p.z < 0.35f) ground_bins[bin].push_back(p);
            if (p.z > 0.20f) ceiling_bins[bin].push_back(p);
        }

        int valid_ground_bins = 0;
        int valid_ceiling_bins = 0;
        for (auto& bin_points : ground_bins)
        {
            if (bin_points.empty()) continue;
            std::sort(bin_points.begin(), bin_points.end(),
                      [](const PointType& a, const PointType& b) { return a.z < b.z; });
            const int take_count = std::max(1, static_cast<int>(
                std::ceil(params_.ground_low_ratio * static_cast<float>(bin_points.size()))));
            for (int i = 0; i < std::min(take_count, static_cast<int>(bin_points.size())); ++i)
            {
                ground_candidates.push_back(bin_points[i]);
            }
            ++valid_ground_bins;
        }

        for (auto& bin_points : ceiling_bins)
        {
            if (bin_points.empty()) continue;
            std::sort(bin_points.begin(), bin_points.end(),
                      [](const PointType& a, const PointType& b) { return a.z > b.z; });
            const int take_count = std::max(1, static_cast<int>(
                std::ceil(params_.ceiling_high_ratio * static_cast<float>(bin_points.size()))));
            for (int i = 0; i < std::min(take_count, static_cast<int>(bin_points.size())); ++i)
            {
                ceiling_candidates.push_back(bin_points[i]);
            }
            ++valid_ceiling_bins;
        }

        if (valid_ground_bins < params_.min_valid_bins) ground_candidates.clear();
        if (valid_ceiling_bins < params_.min_valid_bins) ceiling_candidates.clear();
    }

    bool fitPlane(const std::vector<PointType>& points, PlaneModel& plane) const
    {
        if (points.size() < 3U) return false;

        Eigen::Matrix3f ata = Eigen::Matrix3f::Zero();
        Eigen::Vector3f atz = Eigen::Vector3f::Zero();
        for (const auto& p : points)
        {
            const Eigen::Vector3f row(p.x, p.y, 1.0f);
            ata += row * row.transpose();
            atz += row * p.z;
        }

        if (std::fabs(ata.determinant()) < 1e-6f) return false;
        const Eigen::Vector3f sol = ata.ldlt().solve(atz);
        if (!sol.allFinite()) return false;

        plane.a = sol.x();
        plane.b = sol.y();
        plane.c = sol.z();
        return true;
    }

    bool isGroundPlaneReasonable(const PlaneModel& plane,
                                 const Eigen::Vector3f& goal_body) const
    {
        const float slope = std::sqrt(plane.a * plane.a + plane.b * plane.b);
        const float z_body = plane.c;
        const float z_goal = evalPlane(plane, goal_body.x(), goal_body.y());
        return slope <= params_.max_abs_slope &&
               std::isfinite(z_body) && std::isfinite(z_goal) &&
               z_body < -0.05f && z_goal < 0.35f &&
               std::fabs(z_body) <= params_.z_abs_max &&
               std::fabs(z_goal) <= params_.z_abs_max;
    }

    bool isCeilingPlaneReasonable(const PlaneModel& plane,
                                  const Eigen::Vector3f& goal_body) const
    {
        const float slope = std::sqrt(plane.a * plane.a + plane.b * plane.b);
        const float z_body = plane.c;
        const float z_goal = evalPlane(plane, goal_body.x(), goal_body.y());
        return slope <= params_.max_abs_slope &&
               std::isfinite(z_body) && std::isfinite(z_goal) &&
               z_body > 0.20f && z_goal > 0.20f &&
               std::fabs(z_body) <= params_.z_abs_max &&
               std::fabs(z_goal) <= params_.z_abs_max;
    }

    TunnelHeightEstimate holdLast(const ros::Time& now) const
    {
        TunnelHeightEstimate out;
        if (hasRecentGround(now))
        {
            out.ground_valid = true;
            out.ground_z_at_body = last_ground_z_body_;
            out.ground_z_at_goal = last_ground_z_goal_;
            out.ground_confidence = 0.30f * last_ground_confidence_;
            out.slope_x = last_ground_slope_x_;
            out.slope_y = last_ground_slope_y_;
            out.num_ground_points = last_ground_points_;
        }
        if (hasRecentCeiling(now))
        {
            out.ceiling_valid = true;
            out.ceiling_z_at_body = last_ceiling_z_body_;
            out.ceiling_z_at_goal = last_ceiling_z_goal_;
            out.ceiling_confidence = 0.30f * last_ceiling_confidence_;
            out.num_ceiling_points = last_ceiling_points_;
        }
        return out;
    }

    bool hasRecentGround(const ros::Time& now) const
    {
        return has_last_ground_ && (now - last_ground_time_).toSec() <= params_.hold_time_sec;
    }

    bool hasRecentCeiling(const ros::Time& now) const
    {
        return has_last_ceiling_ && (now - last_ceiling_time_).toSec() <= params_.hold_time_sec;
    }

    static float evalPlane(const PlaneModel& plane, float x, float y)
    {
        return plane.a * x + plane.b * y + plane.c;
    }

    static float confidenceFromCount(int count, int min_count)
    {
        if (min_count <= 0) return 1.0f;
        return clampf(static_cast<float>(count) / static_cast<float>(2 * min_count), 0.0f, 1.0f);
    }

    static float clampf(float value, float lo, float hi)
    {
        return std::max(lo, std::min(value, hi));
    }

    static int clampi(int value, int lo, int hi)
    {
        return std::max(lo, std::min(value, hi));
    }
};

class TunnelVisualizer
{
public:
    TunnelVisualizer() = default;

    explicit TunnelVisualizer(ros::NodeHandle& nh)
    {
        pca_goal_pub_ = nh.advertise<geometry_msgs::PoseStamped>("/tunnel/debug_pca_goal", 1);
        structure_goal_pub_ = nh.advertise<geometry_msgs::PoseStamped>("/tunnel/debug_structure_goal", 1);
        final_goal_pub_ = nh.advertise<geometry_msgs::PoseStamped>("/tunnel/debug_final_goal", 1);
        structure_state_pub_ = nh.advertise<std_msgs::Float64MultiArray>("/tunnel/structure_state", 1);
        height_state_pub_ = nh.advertise<std_msgs::Float64MultiArray>("/tunnel/height_state", 1);
        centerline_marker_pub_ = nh.advertise<visualization_msgs::Marker>("/tunnel/centerline_marker", 1);
        direction_marker_pub_ = nh.advertise<visualization_msgs::Marker>("/tunnel/direction_marker", 1);
        wall_marker_pub_ = nh.advertise<visualization_msgs::Marker>("/tunnel/wall_marker", 1);
        ground_ceiling_marker_pub_ = nh.advertise<visualization_msgs::Marker>("/tunnel/ground_ceiling_marker", 1);
    }

    void publish(const geometry_msgs::PoseStamped& pose,
                 const TunnelStructure& structure,
                 const TunnelHeightEstimate& height_estimate,
                 const TunnelCenterline& stable_centerline,
                 const Eigen::Vector3f& pca_goal,
                 const Eigen::Vector3f& structure_goal,
                 const Eigen::Vector3f& final_goal) const
    {
        const ros::Time stamp = ros::Time::now();

        pca_goal_pub_.publish(makeGoalPose(pose, pca_goal));
        structure_goal_pub_.publish(makeGoalPose(pose, structure_goal));
        final_goal_pub_.publish(makeGoalPose(pose, final_goal));

        std_msgs::Float64MultiArray state;
        state.data = {
            structure.valid ? 1.0 : 0.0,
            structure.lateral_confidence,
            structure.height_confidence,
            structure.direction_confidence,
            structure.overall_confidence,
            stable_centerline.confidence,
            structure.left_dist,
            structure.right_dist,
            structure.width,
            structure.relative_height,
            structure.center_error,
            structure.direction_body.x(),
            structure.direction_body.y(),
            structure.direction_body.z(),
            structure.ceiling_relative_height,
            structure.ground_z_body,
            structure.ceiling_z_body,
            structure.ground_valid ? 1.0 : 0.0,
            structure.ceiling_valid ? 1.0 : 0.0,
            static_cast<double>(structure.num_ground_points),
            static_cast<double>(structure.num_ceiling_points)
        };
        structure_state_pub_.publish(state);

        std_msgs::Float64MultiArray height_state;
        height_state.data = {
            height_estimate.ground_valid ? 1.0 : 0.0,
            height_estimate.ceiling_valid ? 1.0 : 0.0,
            height_estimate.ground_z_at_body,
            height_estimate.ground_z_at_goal,
            height_estimate.ceiling_z_at_body,
            height_estimate.ceiling_z_at_goal,
            height_estimate.ground_confidence,
            height_estimate.ceiling_confidence,
            height_estimate.slope_x,
            height_estimate.slope_y,
            static_cast<double>(height_estimate.num_ground_points),
            static_cast<double>(height_estimate.num_ceiling_points)
        };
        height_state_pub_.publish(height_state);

        visualization_msgs::Marker centerline =
            makeBaseMarker("tunnel_centerline", 0, visualization_msgs::Marker::LINE_STRIP, stamp);
        centerline.scale.x = 0.08;
        centerline.color.r = 0.1f;
        centerline.color.g = 0.9f;
        centerline.color.b = 0.2f;
        centerline.color.a = 1.0f;
        if (!stable_centerline.stable_points.empty())
        {
            for (const auto& point : stable_centerline.stable_points)
            {
                if (!point.valid) continue;
                centerline.points.push_back(toWorldPoint(pose, point.p_body));
            }
        }
        else if (!structure.centerline.measured_points.empty())
        {
            for (const auto& point : structure.centerline.measured_points)
            {
                if (!point.valid) continue;
                centerline.points.push_back(toWorldPoint(pose, point.p_body));
            }
        }
        else
        {
            centerline.points.push_back(pose.pose.position);
            centerline.points.push_back(toWorldPoint(pose, structure_goal));
        }
        centerline_marker_pub_.publish(centerline);

        visualization_msgs::Marker direction =
            makeBaseMarker("tunnel_direction", 0, visualization_msgs::Marker::ARROW, stamp);
        direction.scale.x = 0.08;
        direction.scale.y = 0.16;
        direction.scale.z = 0.2;
        direction.color.r = 0.1f;
        direction.color.g = 0.8f;
        direction.color.b = 1.0f;
        direction.color.a = 1.0f;
        direction.points.push_back(pose.pose.position);
        direction.points.push_back(toWorldPoint(pose, 2.0f * structure.direction_body.normalized()));
        direction_marker_pub_.publish(direction);

        visualization_msgs::Marker walls =
            makeBaseMarker("tunnel_walls", 0, visualization_msgs::Marker::LINE_LIST, stamp);
        walls.scale.x = 0.08;
        walls.color.r = 1.0f;
        walls.color.g = 0.65f;
        walls.color.b = 0.1f;
        walls.color.a = 1.0f;

        if (!structure.left_wall_points_body.empty() || !structure.right_wall_points_body.empty())
        {
            for (size_t i = 1; i < structure.left_wall_points_body.size(); ++i)
            {
                const auto& prev = structure.left_wall_points_body[i - 1];
                const auto& curr = structure.left_wall_points_body[i];
                if (!prev.valid || !curr.valid) continue;
                walls.points.push_back(toWorldPoint(pose, prev.p_body));
                walls.points.push_back(toWorldPoint(pose, curr.p_body));
            }
            for (size_t i = 1; i < structure.right_wall_points_body.size(); ++i)
            {
                const auto& prev = structure.right_wall_points_body[i - 1];
                const auto& curr = structure.right_wall_points_body[i];
                if (!prev.valid || !curr.valid) continue;
                walls.points.push_back(toWorldPoint(pose, prev.p_body));
                walls.points.push_back(toWorldPoint(pose, curr.p_body));
            }
        }
        else
        {
            if (structure.left_wall_valid)
            {
                walls.points.push_back(toWorldPoint(pose, Eigen::Vector3f(0.6f, structure.left_dist, 0.0f)));
                walls.points.push_back(toWorldPoint(pose, Eigen::Vector3f(2.0f, structure.left_dist, 0.0f)));
            }
            if (structure.right_wall_valid)
            {
                walls.points.push_back(toWorldPoint(pose, Eigen::Vector3f(0.6f, -structure.right_dist, 0.0f)));
                walls.points.push_back(toWorldPoint(pose, Eigen::Vector3f(2.0f, -structure.right_dist, 0.0f)));
            }
        }
        wall_marker_pub_.publish(walls);

        publishGroundCeilingMarkers(pose, structure, height_estimate, stamp);
    }

private:
    ros::Publisher pca_goal_pub_;
    ros::Publisher structure_goal_pub_;
    ros::Publisher final_goal_pub_;
    ros::Publisher structure_state_pub_;
    ros::Publisher height_state_pub_;
    ros::Publisher centerline_marker_pub_;
    ros::Publisher direction_marker_pub_;
    ros::Publisher wall_marker_pub_;
    ros::Publisher ground_ceiling_marker_pub_;

    void publishGroundCeilingMarkers(const geometry_msgs::PoseStamped& pose,
                                     const TunnelStructure& structure,
                                     const TunnelHeightEstimate& height_estimate,
                                     const ros::Time& stamp) const
    {
        visualization_msgs::Marker height =
            makeBaseMarker("tunnel_ground_ceiling", 0, visualization_msgs::Marker::LINE_LIST, stamp);
        height.scale.x = 0.06;
        height.color.a = 1.0f;

        float half_width = 1.5f;
        if (structure.width > 0.0f)
        {
            half_width = 0.5f * structure.width;
        }
        else if (structure.left_wall_valid && structure.right_wall_valid)
        {
            half_width = 0.5f * (structure.left_dist + structure.right_dist);
        }
        half_width = clampf(half_width, 0.6f, 3.0f);

        const float x_min = 0.5f;
        const float x_max = 4.0f;
        const std_msgs::ColorRGBA ground_color = makeColor(0.1f, 0.9f, 0.25f, 0.95f);
        const std_msgs::ColorRGBA ceiling_color = makeColor(0.1f, 0.65f, 1.0f, 0.95f);

        if (height_estimate.ground_valid)
        {
            appendHeightRectangle(height, pose, height_estimate.ground_z_at_body, half_width,
                                  x_min, x_max, ground_color);
        }
        else if (structure.ground_valid)
        {
            appendHeightRectangle(height, pose, structure.ground_z_body, half_width,
                                  x_min, x_max, ground_color);
        }

        if (height_estimate.ceiling_valid)
        {
            appendHeightRectangle(height, pose, height_estimate.ceiling_z_at_body, half_width,
                                  x_min, x_max, ceiling_color);
        }
        else if (structure.ceiling_valid)
        {
            appendHeightRectangle(height, pose, structure.ceiling_z_body, half_width,
                                  x_min, x_max, ceiling_color);
        }

        ground_ceiling_marker_pub_.publish(height);
    }

    static geometry_msgs::Point toWorldPoint(const geometry_msgs::PoseStamped& pose,
                                             const Eigen::Vector3f& point_level)
    {
        const float yaw = yawFromPose(pose);
        const Eigen::Quaternionf q_world_yaw(Eigen::AngleAxisf(yaw, Eigen::Vector3f::UnitZ()));
        const Eigen::Vector3f pos_world(
            pose.pose.position.x,
            pose.pose.position.y,
            pose.pose.position.z);
        const Eigen::Vector3f point_xy_level(point_level.x(), point_level.y(), 0.0f);
        const Eigen::Vector3f world_xy_delta = q_world_yaw * point_xy_level;
        const Eigen::Vector3f world_point(
            pos_world.x() + world_xy_delta.x(),
            pos_world.y() + world_xy_delta.y(),
            pos_world.z() + point_level.z());

        geometry_msgs::Point point;
        point.x = world_point.x();
        point.y = world_point.y();
        point.z = world_point.z();
        return point;
    }

    static float yawFromPose(const geometry_msgs::PoseStamped& pose)
    {
        const Eigen::Quaternionf q(
            pose.pose.orientation.w,
            pose.pose.orientation.x,
            pose.pose.orientation.y,
            pose.pose.orientation.z);
        const Eigen::Vector3f forward = q * Eigen::Vector3f::UnitX();
        return std::atan2(forward.y(), forward.x());
    }

    static geometry_msgs::PoseStamped makeGoalPose(const geometry_msgs::PoseStamped& pose,
                                                   const Eigen::Vector3f& point_level)
    {
        geometry_msgs::PoseStamped out;
        out.header.stamp = ros::Time::now();
        out.header.frame_id = "camera_init";
        out.pose.position = toWorldPoint(pose, point_level);
        out.pose.orientation = pose.pose.orientation;
        return out;
    }

    static std_msgs::ColorRGBA makeColor(float r, float g, float b, float a)
    {
        std_msgs::ColorRGBA color;
        color.r = r;
        color.g = g;
        color.b = b;
        color.a = a;
        return color;
    }

    static void appendColoredPoint(visualization_msgs::Marker& marker,
                                   const geometry_msgs::PoseStamped& pose,
                                   const Eigen::Vector3f& point_level,
                                   const std_msgs::ColorRGBA& color)
    {
        marker.points.push_back(toWorldPoint(pose, point_level));
        marker.colors.push_back(color);
    }

    static void appendColoredLine(visualization_msgs::Marker& marker,
                                  const geometry_msgs::PoseStamped& pose,
                                  const Eigen::Vector3f& start_body,
                                  const Eigen::Vector3f& end_body,
                                  const std_msgs::ColorRGBA& color)
    {
        appendColoredPoint(marker, pose, start_body, color);
        appendColoredPoint(marker, pose, end_body, color);
    }

    static void appendHeightRectangle(visualization_msgs::Marker& marker,
                                      const geometry_msgs::PoseStamped& pose,
                                      float z_body,
                                      float half_width,
                                      float x_min,
                                      float x_max,
                                      const std_msgs::ColorRGBA& color)
    {
        const Eigen::Vector3f front_left(x_max, half_width, z_body);
        const Eigen::Vector3f front_right(x_max, -half_width, z_body);
        const Eigen::Vector3f back_left(x_min, half_width, z_body);
        const Eigen::Vector3f back_right(x_min, -half_width, z_body);

        appendColoredLine(marker, pose, back_left, front_left, color);
        appendColoredLine(marker, pose, back_right, front_right, color);
        appendColoredLine(marker, pose, back_left, back_right, color);
        appendColoredLine(marker, pose, front_left, front_right, color);
    }

    static float clampf(float value, float lo, float hi)
    {
        return std::max(lo, std::min(value, hi));
    }

    static visualization_msgs::Marker makeBaseMarker(const std::string& topic_ns,
                                                     int id,
                                                     int type,
                                                     const ros::Time& stamp)
    {
        visualization_msgs::Marker marker;
        marker.header.frame_id = "camera_init";
        marker.header.stamp = stamp;
        marker.ns = topic_ns;
        marker.id = id;
        marker.type = type;
        marker.action = visualization_msgs::Marker::ADD;
        marker.pose.orientation.w = 1.0;
        return marker;
    }
};

class GoalPublisher
{
public:
    explicit GoalPublisher(ros::NodeHandle& nh)
        : nh_(nh)
    {
        loadParams();

        pcl_cloud_.reset(new pcl::PointCloud<PointType>);
        cloud_filtered_.reset(new pcl::PointCloud<PointType>);
        cloud_level_.reset(new pcl::PointCloud<PointType>);
        cloud_filtered2_.reset(new pcl::PointCloud<PointType>);
        cloud_struct_.reset(new pcl::PointCloud<PointType>);
        cloud_submap_struct_.reset(new pcl::PointCloud<PointType>);

        pass_filter_.setFilterFieldName("x");
        pass_filter_.setFilterLimits(kFrontDistance, FLT_MAX);
        pass_filter_.setFilterLimitsNegative(false);
        sor_.setMeanK(100);
        sor_.setStddevMulThresh(10.0);
        voxel_filter_.setLeafSize(kVoxelSize, kVoxelSize, kVoxelSize);

        TunnelStructureEstimator::Params estimator_params;
        estimator_params.wall_min_y = wall_min_y_;
        estimator_params.min_wall_points = min_wall_points_;
        estimator_params.ground_candidate_ratio = ground_candidate_ratio_;
        estimator_params.min_ground_points = min_ground_points_;
        estimator_params.ceiling_candidate_ratio = ceiling_candidate_ratio_;
        estimator_params.min_ceiling_points = min_ceiling_points_;
        estimator_params.centerline_bin_start_x = centerline_bin_start_x_;
        estimator_params.centerline_bin_end_x = centerline_bin_end_x_;
        estimator_params.centerline_bin_size_x = centerline_bin_size_x_;
        estimator_params.min_points_per_side = min_points_per_side_;
        estimator_params.max_width_change = max_width_change_;
        estimator_params.max_center_jump = max_center_jump_;
        estimator_params.direction_smooth_alpha = direction_smooth_alpha_;
        structure_estimator_ = TunnelStructureEstimator(estimator_params);
        submap_structure_estimator_ = TunnelStructureEstimator(estimator_params);

        TunnelCenterlineManager::Params manager_params;
        manager_params.stable_update_alpha = goal_smooth_alpha_;
        manager_params.hold_time_sec = centerline_hold_time_sec_;
        manager_params.reliable_confidence_threshold = centerline_reliable_confidence_threshold_;
        manager_params.min_reliable_points = centerline_min_reliable_points_;
        centerline_manager_ = TunnelCenterlineManager(manager_params);

        TunnelGoalSelector::Params selector_params;
        selector_params.lookahead_distance = lookahead_distance_;
        selector_params.max_lateral_correction = max_lateral_correction_;
        selector_params.lateral_confidence_threshold = lateral_confidence_threshold_;
        selector_params.height_confidence_threshold = height_confidence_threshold_;
        selector_params.direction_confidence_threshold = direction_confidence_threshold_;
        selector_params.smooth_alpha = goal_smooth_alpha_;
        selector_params.max_y_step = max_y_step_;
        selector_params.max_goal_step = max_goal_step_;
        selector_params.use_structure_goal = use_structure_goal_;
        goal_selector_ = TunnelGoalSelector(selector_params);

        TunnelLocalSubmap::Params submap_params;
        submap_params.time_window_sec = local_map_time_window_sec_;
        submap_params.back_distance = local_map_back_distance_;
        submap_params.front_distance = local_map_front_distance_;
        submap_params.side_distance = local_map_side_distance_;
        submap_params.z_distance = local_map_z_distance_;
        submap_params.voxel_size = local_map_voxel_size_;
        submap_params.max_points = local_map_max_points_;
        local_submap_ = TunnelLocalSubmap(submap_params);

        TunnelHeightEstimator::Params height_params;
        height_params.x_min = height_x_min_;
        height_params.x_max = height_x_max_;
        height_params.x_bin_size = height_x_bin_size_;
        height_params.center_y_abs = height_center_y_abs_;
        height_params.z_abs_max = height_z_abs_max_;
        height_params.min_ground_points = height_min_ground_points_;
        height_params.min_ceiling_points = height_min_ceiling_points_;
        height_params.min_valid_bins = height_min_valid_bins_;
        height_params.ground_low_ratio = height_ground_low_ratio_;
        height_params.ceiling_high_ratio = height_ceiling_high_ratio_;
        height_params.smooth_alpha = height_smooth_alpha_;
        height_params.hold_time_sec = height_hold_time_sec_;
        height_params.max_abs_slope = height_max_abs_slope_;
        height_estimator_ = TunnelHeightEstimator(height_params);

        visualizer_ = TunnelVisualizer(nh_);

        pose_sub_ = nh_.subscribe("/mavros/local_position/pose", 1, &GoalPublisher::poseCallback, this);
        goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1);
        ext_dist_ = nh_.subscribe("/distance_landing_node/integrated_distance", 1, &GoalPublisher::distCallback, this);
        cloud_sub_ = nh_.subscribe("/livox/points", 1, &GoalPublisher::pointCloudCallback, this);
        timer_ = nh_.createTimer(ros::Duration(0.2), &GoalPublisher::timerCallback, this);

        ROS_INFO("Stage2 tunnel guidance single-file node started. goal_mode=%s use_structure_goal=%s debug_only=%s",
                 goal_mode_.c_str(),
                 use_structure_goal_ ? "true" : "false",
                 debug_only_ ? "true" : "false");
    }

private:
    ros::NodeHandle nh_;
    ros::Subscriber pose_sub_;
    ros::Publisher goal_pub_;
    ros::Subscriber ext_dist_;
    ros::Timer timer_;
    ros::Subscriber cloud_sub_;

    geometry_msgs::PoseStamped current_pose_;
    geometry_msgs::Point home_position_;
    std::mutex pose_mutex_;
    std::mutex cloud_mutex_;

    pcl::PointCloud<PointType>::Ptr pcl_cloud_;
    pcl::VoxelGrid<PointType> voxel_filter_;
    pcl::PointCloud<PointType>::Ptr cloud_filtered_;
    pcl::PointCloud<PointType>::Ptr cloud_level_;
    pcl::PointCloud<PointType>::Ptr cloud_filtered2_;
    pcl::PointCloud<PointType>::Ptr cloud_struct_;
    pcl::PointCloud<PointType>::Ptr cloud_submap_struct_;
    pcl::PassThrough<PointType> pass_filter_;
    pcl::StatisticalOutlierRemoval<PointType> sor_;

    Vector3f pca_center_ = Vector3f::Zero();
    Vector3f last_point_ = Vector3f::Zero();
    ros::Time update_time_;

    TunnelStructureEstimator structure_estimator_;
    TunnelStructureEstimator submap_structure_estimator_;
    TunnelCenterlineManager centerline_manager_;
    TunnelGoalSelector goal_selector_;
    TunnelLocalSubmap local_submap_;
    TunnelHeightEstimator height_estimator_;
    TunnelVisualizer visualizer_;

    bool pose_received_ = false;
    bool initialized_ = false;

    ros::Time start_time_;
    float total_distance_ = 0.0f;
    geometry_msgs::Point last_position_;

    bool use_structure_goal_ = true;
    bool debug_only_ = false;
    // SUBMAP_ONLY: x-y target and yaw direction are estimated from the local sliding-window submap.
    // STRUCTURE_ONLY: x-y target is estimated from the current frame only.
    std::string goal_mode_ = "SUBMAP_ONLY";
    float lookahead_distance_ = 2.0f;
    float max_lateral_correction_ = 0.8f;
    float lateral_confidence_threshold_ = 0.75f;
    float height_confidence_threshold_ = 0.6f;
    float direction_confidence_threshold_ = 0.6f;
    float goal_smooth_alpha_ = 0.8f;
    float max_y_step_ = 0.15f;
    float max_goal_step_ = 0.35f;
    float struct_x_min_ = 0.2f;
    float struct_x_max_ = 5.0f;
    float struct_y_abs_max_ = 3.0f;
    float struct_z_abs_max_ = 2.0f;

    // Crop used when estimating the horizontal tunnel centerline from the local submap.
    // It is intentionally separated from local_map_* because the local map may include
    // rear/up/down points for height estimation, while x-y guidance should mainly use
    // the front tunnel section.
    float submap_xy_x_min_ = 0.2f;
    float submap_xy_x_max_ = 5.0f;
    float submap_xy_y_abs_max_ = 3.0f;
    float submap_xy_z_abs_max_ = 2.0f;

    float desired_relative_height_ = 1.3f;
    float desired_ceiling_clearance_ = 0.6f;
    float max_height_step_ = 0.25f;
    bool use_world_z_guard_ = false;
    float min_goal_z_ = 0.8f;
    float max_goal_z_ = 1.8f;
    float wall_min_y_ = 0.4f;
    int min_wall_points_ = 80;
    float ground_candidate_ratio_ = 0.2f;
    int min_ground_points_ = 60;
    float ceiling_candidate_ratio_ = 0.2f;
    int min_ceiling_points_ = 60;
    float centerline_bin_start_x_ = 0.5f;
    float centerline_bin_end_x_ = 5.0f;
    float centerline_bin_size_x_ = 0.5f;
    int min_points_per_side_ = 20;
    float max_width_change_ = 0.5f;
    float max_center_jump_ = 0.4f;
    float direction_smooth_alpha_ = 0.8f;
    float centerline_hold_time_sec_ = 1.0f;
    float centerline_reliable_confidence_threshold_ = 0.6f;
    int centerline_min_reliable_points_ = 3;

    float structure_goal_hold_time_sec_ = 0.8f;
    float tunnel_wall_clearance_ = 0.35f;

    float local_map_time_window_sec_ = 5.0f;
    float local_map_back_distance_ = 2.0f;
    float local_map_front_distance_ = 8.0f;
    float local_map_side_distance_ = 3.0f;
    float local_map_z_distance_ = 3.0f;
    float local_map_voxel_size_ = 0.20f;
    int local_map_max_points_ = 60000;

    float height_x_min_ = -1.0f;
    float height_x_max_ = 6.0f;
    float height_x_bin_size_ = 0.5f;
    float height_center_y_abs_ = 0.9f;
    float height_z_abs_max_ = 3.0f;
    int height_min_ground_points_ = 40;
    int height_min_ceiling_points_ = 40;
    int height_min_valid_bins_ = 3;
    float height_ground_low_ratio_ = 0.20f;
    float height_ceiling_high_ratio_ = 0.20f;
    float height_smooth_alpha_ = 0.85f;
    float height_hold_time_sec_ = 1.5f;
    float height_max_abs_slope_ = 0.35f;

    TunnelCenterline stable_centerline_;
    Vector3f last_structure_goal_ = Vector3f::Zero();
    ros::Time last_structure_goal_time_;
    bool has_last_structure_goal_ = false;

    void loadParams()
    {
        nh_.param("tunnel/use_structure_goal", use_structure_goal_, use_structure_goal_);
        nh_.param("tunnel/debug_only", debug_only_, debug_only_);
        nh_.param<std::string>("tunnel/goal_mode", goal_mode_, goal_mode_);
        nh_.param("tunnel/lookahead_distance", lookahead_distance_, lookahead_distance_);
        nh_.param("tunnel/max_lateral_correction", max_lateral_correction_, max_lateral_correction_);
        nh_.param("tunnel/lateral_confidence_threshold",
                  lateral_confidence_threshold_,
                  lateral_confidence_threshold_);
        nh_.param("tunnel/height_confidence_threshold",
                  height_confidence_threshold_,
                  height_confidence_threshold_);
        nh_.param("tunnel/direction_confidence_threshold",
                  direction_confidence_threshold_,
                  direction_confidence_threshold_);
        nh_.param("tunnel/goal_smooth_alpha", goal_smooth_alpha_, goal_smooth_alpha_);
        nh_.param("tunnel/max_y_step", max_y_step_, max_y_step_);
        nh_.param("tunnel/max_goal_step", max_goal_step_, max_goal_step_);

        nh_.param("tunnel/struct_x_min", struct_x_min_, struct_x_min_);
        nh_.param("tunnel/struct_x_max", struct_x_max_, struct_x_max_);
        nh_.param("tunnel/struct_y_abs_max", struct_y_abs_max_, struct_y_abs_max_);
        nh_.param("tunnel/struct_z_abs_max", struct_z_abs_max_, struct_z_abs_max_);
        nh_.param("tunnel/submap_xy_x_min", submap_xy_x_min_, submap_xy_x_min_);
        nh_.param("tunnel/submap_xy_x_max", submap_xy_x_max_, submap_xy_x_max_);
        nh_.param("tunnel/submap_xy_y_abs_max", submap_xy_y_abs_max_, submap_xy_y_abs_max_);
        nh_.param("tunnel/submap_xy_z_abs_max", submap_xy_z_abs_max_, submap_xy_z_abs_max_);
        nh_.param("tunnel/desired_relative_height", desired_relative_height_, desired_relative_height_);
        nh_.param("tunnel/desired_ceiling_clearance", desired_ceiling_clearance_, desired_ceiling_clearance_);
        nh_.param("tunnel/max_height_step", max_height_step_, max_height_step_);
        nh_.param("tunnel/use_world_z_guard", use_world_z_guard_, use_world_z_guard_);
        nh_.param("tunnel/min_goal_z", min_goal_z_, min_goal_z_);
        nh_.param("tunnel/max_goal_z", max_goal_z_, max_goal_z_);
        nh_.param("tunnel/wall_min_y", wall_min_y_, wall_min_y_);
        nh_.param("tunnel/min_wall_points", min_wall_points_, min_wall_points_);
        nh_.param("tunnel/ground_candidate_ratio", ground_candidate_ratio_, ground_candidate_ratio_);
        nh_.param("tunnel/min_ground_points", min_ground_points_, min_ground_points_);
        nh_.param("tunnel/ceiling_candidate_ratio", ceiling_candidate_ratio_, ceiling_candidate_ratio_);
        nh_.param("tunnel/min_ceiling_points", min_ceiling_points_, min_ceiling_points_);
        nh_.param("tunnel/centerline_bin_start_x", centerline_bin_start_x_, centerline_bin_start_x_);
        nh_.param("tunnel/centerline_bin_end_x", centerline_bin_end_x_, centerline_bin_end_x_);
        nh_.param("tunnel/centerline_bin_size_x", centerline_bin_size_x_, centerline_bin_size_x_);
        nh_.param("tunnel/min_points_per_side", min_points_per_side_, min_points_per_side_);
        nh_.param("tunnel/max_width_change", max_width_change_, max_width_change_);
        nh_.param("tunnel/max_center_jump", max_center_jump_, max_center_jump_);
        nh_.param("tunnel/direction_smooth_alpha", direction_smooth_alpha_, direction_smooth_alpha_);
        nh_.param("tunnel/centerline_hold_time_sec", centerline_hold_time_sec_, centerline_hold_time_sec_);
        nh_.param("tunnel/centerline_reliable_confidence_threshold",
                  centerline_reliable_confidence_threshold_,
                  centerline_reliable_confidence_threshold_);
        nh_.param("tunnel/centerline_min_reliable_points",
                  centerline_min_reliable_points_,
                  centerline_min_reliable_points_);

        nh_.param("tunnel/structure_goal_hold_time_sec",
                  structure_goal_hold_time_sec_,
                  structure_goal_hold_time_sec_);
        nh_.param("tunnel/tunnel_wall_clearance", tunnel_wall_clearance_, tunnel_wall_clearance_);

        nh_.param("tunnel/local_map_time_window_sec", local_map_time_window_sec_, local_map_time_window_sec_);
        nh_.param("tunnel/local_map_back_distance", local_map_back_distance_, local_map_back_distance_);
        nh_.param("tunnel/local_map_front_distance", local_map_front_distance_, local_map_front_distance_);
        nh_.param("tunnel/local_map_side_distance", local_map_side_distance_, local_map_side_distance_);
        nh_.param("tunnel/local_map_z_distance", local_map_z_distance_, local_map_z_distance_);
        nh_.param("tunnel/local_map_voxel_size", local_map_voxel_size_, local_map_voxel_size_);
        nh_.param("tunnel/local_map_max_points", local_map_max_points_, local_map_max_points_);

        nh_.param("tunnel/height_x_min", height_x_min_, height_x_min_);
        nh_.param("tunnel/height_x_max", height_x_max_, height_x_max_);
        nh_.param("tunnel/height_x_bin_size", height_x_bin_size_, height_x_bin_size_);
        nh_.param("tunnel/height_center_y_abs", height_center_y_abs_, height_center_y_abs_);
        nh_.param("tunnel/height_z_abs_max", height_z_abs_max_, height_z_abs_max_);
        nh_.param("tunnel/height_min_ground_points", height_min_ground_points_, height_min_ground_points_);
        nh_.param("tunnel/height_min_ceiling_points", height_min_ceiling_points_, height_min_ceiling_points_);
        nh_.param("tunnel/height_min_valid_bins", height_min_valid_bins_, height_min_valid_bins_);
        nh_.param("tunnel/height_ground_low_ratio", height_ground_low_ratio_, height_ground_low_ratio_);
        nh_.param("tunnel/height_ceiling_high_ratio", height_ceiling_high_ratio_, height_ceiling_high_ratio_);
        nh_.param("tunnel/height_smooth_alpha", height_smooth_alpha_, height_smooth_alpha_);
        nh_.param("tunnel/height_hold_time_sec", height_hold_time_sec_, height_hold_time_sec_);
        nh_.param("tunnel/height_max_abs_slope", height_max_abs_slope_, height_max_abs_slope_);
    }

    void distCallback(const std_msgs::Float64::ConstPtr& msg)
    {
        total_distance_ = static_cast<float>(msg->data);
    }

    void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg)
    {
        std::lock_guard<std::mutex> lock(pose_mutex_);
        current_pose_ = *msg;
        pose_received_ = true;

        if (!initialized_)
        {
            home_position_ = current_pose_.pose.position;
            last_position_ = current_pose_.pose.position;
            start_time_ = ros::Time::now();
            initialized_ = true;
            ROS_INFO("Home position set and tracking started.");
        }
    }

    void pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg)
    {
        pcl::PointCloud<PointType> tmp;
        pcl::fromROSMsg(*msg, tmp);
        std::lock_guard<std::mutex> lock(cloud_mutex_);
        *pcl_cloud_ = tmp;
    }

    void timerCallback(const ros::TimerEvent&)
    {
        {
            std::lock_guard<std::mutex> lock(cloud_mutex_);
            if (pcl_cloud_->empty())
            {
                ROS_INFO_THROTTLE(1.0, "NO PCL");
                return;
            }
        }

        cloudFilter();

        geometry_msgs::PoseStamped pose_snapshot;
        if (!getPoseSnapshot(pose_snapshot))
        {
            ROS_INFO_THROTTLE(1.0, "NO POSE");
            return;
        }
        buildLevelCloud(pose_snapshot);

        // The current frame is used to update the rolling local submap.
        // In SUBMAP_ONLY mode, the x-y centerline/target/yaw are then estimated
        // from this local submap instead of from the current frame.
        local_submap_.update(cloud_level_, pose_snapshot);
        pcl::PointCloud<PointType>::Ptr local_map_cloud = local_submap_.getLocalCloudLevel(pose_snapshot);

        cloudProcess();
        Vector3f pca_goal = pca_center_;
        if (pca_goal.norm() > kGoalLength)
        {
            pca_goal = pca_goal.normalized() * kGoalLength;
        }

        // Current-frame structure is kept for fallback/debug.
        buildStructureCloud();
        TunnelStructure frame_structure = structure_estimator_.estimate(cloud_struct_);

        // Submap structure is the main source in SUBMAP_ONLY mode.
        buildSubmapStructureCloud(local_map_cloud);
        TunnelStructure submap_structure = submap_structure_estimator_.estimate(cloud_submap_struct_);

        TunnelStructure structure = frame_structure;
        if (goal_mode_ == "SUBMAP_ONLY")
        {
            structure = submap_structure;
        }

        stable_centerline_ = centerline_manager_.update(structure.centerline, ros::Time::now());
        structure.centerline.stable_points = stable_centerline_.stable_points;
        structure.centerline.valid = structure.centerline.valid || stable_centerline_.valid;

        const Vector3f neutral_forward_goal(std::max(0.8f, std::min(kGoalLength, lookahead_distance_)),
                                            0.0f,
                                            0.0f);
        Vector3f structure_goal = (goal_mode_ == "SUBMAP_ONLY") ? neutral_forward_goal : pca_goal;
        bool structure_goal_ok = goal_selector_.computeStructureGoal(stable_centerline_, structure_goal);
        if (structure_goal_ok)
        {
            structure_goal = goal_selector_.smoothAndLimitGoal(
                structure_goal, last_structure_goal_, has_last_structure_goal_);
            last_structure_goal_ = structure_goal;
            last_structure_goal_time_ = ros::Time::now();
            has_last_structure_goal_ = true;
        }

        Vector3f final_goal = pca_goal;
        if (goal_mode_ == "BASELINE_ONLY")
        {
            final_goal = pca_goal;
        }
        else if (goal_mode_ == "STRUCTURE_ONLY_DEBUG")
        {
            final_goal = pca_goal;
        }
        else if (goal_mode_ == "STRUCTURE_ONLY")
        {
            if (structure_goal_ok)
            {
                final_goal = structure_goal;
            }
            else if (hasRecentStructureGoal())
            {
                final_goal = last_structure_goal_;
            }
            else
            {
                final_goal = pca_goal;
            }
        }
        else if (goal_mode_ == "SUBMAP_ONLY")
        {
            if (structure_goal_ok)
            {
                final_goal = structure_goal;
            }
            else if (hasRecentStructureGoal())
            {
                final_goal = last_structure_goal_;
            }
            else
            {
                // Pure submap mode does not fall back to the current-frame PCA centroid.
                // Before the local submap becomes reliable, move only toward a neutral forward point.
                final_goal = neutral_forward_goal;
            }
        }
        else
        {
            final_goal = goal_selector_.selectGoal(pca_goal, structure_goal, structure, structure_goal_ok);
        }

        if (goal_mode_ == "BASELINE_ONLY" || goal_mode_ == "STRUCTURE_ONLY_DEBUG")
        {
            gradAdjust(final_goal, cloud_filtered2_);
        }
        clampGoalInsideTunnel(final_goal, structure);

        TunnelHeightEstimate height_estimate = height_estimator_.estimate(local_map_cloud, final_goal);
        logHeightEstimateStatus(structure, height_estimate, local_map_cloud ? local_map_cloud->size() : 0U);
        logSubmapOnlyStatus(frame_structure, submap_structure, structure_goal_ok, structure_goal,
                            local_map_cloud ? local_map_cloud->size() : 0U);
        applyRelativeHeightControl(final_goal, height_estimate);

        Vector3f yaw_dir = final_goal;
        if (goal_mode_ != "BASELINE_ONLY" &&
            structure.direction_confidence >= direction_confidence_threshold_ &&
            structure.direction_body.norm() > 1e-3f)
        {
            yaw_dir = structure.direction_body;
        }

        if (!debug_only_)
        {
            pubPose(goal_pub_, final_goal, yaw_dir, pose_snapshot);
        }
        else
        {
            ROS_INFO_THROTTLE(1.0,
                              "debug_only=true: skip publishing goal, final level [%.2f %.2f %.2f]",
                              final_goal.x(), final_goal.y(), final_goal.z());
        }

        const Vector3f structure_goal_for_viz = structure_goal_ok ? structure_goal :
            ((goal_mode_ == "SUBMAP_ONLY") ? structure_goal : pca_goal);
        visualizer_.publish(pose_snapshot,
                            structure,
                            height_estimate,
                            stable_centerline_,
                            pca_goal,
                            structure_goal_for_viz,
                            final_goal);
    }

    void cloudFilter()
    {
        pcl::PointCloud<PointType>::Ptr raw_copy(new pcl::PointCloud<PointType>);
        {
            std::lock_guard<std::mutex> lock(cloud_mutex_);
            *raw_copy = *pcl_cloud_;
        }

        voxel_filter_.setInputCloud(raw_copy);
        voxel_filter_.filter(*cloud_filtered_);
        sor_.setInputCloud(cloud_filtered_);
        sor_.filter(*cloud_filtered_);
    }

    bool getPoseSnapshot(geometry_msgs::PoseStamped& pose)
    {
        std::lock_guard<std::mutex> lock(pose_mutex_);
        if (!pose_received_) return false;
        pose = current_pose_;
        return true;
    }

    void buildLevelCloud(const geometry_msgs::PoseStamped& pose)
    {
        cloud_level_->clear();
        cloud_level_->reserve(cloud_filtered_->size());

        const Eigen::Quaternionf q_world_body = quatFromPose(pose);
        const float yaw = yawFromPose(pose);
        const Eigen::Quaternionf q_world_yaw(Eigen::AngleAxisf(yaw, Eigen::Vector3f::UnitZ()));
        const Eigen::Quaternionf q_level_body = q_world_yaw.conjugate() * q_world_body;

        for (const auto& point : cloud_filtered_->points)
        {
            if (!std::isfinite(point.x) || !std::isfinite(point.y) || !std::isfinite(point.z)) continue;
            const Eigen::Vector3f p_level = q_level_body * Eigen::Vector3f(point.x, point.y, point.z);

            PointType out;
            out.x = p_level.x();
            out.y = p_level.y();
            out.z = p_level.z();
            cloud_level_->points.push_back(out);
        }

        cloud_level_->width = cloud_level_->points.size();
        cloud_level_->height = 1;
        cloud_level_->is_dense = true;
    }

    void cloudProcess()
    {
        pass_filter_.setInputCloud(cloud_level_);
        pass_filter_.filter(*cloud_filtered2_);

        if (cloud_filtered2_->empty())
        {
            pca_center_ = Vector3f(kGoalLength, 0.0f, 0.0f);
            return;
        }

        Eigen::Vector4f centroid;
        pcl::compute3DCentroid(*cloud_filtered2_, centroid);
        pca_center_ = Vector3f(centroid.x(), centroid.y(), centroid.z());
    }

    void buildStructureCloud()
    {
        buildStructureCloudFromSource(cloud_level_,
                                      cloud_struct_,
                                      struct_x_min_,
                                      struct_x_max_,
                                      struct_y_abs_max_,
                                      struct_z_abs_max_);
    }

    void buildSubmapStructureCloud(const pcl::PointCloud<PointType>::ConstPtr& local_map_cloud)
    {
        buildStructureCloudFromSource(local_map_cloud,
                                      cloud_submap_struct_,
                                      submap_xy_x_min_,
                                      submap_xy_x_max_,
                                      submap_xy_y_abs_max_,
                                      submap_xy_z_abs_max_);
    }

    void buildStructureCloudFromSource(const pcl::PointCloud<PointType>::ConstPtr& source,
                                       pcl::PointCloud<PointType>::Ptr& target,
                                       float x_min,
                                       float x_max,
                                       float y_abs_max,
                                       float z_abs_max) const
    {
        if (!target) target.reset(new pcl::PointCloud<PointType>);
        target->clear();
        if (!source || source->empty())
        {
            target->width = 0;
            target->height = 1;
            target->is_dense = true;
            return;
        }

        target->reserve(source->size());
        for (const auto& point : source->points)
        {
            if (!std::isfinite(point.x) || !std::isfinite(point.y) || !std::isfinite(point.z)) continue;
            if (point.x < x_min || point.x > x_max) continue;
            if (std::fabs(point.y) > y_abs_max) continue;
            if (std::fabs(point.z) > z_abs_max) continue;
            target->points.push_back(point);
        }
        target->width = target->points.size();
        target->height = 1;
        target->is_dense = true;
    }

    void logHeightEstimateStatus(const TunnelStructure& structure,
                                 const TunnelHeightEstimate& height,
                                 size_t local_height_points) const
    {
        if (height.ground_valid && height.ceiling_valid) return;

        const size_t struct_points = cloud_struct_ ? cloud_struct_->size() : 0U;
        ROS_WARN_THROTTLE(1.0,
                          "Height estimate incomplete: submap_ground=%s submap_ceiling=%s "
                          "submap_ground_points=%d submap_ceiling_points=%d "
                          "ground_z_body=%.2f ground_z_goal=%.2f ceiling_z_body=%.2f ceiling_z_goal=%.2f "
                          "slope=(%.3f, %.3f) local_height_points=%zu local_map_points=%zu "
                          "frame_ground=%s frame_ceiling=%s frame_ground_points=%d frame_ceiling_points=%d struct_points=%zu",
                          height.ground_valid ? "valid" : "invalid",
                          height.ceiling_valid ? "valid" : "invalid",
                          height.num_ground_points,
                          height.num_ceiling_points,
                          height.ground_z_at_body,
                          height.ground_z_at_goal,
                          height.ceiling_z_at_body,
                          height.ceiling_z_at_goal,
                          height.slope_x,
                          height.slope_y,
                          local_height_points,
                          local_submap_.size(),
                          structure.ground_valid ? "valid" : "invalid",
                          structure.ceiling_valid ? "valid" : "invalid",
                          structure.num_ground_points,
                          structure.num_ceiling_points,
                          struct_points);
    }

    void logSubmapOnlyStatus(const TunnelStructure& frame_structure,
                             const TunnelStructure& submap_structure,
                             bool structure_goal_ok,
                             const Vector3f& structure_goal,
                             size_t local_map_points) const
    {
        if (goal_mode_ != "SUBMAP_ONLY") return;

        ROS_INFO_THROTTLE(1.0,
                          "SUBMAP_ONLY xy: goal_ok=%s goal=[%.2f %.2f %.2f] "
                          "submap_valid=%s submap_conf=%.2f submap_dir_conf=%.2f "
                          "submap_centerline_points=%zu submap_struct_points=%zu local_map_points=%zu "
                          "frame_valid=%s frame_conf=%.2f frame_centerline_points=%zu",
                          structure_goal_ok ? "true" : "false",
                          structure_goal.x(), structure_goal.y(), structure_goal.z(),
                          submap_structure.valid ? "true" : "false",
                          submap_structure.lateral_confidence,
                          submap_structure.direction_confidence,
                          submap_structure.centerline.measured_points.size(),
                          cloud_submap_struct_ ? cloud_submap_struct_->size() : 0U,
                          local_map_points,
                          frame_structure.valid ? "true" : "false",
                          frame_structure.lateral_confidence,
                          frame_structure.centerline.measured_points.size());
    }

    void applyRelativeHeightControl(Vector3f& target_body, const TunnelHeightEstimate& height) const
    {
        float target_z = 0.0f;
        bool has_height_constraint = false;

        if (height.ground_valid)
        {
            target_z = height.ground_z_at_goal + desired_relative_height_;
            has_height_constraint = true;
        }

        if (height.ceiling_valid)
        {
            const float max_z_by_ceiling = height.ceiling_z_at_goal - desired_ceiling_clearance_;
            if (has_height_constraint)
            {
                target_z = std::min(target_z, max_z_by_ceiling);
            }
            else
            {
                target_z = std::min(0.0f, max_z_by_ceiling);
                has_height_constraint = true;
            }
        }

        if (!has_height_constraint)
        {
            target_z = 0.0f;
        }

        target_body.z() = clampf(target_z, -max_height_step_, max_height_step_);
    }

    void clampGoalInsideTunnel(Vector3f& target_body, const TunnelStructure& structure) const
    {
        const float min_x = 0.8f;
        const float max_x = std::max(min_x, lookahead_distance_);
        target_body.x() = clampf(target_body.x(), min_x, max_x);

        float y_min = -max_lateral_correction_;
        float y_max = max_lateral_correction_;

        if (structure.right_wall_valid && structure.right_dist > tunnel_wall_clearance_)
        {
            y_min = std::max(y_min, -structure.right_dist + tunnel_wall_clearance_);
        }
        if (structure.left_wall_valid && structure.left_dist > tunnel_wall_clearance_)
        {
            y_max = std::min(y_max, structure.left_dist - tunnel_wall_clearance_);
        }

        if (y_min <= y_max)
        {
            target_body.y() = clampf(target_body.y(), y_min, y_max);
        }
        else
        {
            target_body.y() = clampf(target_body.y(), -max_lateral_correction_, max_lateral_correction_);
        }
    }

    bool hasRecentStructureGoal() const
    {
        return has_last_structure_goal_ &&
               (ros::Time::now() - last_structure_goal_time_).toSec() <= structure_goal_hold_time_sec_;
    }

    static float clampf(float value, float lo, float hi)
    {
        return std::max(lo, std::min(value, hi));
    }

    void gradAdjust(Vector3f& target,
                    const pcl::PointCloud<PointType>::Ptr& obstacle_cloud) const
    {
        if (!obstacle_cloud || obstacle_cloud->empty()) return;

        std::vector<int> point_indices;
        std::vector<float> point_d2;
        pcl::KdTreeFLANN<PointType> kdtree;
        kdtree.setInputCloud(obstacle_cloud);

        PointType target_point;
        target_point.x = target.x();
        target_point.y = target.y();
        target_point.z = target.z();

        pcl::PointCloud<PointType>::Ptr local_cloud(new pcl::PointCloud<PointType>);
        const float dist = target.norm();
        const float radius = dist * 0.7f > kSearchRadius ? kSearchRadius : dist * 0.7f;
        if (kdtree.radiusSearch(target_point, radius, point_indices, point_d2) <= 0) return;

        for (const int idx : point_indices)
        {
            local_cloud->points.push_back(obstacle_cloud->points[idx]);
        }

        Vector3f x = target;
        const float sigma = 0.5f;
        const float lr = 0.01f;
        const int max_iter = 100;

        for (int iter = 0; iter < max_iter; ++iter)
        {
            Vector3f grad = Vector3f::Zero();
            for (const auto& p : local_cloud->points)
            {
                const Vector3f p_i(p.x, p.y, p.z);
                const Vector3f diff = x - p_i;
                const float dist2 = diff.squaredNorm();
                const float weight = std::exp(-dist2 / (2.0f * sigma * sigma));
                grad += (diff / (sigma * sigma)) * weight;
            }
            x += lr * grad;
            x.z() = target.z();
            if ((x - target).norm() > kSearchRadius / 2.0f) break;
        }

        target = x;
    }

    static float yawFromPose(const geometry_msgs::PoseStamped& pose)
    {
        const Eigen::Quaternionf q(
            pose.pose.orientation.w,
            pose.pose.orientation.x,
            pose.pose.orientation.y,
            pose.pose.orientation.z);
        const Eigen::Vector3f forward = q * Eigen::Vector3f::UnitX();
        return std::atan2(forward.y(), forward.x());
    }

    static Eigen::Quaternionf quatFromPose(const geometry_msgs::PoseStamped& pose)
    {
        Eigen::Quaternionf q(
            pose.pose.orientation.w,
            pose.pose.orientation.x,
            pose.pose.orientation.y,
            pose.pose.orientation.z);
        q.normalize();
        return q;
    }

    Eigen::Quaternionf computeDir(Vector3f dir_vec) const
    {
        dir_vec.z() = 0.0f;
        if (dir_vec.norm() < 1e-4f) return Eigen::Quaternionf::Identity();

        const Vector3f xb = dir_vec.normalized();
        const Vector3f zb(0.0f, 0.0f, 1.0f);
        const Vector3f yb = zb.cross(xb).normalized();
        Eigen::Matrix3f rotation;
        rotation.col(0) = xb;
        rotation.col(1) = yb;
        rotation.col(2) = zb;
        return Eigen::Quaternionf(rotation);
    }

    void pubPose(const ros::Publisher& pub,
                 const Vector3f& target_body,
                 const Vector3f& yaw_dir_body,
                 const geometry_msgs::PoseStamped& pose)
    {
        const float yaw = yawFromPose(pose);
        const Eigen::Quaternionf q_world_yaw(Eigen::AngleAxisf(yaw, Eigen::Vector3f::UnitZ()));
        const Vector3f target_xy_body(target_body.x(), target_body.y(), 0.0f);
        const Vector3f target_world_delta = q_world_yaw * target_xy_body;
        Vector3f dir_vec = yaw_dir_body;
        if (dir_vec.norm() < 1e-3f) dir_vec = target_body;
        const Eigen::Quaternionf q_target = q_world_yaw * computeDir(dir_vec);
        const Vector3f pos_now(pose.pose.position.x, pose.pose.position.y, pose.pose.position.z);

        float target_z = pose.pose.position.z + target_body.z();
        if (use_world_z_guard_)
        {
            target_z = std::max(min_goal_z_, std::min(target_z, max_goal_z_));
        }

        geometry_msgs::PoseStamped goal;
        goal.header.stamp = ros::Time::now();
        goal.header.frame_id = "camera_init";
        goal.pose.position.x = pose.pose.position.x + target_world_delta.x();
        goal.pose.position.y = pose.pose.position.y + target_world_delta.y();
        goal.pose.position.z = target_z;
        goal.pose.orientation.w = q_target.w();
        goal.pose.orientation.x = q_target.x();
        goal.pose.orientation.y = q_target.y();
        goal.pose.orientation.z = q_target.z();

        const Vector3f goal_point(goal.pose.position.x, goal.pose.position.y, goal.pose.position.z);
        if (last_point_.norm() == 0.0f ||
            goal.header.stamp - update_time_ > ros::Duration(kReplanDuration) ||
            (last_point_ - pos_now).norm() < kExeFinishDist ||
            (last_point_ - goal_point).norm() > kReplanThresh)
        {
            pub.publish(goal);
            ROS_INFO("goal level [%.2f %.2f %.2f], world [%.2f %.2f %.2f]",
                     target_body.x(), target_body.y(), target_body.z(),
                     goal.pose.position.x, goal.pose.position.y, goal.pose.position.z);
            last_point_ = goal_point;
            update_time_ = ros::Time::now();
        }
    }
};

int main(int argc, char** argv)
{
    ros::init(argc, argv, "goal_publisher_tunnel_guidance_single_node");
    ros::NodeHandle nh("~");
    GoalPublisher node(nh);
    ros::spin();
    return 0;
}
