#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/TwistStamped.h>
#include <sensor_msgs/PointCloud2.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/Odometry.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <mutex>
#include <cmath>
#include <iostream>
#include <string>
#include <deque>
#include <pcl/io/pcd_io.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/common/transforms.h>
#include <pcl/common/common.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/features/normal_3d.h>
#include <pcl/features/pfh.h>
#include <pcl/features/fpfh.h>
#include <pcl/registration/icp.h>
#include <pcl/registration/ia_ransac.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/PCLPointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/conversions.h>
#include <pcl_ros/transforms.h>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include <Eigen/Dense>
#include <Eigen/QR>

typedef pcl::PointXYZ PointType;

// ============ 可调参数 ============
#define VOXEL_SIZE 0.2
#define MIN_SAFE_RADIUS 0.6
#define GOAL_STEP 5.0
#define QUEUE_SIZE 3
#define SWITCH_DIST 2.0
#define SEARCH_HORIZON 15.0
#define MAX_RADIUS 5.0
#define REPLAN_INTERVAL 0.2
#define SPEED_SMOOTH_FACTOR 0.3

// 扇形采样参数
#define HORIZONTAL_ANGLES {-45, -30, -15, 0, 15, 30, 45}
#define VERTICAL_ANGLES {-20, -10, 0, 10, 20}

// 历史平滑参数
#define HISTORY_SIZE 5
#define MAX_LATERAL_RATIO 0.3

// PCA轴向估计参数
#define PCA_POINTS_MIN 100
#define PCA_UPDATE_INTERVAL 1.0

// LiDAR视场角参数 (Livox Mid360)
#define FOV_UP_DEG 52.0
#define FOV_DOWN_DEG -7.0

// 安全验证参数
#define SAFE_CHECK_POINTS 20
#define SAFE_CHECK_THRESHOLD 0.2

// 高度约束参数
#define GROUND_CLEARANCE 0.5
#define CEILING_CLEARANCE 0.5

// 点云帧数限制
#define MAX_GLOBAL_FRAMES 20  // 保留最近 20 帧点云（可根据实际帧率和内存调整）
// ================================

using namespace Eigen;
using namespace std;

struct SphereInfo
{
    Vector3f center;
    float radius;
    bool is_current_goal;
    ros::Time timestamp;
    int optimize_count;    // 已优化次数
    bool is_fixed;         // 是否已固定（不再优化）
};

class TunnelGoalPublisher
{
public:
    TunnelGoalPublisher(ros::NodeHandle& nh_)
    {
        // ============ 初始化 ============
        current_pos_ = Vector3f(0, 0, 0);
        current_vel_ = Vector3f(1, 0, 0);
        smoothed_dir_ = Vector3f(1, 0, 0);
        tunnel_axis_ = Vector3f(1, 0, 0);
        last_pca_time_ = ros::Time::now();
        
        // 高度范围初始化
        min_z_seen_ = 100.0;
        max_z_seen_ = -100.0;
        // 绝对高度上限（可根据实际情况调整）
        absolute_max_height_ = 10.0;  // 例如最高不超过 10 米

        pcl_cloud_global_.reset(new pcl::PointCloud<PointType>);
        pcl_cloud_local_.reset(new pcl::PointCloud<PointType>);
        
        // ============ PCL对象初始化 ============
        pcl_cloud_.reset(new pcl::PointCloud<PointType>);
        cloud_filtered_.reset(new pcl::PointCloud<PointType>);
        cloud_downsampled_.reset(new pcl::PointCloud<PointType>);
        cloud_pca_.reset(new pcl::PointCloud<PointType>);
        kdtree_.reset(new pcl::KdTreeFLANN<PointType>);
        
        // 滤波器设置
        voxel_filter_.setLeafSize(VOXEL_SIZE, VOXEL_SIZE, VOXEL_SIZE);
        
        pass_filter_.setFilterFieldName("x");
        pass_filter_.setFilterLimits(2.0, SEARCH_HORIZON);
        pass_filter_.setFilterLimitsNegative(false);
        
        pass_filter_y_.setFilterFieldName("y");
        pass_filter_y_.setFilterLimits(-4.0, 4.0);
        pass_filter_y_.setFilterLimitsNegative(false);
        
        pass_filter_z_.setFilterFieldName("z");
        pass_filter_z_.setFilterLimits(-2.0, 10.0);
        pass_filter_z_.setFilterLimitsNegative(false);
        
        sor_.setMeanK(50);
        sor_.setStddevMulThresh(3.0);
        
        // ============ ROS通信初始化 ============
        pose_sub_ = nh_.subscribe("/Odometry", 1, 
                                  &TunnelGoalPublisher::poseCallback, this);
        vel_sub_ = nh_.subscribe("/mavros/local_position/velocity_local", 1,
                                 &TunnelGoalPublisher::velocityCallback, this);
        cloud_sub_ = nh_.subscribe("/cloud_registered", 1,
                                   &TunnelGoalPublisher::pointCloudCallback, this);
        
        goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1);
        // goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/position_cmd", 1);
        
        // ============ 可视化Publisher ============
        sphere_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/visualization/safety_spheres", 1);
        corridor_pub_ = nh_.advertise<visualization_msgs::Marker>("/visualization/flight_corridor", 1);
        text_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/visualization/sphere_labels", 1);
        path_pub_ = nh_.advertise<nav_msgs::Path>("/visualization/center_path", 1);
        axis_pub_ = nh_.advertise<visualization_msgs::Marker>("/visualization/tunnel_axis", 1);
        // 新增 Publisher：发布每个球心周围搜索半径内的所有点云
        search_points_pub_ = nh_.advertise<sensor_msgs::PointCloud2>("/visualization/search_points", 1);
        

        // 新增：最近障碍物可视化
        obstacle_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/visualization/nearest_obstacles", 1);
        
        timer_ = nh_.createTimer(ros::Duration(REPLAN_INTERVAL), 
                                 &TunnelGoalPublisher::timerCallback, this);
        
        ROS_INFO("Tunnel Goal Publisher with Multi-Method Fusion Initialized");
        ROS_INFO("Using frame_id: world");
        ROS_INFO("Nearest obstacles visualization enabled");
    }

private:
    // ============ ROS通信成员 ============
    ros::Subscriber pose_sub_;
    ros::Subscriber vel_sub_;
    ros::Subscriber cloud_sub_;
    ros::Publisher goal_pub_;
    ros::Timer timer_;
    
    // ============ 可视化Publisher ============
    ros::Publisher sphere_pub_;
    ros::Publisher corridor_pub_;
    ros::Publisher text_pub_;
    ros::Publisher path_pub_;
    ros::Publisher axis_pub_;
    ros::Publisher obstacle_pub_;  // 新增：最近障碍物可视化
    ros::Publisher search_points_pub_;
    float absolute_max_height_;// 新增成员
    
    // ============ 状态变量 ============
    Vector3f current_pos_;
    Vector3f current_vel_;
    Vector3f smoothed_dir_;
    Vector3f tunnel_axis_;
    std::deque<SphereInfo> sphere_queue_;
    std::deque<Vector3f> history_centers_;
    ros::Time last_cloud_time_;
    ros::Time last_pca_time_;
    std::deque<pcl::PointCloud<PointType>::Ptr> cloud_frames_;  // 存储各帧点云的智能指针
    
    // 高度范围统计
    float min_z_seen_;
    float max_z_seen_;
    
    // ============ PCL相关 ============
    pcl::PointCloud<PointType>::Ptr pcl_cloud_;
    pcl::PointCloud<PointType>::Ptr cloud_filtered_;
    pcl::PointCloud<PointType>::Ptr cloud_downsampled_;
    pcl::PointCloud<PointType>::Ptr cloud_pca_;
    pcl::KdTreeFLANN<PointType>::Ptr kdtree_;

    pcl::PointCloud<PointType>::Ptr pcl_cloud_global_;   // 累积的全局点云（可选）
    pcl::PointCloud<PointType>::Ptr pcl_cloud_local_;    // 当前局部点云（用于 KD‑Tree）
    
    // ============ 滤波器 ============
    pcl::VoxelGrid<PointType> voxel_filter_;
    pcl::PassThrough<PointType> pass_filter_;
    pcl::PassThrough<PointType> pass_filter_y_;
    pcl::PassThrough<PointType> pass_filter_z_;
    pcl::StatisticalOutlierRemoval<PointType> sor_;

    // ============ 回调函数 ============
    void poseCallback(const nav_msgs::Odometry::ConstPtr& msg)
    {
        current_pos_ = Vector3f(msg->pose.pose.position.x,
                                msg->pose.pose.position.y,
                                msg->pose.pose.position.z);
    }
    
    void velocityCallback(const geometry_msgs::TwistStamped::ConstPtr& msg)
    {
        Vector3f raw_vel(msg->twist.linear.x,
                         msg->twist.linear.y,
                         msg->twist.linear.z);
        
        if (raw_vel.norm() > 0.1)
        {
            current_vel_ = raw_vel;
            smoothed_dir_ = SPEED_SMOOTH_FACTOR * raw_vel.normalized() + 
                          (1 - SPEED_SMOOTH_FACTOR) * smoothed_dir_;
            smoothed_dir_.normalize();
        }
    }
    
    // void pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg)
    // {
    //     pcl::fromROSMsg(*msg, *pcl_cloud_);
    //     last_cloud_time_ = ros::Time::now();
    // }
    void pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg)
    {
        pcl::PointCloud<PointType>::Ptr new_frame(new pcl::PointCloud<PointType>);
        pcl::fromROSMsg(*msg, *new_frame);
        
        // 将新帧加入队列
        cloud_frames_.push_back(new_frame);
        
        // 如果超出最大帧数，移除最老帧
        if (cloud_frames_.size() > MAX_GLOBAL_FRAMES)
        {
            cloud_frames_.pop_front();
        }
        
        // 重新构建全局累积点云：合并所有保留帧
        pcl_cloud_global_->clear();
        for (const auto& frame : cloud_frames_)
        {
            *pcl_cloud_global_ += *frame;
        }
        
        // 可选：体素滤波全局点云，进一步减少点数
        // pcl::VoxelGrid<PointType> vg; vg.setLeafSize(0.1,0.1,0.1); vg.setInputCloud(pcl_cloud_global_); vg.filter(*pcl_cloud_global_);
    }

    // void extractLocalCloud()
    // {
    //     if (pcl_cloud_global_->empty()) return;
        
    //     pcl::PointCloud<PointType>::Ptr local(new pcl::PointCloud<PointType>);
        
    //     // 定义局部窗口范围（可根据实际隧道尺寸调整）
    //     float range_x = SEARCH_HORIZON + 3.0;   // 前后范围，前方多预留一些
    //     float range_y = 5.0;                    // 左右范围
    //     float range_z = 5.0;                    // 上下范围
        
    //     for (const auto& pt : pcl_cloud_global_->points)
    //     {
    //         if (pt.x > current_pos_.x() - range_x && pt.x < current_pos_.x() + range_x &&
    //             pt.y > current_pos_.y() - range_y && pt.y < current_pos_.y() + range_y &&
    //             pt.z > current_pos_.z() - range_z && pt.z < current_pos_.z() + range_z)
    //         {
    //             local->push_back(pt);
    //         }
    //     }
        
    //     if (local->empty())
    //     {
    //         ROS_WARN_THROTTLE(1.0, "No points in local window, using full cloud as fallback");
    //         *pcl_cloud_local_ = *pcl_cloud_global_;
    //     }
    //     else
    //     {
    //         *pcl_cloud_local_ = *local;
    //     }
    // }
    void extractLocalCloud()
    {
        if (pcl_cloud_global_->empty()) return;
        
        pcl::PointCloud<PointType>::Ptr local(new pcl::PointCloud<PointType>);
        
        // 可调参数：前方距离（根据 SEARCH_HORIZON 适当增加）
        const float FORWARD_RANGE = SEARCH_HORIZON + 3.0;  // 前方 6+3 = 9 米
        const float LATERAL_RANGE = 5.0;                    // 左右各 5 米
        const float VERTICAL_RANGE = 5.0;                    // 上下各 5 米
        
        float x_min = current_pos_.x();                     // 从当前位置开始（不含后方）
        float x_max = current_pos_.x() + FORWARD_RANGE;
        float y_min = current_pos_.y() - LATERAL_RANGE;
        float y_max = current_pos_.y() + LATERAL_RANGE;
        float z_min = current_pos_.z() - VERTICAL_RANGE;
        float z_max = current_pos_.z() + VERTICAL_RANGE;
        
        for (const auto& pt : pcl_cloud_global_->points)
        {
            if (pt.x >= x_min && pt.x <= x_max &&
                pt.y >= y_min && pt.y <= y_max &&
                pt.z >= z_min && pt.z <= z_max)
            {
                local->push_back(pt);
            }
        }
        
        if (local->empty())
        {
            ROS_WARN_THROTTLE(1.0, "No points in local forward window, using full cloud as fallback");
            *pcl_cloud_local_ = *pcl_cloud_global_;
        }
        else
        {
            *pcl_cloud_local_ = *local;
        }
    }
    
    // ============ 考虑LiDAR视场角的点云过滤 ============
    void filterByFOV()
    {
        if (cloud_filtered_->empty()) return;
        
        pcl::PointCloud<PointType>::Ptr fov_filtered(new pcl::PointCloud<PointType>);
        
        for (const auto& point : cloud_filtered_->points)
        {
            Vector3f rel_pos(point.x - current_pos_.x(),
                            point.y - current_pos_.y(),
                            point.z - current_pos_.z());
            
            float horizontal_dist = sqrt(rel_pos.x()*rel_pos.x() + rel_pos.y()*rel_pos.y());
            float pitch_deg = atan2(rel_pos.z(), horizontal_dist) * 180.0 / M_PI;
            
            if (pitch_deg >= FOV_DOWN_DEG && pitch_deg <= FOV_UP_DEG)
            {
                fov_filtered->push_back(point);
            }
        }
        
        if (fov_filtered->size() < 10)
        {
            ROS_WARN_THROTTLE(1.0, "FOV filtered cloud too small, using original with caution");
            return;
        }
        
        *cloud_filtered_ = *fov_filtered;
    }
    
    // ============ 更新高度统计 ============
    void updateHeightStatistics()
    {
        if (cloud_filtered_->empty()) return;
        
        for (const auto& point : cloud_filtered_->points)
        {
            if (point.z < min_z_seen_) min_z_seen_ = point.z;
            if (point.z > max_z_seen_) max_z_seen_ = point.z;
        }
        
        if (min_z_seen_ > max_z_seen_ - 0.5)
        {
            pcl::PointXYZ q(current_pos_.x(), current_pos_.y(), current_pos_.z());
            std::vector<int> indices;
            std::vector<float> sqr_dist;
            
            if (kdtree_->radiusSearch(q, 2.0, indices, sqr_dist) > 10)
            {
                min_z_seen_ = 100.0;
                max_z_seen_ = -100.0;
                for (int idx : indices)
                {
                    float z = cloud_filtered_->points[idx].z;
                    if (z < min_z_seen_) min_z_seen_ = z;
                    if (z > max_z_seen_) max_z_seen_ = z;
                }
            }
        }
    }
    
    // ============ 点云预处理 ============
    void preprocessCloud()
    {
        // if (pcl_cloud_->empty()) return;
        
        // cloud_downsampled_->clear();
        // voxel_filter_.setInputCloud(pcl_cloud_);
        // voxel_filter_.filter(*cloud_downsampled_);
        
        // cloud_filtered_->clear();
        // sor_.setInputCloud(cloud_downsampled_);
        // sor_.filter(*cloud_filtered_);
        
        // pass_filter_.setInputCloud(cloud_filtered_);
        // pass_filter_.filter(*cloud_filtered_);
        
        // pass_filter_y_.setInputCloud(cloud_filtered_);
        // pass_filter_y_.filter(*cloud_filtered_);
        
        // pass_filter_z_.setInputCloud(cloud_filtered_);
        // pass_filter_z_.filter(*cloud_filtered_);
        if (pcl_cloud_local_->empty()) return;
    
        // 体素滤波
        cloud_downsampled_->clear();
        voxel_filter_.setInputCloud(pcl_cloud_local_);
        voxel_filter_.filter(*cloud_downsampled_);
        
        // 统计滤波去除离群点
        cloud_filtered_->clear();
        sor_.setInputCloud(cloud_downsampled_);
        sor_.filter(*cloud_filtered_);
        
        filterByFOV();
        
        if (!cloud_filtered_->empty())
        {
            kdtree_->setInputCloud(cloud_filtered_);
            updateHeightStatistics();
            
            if ((ros::Time::now() - last_pca_time_).toSec() > PCA_UPDATE_INTERVAL)
            {
                estimateTunnelAxis();
                last_pca_time_ = ros::Time::now();
            }
        }
    }
    
    // ============ PCA估计隧道轴向 ============
    void estimateTunnelAxis()
    {
        if (cloud_filtered_->size() < PCA_POINTS_MIN) 
        {
            tunnel_axis_ = smoothed_dir_;
            return;
        }
        
        cloud_pca_->clear();
        
        Vector3f forward = smoothed_dir_.normalized();
        
        for (const auto& point : cloud_filtered_->points)
        {
            Vector3f pt(point.x, point.y, point.z);
            Vector3f rel_pt = pt - current_pos_;
            
            if (rel_pt.dot(forward) > 0 && rel_pt.dot(forward) < SEARCH_HORIZON)
            {
                cloud_pca_->push_back(point);
            }
        }
        
        if (cloud_pca_->size() < PCA_POINTS_MIN)
        {
            tunnel_axis_ = smoothed_dir_;
            return;
        }
        
        pcl::PointXYZ centroid;
        pcl::computeCentroid(*cloud_pca_, centroid);
        Vector3f centroid_vec(centroid.x, centroid.y, centroid.z);
        
        Eigen::Matrix3f covariance = Eigen::Matrix3f::Zero();
        for (const auto& point : cloud_pca_->points)
        {
            Vector3f pt(point.x, point.y, point.z);
            Vector3f diff = pt - centroid_vec;
            covariance += diff * diff.transpose();
        }
        covariance /= (cloud_pca_->size() - 1);
        
        Eigen::SelfAdjointEigenSolver<Eigen::Matrix3f> solver(covariance);
        Eigen::Vector3f eigen_values = solver.eigenvalues();
        Eigen::Matrix3f eigen_vectors = solver.eigenvectors();
        
        int max_idx = 0;
        float max_val = eigen_values(0);
        for (int i = 1; i < 3; i++)
        {
            if (eigen_values(i) > max_val)
            {
                max_val = eigen_values(i);
                max_idx = i;
            }
        }
        
        Vector3f new_axis = eigen_vectors.col(max_idx);
        
        if (new_axis.dot(smoothed_dir_) < 0)
            new_axis = -new_axis;
        
        tunnel_axis_ = 0.7 * tunnel_axis_ + 0.3 * new_axis;
        tunnel_axis_.normalize();
        
        ROS_DEBUG("PCA: points=%ld, axis=[%.2f, %.2f, %.2f]", 
                  cloud_pca_->size(), tunnel_axis_.x(), tunnel_axis_.y(), tunnel_axis_.z());
    }
    
    // ============ 核心函数1：真正的安全半径计算 ============
    float getTrueSafeRadius(const Vector3f& query, float max_radius = MAX_RADIUS)
    {
        if (cloud_filtered_->empty() || kdtree_->getInputCloud()->empty())
            return MIN_SAFE_RADIUS;
        
        pcl::PointXYZ q(query.x(), query.y(), query.z());
        
        std::vector<int> indices;
        std::vector<float> sqr_dist;
        
        float search_radius = max_radius + 10.0;
        if (kdtree_->radiusSearch(q, search_radius, indices, sqr_dist) == 0)
            return max_radius;
        
        float min_dist = max_radius;
        for (const auto& dist : sqr_dist)
        {
            float d = std::sqrt(dist);
            if (d < min_dist) min_dist = d;
        }
        
        float safe_radius = std::max(0.0f, min_dist - 0.3f);
        
        if (safe_radius < MIN_SAFE_RADIUS)
            return MIN_SAFE_RADIUS;
        
        return std::min(safe_radius, max_radius);
    }

    
    // ============ 核心函数2：多方向安全验证 ============
    bool isSphereReallySafe(const Vector3f& center, float radius)
    {
        if (cloud_filtered_->empty()) return false;
        
        pcl::PointXYZ q(center.x(), center.y(), center.z());
        
        std::vector<Vector3f> directions;
        
        for (int i = 0; i < SAFE_CHECK_POINTS; i++)
        {
            float phi = acos(1 - 2.0 * i / SAFE_CHECK_POINTS);
            float theta = M_PI * (1 + sqrt(5)) * i;
            
            Vector3f dir(sin(phi) * cos(theta),
                        sin(phi) * sin(theta),
                        cos(phi));
            directions.push_back(dir.normalized());
        }
        
        for (const auto& dir : directions)
        {
            Vector3f check_point = center + dir * radius;
            pcl::PointXYZ p(check_point.x(), check_point.y(), check_point.z());
            
            std::vector<int> indices(1);
            std::vector<float> sqr_dist(1);
            
            if (kdtree_->nearestKSearch(p, 1, indices, sqr_dist) > 0)
            {
                float dist_to_obs = std::sqrt(sqr_dist[0]);
                if (dist_to_obs < SAFE_CHECK_THRESHOLD)
                {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    // // ============ 核心函数3：高度约束 ============
    // Vector3f applyHeightConstraint(const Vector3f& candidate)
    // {
    //     Vector3f constrained = candidate;
        
    //     float safe_min_z = min_z_seen_ + GROUND_CLEARANCE;
    //     float safe_max_z = max_z_seen_ - CEILING_CLEARANCE;
        
    //     if (safe_min_z > safe_max_z - 0.3)
    //     {
    //         safe_min_z = current_pos_.z() - 1.0;
    //         safe_max_z = current_pos_.z() + 1.0;
    //     }
        
    //     if (constrained.z() < safe_min_z)
    //         constrained.z() = safe_min_z;
    //     if (constrained.z() > safe_max_z)
    //         constrained.z() = safe_max_z;
        
    //     return constrained;
    // }

    // ============ 改进的高度约束 ============
    Vector3f applyHeightConstraint(const Vector3f& candidate)
    {
        Vector3f constrained = candidate;
        
        // 基于点云统计的安全高度
        float safe_min_z = min_z_seen_ + GROUND_CLEARANCE;
        float safe_max_z = max_z_seen_ - CEILING_CLEARANCE;
        
        // 如果统计范围不合理，使用当前位置附近 ±1m
        if (safe_min_z > safe_max_z - 0.3)
        {
            safe_min_z = current_pos_.z() - 1.0;
            safe_max_z = current_pos_.z() + 1.0;
        }
        
        // 引入绝对上限，防止飞得太高
        if (safe_max_z > absolute_max_height_)
            safe_max_z = absolute_max_height_;
        
        // 应用约束
        if (constrained.z() < safe_min_z)
            constrained.z() = safe_min_z;
        if (constrained.z() > safe_max_z)
            constrained.z() = safe_max_z;
        
        return constrained;
    }
    
    // ============ 核心函数4：扇形采样 ============
    Vector3f generateByFanSampling(const Vector3f& start, 
                                   const Vector3f& direction, 
                                   float step = GOAL_STEP)
    {
        Vector3f dir = direction.normalized();
        
        Vector3f up = Vector3f(0, 0, 1);
        Vector3f right = dir.cross(up).normalized();
        Vector3f vertical = right.cross(dir).normalized();
        
        float horizontal_angles[] = HORIZONTAL_ANGLES;
        float vertical_angles[] = VERTICAL_ANGLES;
        
        Vector3f best_candidate = start + dir * step;
        float best_score = -1e6;
        
        for (float h_deg : horizontal_angles)
        {
            for (float v_deg : vertical_angles)
            {
                float h_rad = h_deg * M_PI / 180.0;
                Vector3f horizontal_rotated = dir * cos(h_rad) + right * sin(h_rad);
                
                float v_rad = v_deg * M_PI / 180.0;
                Vector3f ray_dir = horizontal_rotated * cos(v_rad) + vertical * sin(v_rad);
                ray_dir.normalize();
                
                for (float try_step = step; try_step >= 0.5f; try_step -= 0.5f)
                {
                    Vector3f candidate = start + ray_dir * try_step;
                    candidate = applyHeightConstraint(candidate);
                    
                    float radius = getTrueSafeRadius(candidate);
                    
                    if (radius >= MIN_SAFE_RADIUS && isSphereReallySafe(candidate, radius))
                    {
                        float dir_similarity = ray_dir.dot(dir);
                        float distance_score = try_step / step;
                        float radius_score = radius / MAX_RADIUS;
                        
                        float score = radius_score * 3.0 + dir_similarity * 2.0 + distance_score * 1.0;
                        
                        if (score > best_score)
                        {
                            best_score = score;
                            best_candidate = candidate;
                        }
                        
                        if (radius >= step * 0.8) break;
                    }
                }
            }
        }
        
        return best_candidate;
    }
    
    // ============ 核心函数5：历史轨迹平滑 ============
    Vector3f applySmoothConstraint(const Vector3f& candidate, 
                                   const Vector3f& direction,
                                   float step = GOAL_STEP)
    {
        if (history_centers_.empty())
        {
            return candidate;
        }
        
        Vector3f last_center = history_centers_.back();
        Vector3f delta = candidate - last_center;
        Vector3f forward_dir = direction.normalized();
        
        float forward_component = delta.dot(forward_dir);
        Vector3f lateral = delta - forward_component * forward_dir;
        float max_lateral = step * MAX_LATERAL_RATIO;
        
        if (lateral.norm() > max_lateral)
        {
            lateral = lateral.normalized() * max_lateral;
            delta = forward_component * forward_dir + lateral;
        }
        
        float max_step = step * 1.5;
        if (delta.norm() > max_step)
        {
            delta = delta.normalized() * max_step;
        }
        
        Vector3f smoothed_candidate = last_center + delta;
        
        float radius = getTrueSafeRadius(smoothed_candidate);
        if (radius < MIN_SAFE_RADIUS || !isSphereReallySafe(smoothed_candidate, radius))
        {
            return candidate;
        }
        
        return smoothed_candidate;
    }
    
    // ============ 核心函数6：横截面优化 ============
    Vector3f optimizeInCrossSection(const Vector3f& candidate, 
                                    const Vector3f& axis,
                                    float search_range = 1.2f)
    {
        Vector3f up = Vector3f(0, 0, 1);
        Vector3f right = axis.cross(up).normalized();
        Vector3f vertical = right.cross(axis).normalized();
        
        Vector3f best_center = candidate;
        float best_radius = getTrueSafeRadius(candidate);
        
        float step_size = 0.3f;
        
        for (float dx = -search_range; dx <= search_range; dx += step_size)
        {
            for (float dy = -search_range; dy <= search_range; dy += step_size)
            {
                Vector3f test_center = candidate + right * dx + vertical * dy;
                test_center = applyHeightConstraint(test_center);
                
                float radius = getTrueSafeRadius(test_center);
                
                if (radius >= MIN_SAFE_RADIUS && isSphereReallySafe(test_center, radius))
                {
                    float center_dist = sqrt(dx*dx + dy*dy);
                    float score = radius * 2.0 - center_dist * 0.5;
                    
                    if (score > best_radius)
                    {
                        best_radius = score;
                        best_center = test_center;
                    }
                }
            }
        }
        
        return best_center;
    }
    
    // ============ 核心函数7：球体优化 ============
    void optimizeFutureSpheres()
    {
        if (sphere_queue_.size() < 2) return;  // 至少需要一个未来球
        
        // 获取当前方向（用于生成新候选）
        Vector3f forward_dir;
        if (current_vel_.norm() > 0.2)
            forward_dir = smoothed_dir_;
        else
            forward_dir = Vector3f(1, 0, 0);
        
        // 从第二个球开始遍历（索引 1 到 size-1）
        for (size_t i = 1; i < sphere_queue_.size(); ++i)
        {
            SphereInfo& sphere = sphere_queue_[i];
            
            // 如果已经固定，跳过
            if (sphere.is_fixed) continue;
            
            // 以上一个球的中心为起点，沿当前方向生成新候选
            Vector3f prev_center = sphere_queue_[i-1].center;
            Vector3f new_candidate = generateUltimateSafeSphereCenter(prev_center, forward_dir, GOAL_STEP);
            
            // 计算新候选点的安全半径
            float new_radius = getTrueSafeRadius(new_candidate);
            
            // 评估是否需要更新
            float dist = (new_candidate - sphere.center).norm();
            float radius_improve = new_radius - sphere.radius;
            
            // 更新条件：位置变化明显且半径不降低，或者半径明显提升
            if ((dist > 0.3 && radius_improve > -0.1) || radius_improve > 0.2)
            {
                sphere.center = new_candidate;
                sphere.radius = new_radius;
                sphere.timestamp = ros::Time::now();
                sphere.optimize_count++;
                
                ROS_DEBUG("Optimized sphere %lu: dist=%.2f, radius_improve=%.2f", 
                        i, dist, radius_improve);
            }
            else
            {
                // 无显著变化，增加计数，若达到阈值则固定
                sphere.optimize_count++;
            }
            
            // 固定条件：优化超过一定次数且最近变化很小
            if (sphere.optimize_count >= 5 && dist < 0.2)
            {
                sphere.is_fixed = true;
                ROS_INFO("Sphere %lu fixed after %d optimizations", i, sphere.optimize_count);
            }
        }
    }

    // ============ 终极球心生成函数（整合所有方法）============
    Vector3f generateUltimateSafeSphereCenter(const Vector3f& start, 
                                              const Vector3f& direction, 
                                              float step = GOAL_STEP)
    {
        Vector3f best_candidate = start + direction.normalized() * (step * 0.5);
        float best_score = -1e6;
        
        Vector3f primary_dir = tunnel_axis_;
        if (primary_dir.norm() < 0.1)
            primary_dir = direction.normalized();
        
        for (float h_angle = -60; h_angle <= 60; h_angle += 15)
        {
            for (float v_angle = -30; v_angle <= 30; v_angle += 15)
            {
                Vector3f dir = primary_dir;
                Vector3f up(0,0,1);
                Vector3f right = dir.cross(up).normalized();
                Vector3f vertical = right.cross(dir).normalized();
                
                float h_rad = h_angle * M_PI / 180.0;
                float v_rad = v_angle * M_PI / 180.0;
                
                Vector3f horizontal_rotated = dir * cos(h_rad) + right * sin(h_rad);
                Vector3f sample_dir = horizontal_rotated * cos(v_rad) + vertical * sin(v_rad);
                sample_dir.normalize();
                
                for (float try_step = step; try_step >= 1.0; try_step -= 0.5)
                {
                    Vector3f candidate = start + sample_dir * try_step;
                    candidate = applyHeightConstraint(candidate);
                    
                    float radius = getTrueSafeRadius(candidate);
                    
                    if (radius >= MIN_SAFE_RADIUS && isSphereReallySafe(candidate, radius))
                    {
                        candidate = optimizeInCrossSection(candidate, primary_dir);
                        radius = getTrueSafeRadius(candidate);
                        
                        if (radius >= MIN_SAFE_RADIUS && isSphereReallySafe(candidate, radius))
                        {
                            float dir_similarity = sample_dir.dot(primary_dir);
                            float distance_score = try_step / step;
                            float radius_score = radius / MAX_RADIUS;
                            
                            float score = radius_score * 3.0 + dir_similarity * 2.0 + distance_score * 1.0;
                            
                            if (score > best_score)
                            {
                                best_score = score;
                                best_candidate = candidate;
                                break;
                            }
                        }
                    }
                }
            }
        }
        
        best_candidate = applySmoothConstraint(best_candidate, primary_dir, step);
        
        float final_radius = getTrueSafeRadius(best_candidate);
        if (final_radius < MIN_SAFE_RADIUS || !isSphereReallySafe(best_candidate, final_radius))
        {
            ROS_WARN("No safe sphere found, using conservative fallback");
            
            for (float try_step = 1.0; try_step <= step; try_step += 0.5)
            {
                Vector3f candidate = start + primary_dir * try_step;
                candidate = applyHeightConstraint(candidate);
                
                float r = getTrueSafeRadius(candidate);
                if (r >= MIN_SAFE_RADIUS && isSphereReallySafe(candidate, r))
                {
                    return candidate;
                }
            }
            
            return start + primary_dir * 1.0;
        }
        
        return best_candidate;
    }
    
    // ============ 更新目标点队列 ============
    void updateGoalQueue()
    {
        if (cloud_filtered_->empty()) return;
        
        Vector3f forward_dir;
        if (current_vel_.norm() > 0.2)
        {
            forward_dir = smoothed_dir_;
        }
        else
        {
            forward_dir = Vector3f(1, 0, 0);
        }
        
        if (sphere_queue_.empty())
        {
            Vector3f first_goal = generateUltimateSafeSphereCenter(current_pos_, forward_dir, GOAL_STEP);
            
            if ((first_goal - current_pos_).norm() < 1.5)
            {
                first_goal = current_pos_ + forward_dir * 2.0;
            }
            
            float radius = getTrueSafeRadius(first_goal);
            SphereInfo info = {first_goal, radius, true, ros::Time::now()};
            sphere_queue_.push_back(info);
            
            ROS_INFO("Initial sphere: [%.2f, %.2f, %.2f], radius: %.2f", 
                     first_goal.x(), first_goal.y(), first_goal.z(), radius);
        }
        
        while ((int)sphere_queue_.size() < QUEUE_SIZE)
        {
            Vector3f last_goal = sphere_queue_.back().center;
            Vector3f next_goal = generateUltimateSafeSphereCenter(last_goal, forward_dir, GOAL_STEP);
            
            if ((next_goal - last_goal).norm() < 0.5)
            {
                next_goal = last_goal + forward_dir * GOAL_STEP;
            }
            
            float radius = getTrueSafeRadius(next_goal);
            SphereInfo info = {next_goal, radius, false, ros::Time::now()};
            sphere_queue_.push_back(info);
            
            ROS_INFO("Added sphere %lu: [%.2f, %.2f, %.2f], radius: %.2f", 
                     sphere_queue_.size(), next_goal.x(), next_goal.y(), next_goal.z(), radius);
        }
    }
    
    // ============ 检查并切换目标点 ============
    void checkAndSwitchGoal()
    {
        if (sphere_queue_.empty()) return;
        
        Vector3f current_goal = sphere_queue_.front().center;
        float dist_to_goal = (current_pos_ - current_goal).norm();
        
        if (dist_to_goal < SWITCH_DIST)
        {
            sphere_queue_.pop_front();
            
            if (!sphere_queue_.empty())
            {
                sphere_queue_.front().is_current_goal = true;
            }
            
            ROS_INFO("Goal reached, switch to next. Distance: %.2f", dist_to_goal);
            
            if (sphere_queue_.empty())
            {
                updateGoalQueue();
            }
        }
    }
    
    // ============ 新增：发布最近障碍物可视化 ============
    void publishNearestObstacles()
    {
        if (sphere_queue_.empty() || cloud_filtered_->empty()) return;
        
        visualization_msgs::MarkerArray marker_array;
        int id = 200;  // 从200开始避免与其它Marker冲突
        
        for (const auto& sphere : sphere_queue_)
        {
            pcl::PointXYZ q(sphere.center.x(), sphere.center.y(), sphere.center.z());
            std::vector<int> indices(1);
            std::vector<float> sqr_dist(1);
            
            if (kdtree_->nearestKSearch(q, 1, indices, sqr_dist) > 0)
            {
                const auto& obs_point = cloud_filtered_->points[indices[0]];
                Vector3f obs_pos(obs_point.x, obs_point.y, obs_point.z);
                
                // 红色小球表示最近障碍物
                visualization_msgs::Marker sphere_marker;
                sphere_marker.header.frame_id = "world";
                sphere_marker.header.stamp = ros::Time::now();
                sphere_marker.ns = "nearest_obstacles";
                sphere_marker.id = id++;
                sphere_marker.type = visualization_msgs::Marker::SPHERE;
                sphere_marker.action = visualization_msgs::Marker::ADD;
                
                sphere_marker.pose.position.x = obs_pos.x();
                sphere_marker.pose.position.y = obs_pos.y();
                sphere_marker.pose.position.z = obs_pos.z();
                sphere_marker.pose.orientation.w = 1.0;
                
                sphere_marker.scale.x = 0.2;
                sphere_marker.scale.y = 0.2;
                sphere_marker.scale.z = 0.2;
                
                sphere_marker.color.r = 1.0;
                sphere_marker.color.g = 0.0;
                sphere_marker.color.b = 0.0;
                sphere_marker.color.a = 0.8;
                
                sphere_marker.lifetime = ros::Duration(0.5);
                marker_array.markers.push_back(sphere_marker);
                
                // 红色连线：球心 -> 最近障碍物
                visualization_msgs::Marker line_marker;
                line_marker.header.frame_id = "world";
                line_marker.header.stamp = ros::Time::now();
                line_marker.ns = "obstacle_lines";
                line_marker.id = id++;
                line_marker.type = visualization_msgs::Marker::LINE_STRIP;
                line_marker.action = visualization_msgs::Marker::ADD;
                
                line_marker.scale.x = 0.05;  // 线宽
                
                line_marker.color.r = 1.0;
                line_marker.color.g = 0.0;
                line_marker.color.b = 0.0;
                line_marker.color.a = 0.6;
                
                geometry_msgs::Point p1, p2;
                p1.x = sphere.center.x();
                p1.y = sphere.center.y();
                p1.z = sphere.center.z();
                p2.x = obs_pos.x();
                p2.y = obs_pos.y();
                p2.z = obs_pos.z();
                
                line_marker.points.push_back(p1);
                line_marker.points.push_back(p2);
                
                line_marker.lifetime = ros::Duration(0.5);
                marker_array.markers.push_back(line_marker);
            }
        }
        
        obstacle_pub_.publish(marker_array);
    }
    
    // ============ 发布隧道轴向可视化 ============
    void publishTunnelAxis()
    {
        visualization_msgs::Marker axis_marker;
        axis_marker.header.frame_id = "world";
        axis_marker.header.stamp = ros::Time::now();
        axis_marker.ns = "tunnel_axis";
        axis_marker.id = 0;
        axis_marker.type = visualization_msgs::Marker::ARROW;
        axis_marker.action = visualization_msgs::Marker::ADD;
        
        axis_marker.points.resize(2);
        axis_marker.points[0].x = current_pos_.x();
        axis_marker.points[0].y = current_pos_.y();
        axis_marker.points[0].z = current_pos_.z();
        
        Vector3f end = current_pos_ + tunnel_axis_ * 3.0;
        axis_marker.points[1].x = end.x();
        axis_marker.points[1].y = end.y();
        axis_marker.points[1].z = end.z();
        
        axis_marker.scale.x = 0.1;
        axis_marker.scale.y = 0.2;
        axis_marker.scale.z = 0.3;
        
        axis_marker.color.r = 1.0;
        axis_marker.color.g = 0.5;
        axis_marker.color.b = 0.0;
        axis_marker.color.a = 0.8;
        
        axis_marker.lifetime = ros::Duration(0.5);
        
        axis_pub_.publish(axis_marker);
    }
    
    // ============ 发布安全球体 ============
    void publishSafetySpheres()
    {
        if (sphere_queue_.empty()) return;
        
        visualization_msgs::MarkerArray marker_array;
        int id = 0;
        
        for (const auto& sphere : sphere_queue_)
        {
            visualization_msgs::Marker sphere_marker;
            sphere_marker.header.frame_id = "world";
            sphere_marker.header.stamp = ros::Time::now();
            sphere_marker.ns = "safety_spheres";
            sphere_marker.id = id++;
            sphere_marker.type = visualization_msgs::Marker::SPHERE;
            sphere_marker.action = visualization_msgs::Marker::ADD;
            
            sphere_marker.pose.position.x = sphere.center.x();
            sphere_marker.pose.position.y = sphere.center.y();
            sphere_marker.pose.position.z = sphere.center.z();
            sphere_marker.pose.orientation.w = 1.0;
            
            sphere_marker.scale.x = sphere.radius * 2.0;
            sphere_marker.scale.y = sphere.radius * 2.0;
            sphere_marker.scale.z = sphere.radius * 2.0;
            
            if (sphere.is_current_goal)
            {
                sphere_marker.color.r = 0.0;
                sphere_marker.color.g = 1.0;
                sphere_marker.color.b = 0.0;
                sphere_marker.color.a = 0.3;
            }
            else
            {
                sphere_marker.color.r = 0.0;
                sphere_marker.color.g = 0.0;
                sphere_marker.color.b = 1.0;
                sphere_marker.color.a = 0.2;
            }
            
            sphere_marker.lifetime = ros::Duration(0.5);
            marker_array.markers.push_back(sphere_marker);
            
            visualization_msgs::Marker border_marker;
            border_marker.header.frame_id = "world";
            border_marker.header.stamp = ros::Time::now();
            border_marker.ns = "sphere_borders";
            border_marker.id = id++;
            border_marker.type = visualization_msgs::Marker::SPHERE;
            border_marker.action = visualization_msgs::Marker::ADD;
            
            border_marker.pose.position.x = sphere.center.x();
            border_marker.pose.position.y = sphere.center.y();
            border_marker.pose.position.z = sphere.center.z();
            border_marker.pose.orientation.w = 1.0;
            
            border_marker.scale.x = sphere.radius * 2.0;
            border_marker.scale.y = sphere.radius * 2.0;
            border_marker.scale.z = sphere.radius * 2.0;
            
            border_marker.color.r = 1.0;
            border_marker.color.g = 1.0;
            border_marker.color.b = 1.0;
            border_marker.color.a = 0.1;
            
            border_marker.lifetime = ros::Duration(0.5);
            marker_array.markers.push_back(border_marker);
        }
        
        sphere_pub_.publish(marker_array);
    }
    
    // ============ 发布飞行走廊 ============
    void publishFlightCorridor()
    {
        if (sphere_queue_.size() < 2) return;
        
        visualization_msgs::Marker corridor_marker;
        corridor_marker.header.frame_id = "world";
        corridor_marker.header.stamp = ros::Time::now();
        corridor_marker.ns = "flight_corridor";
        corridor_marker.id = 0;
        corridor_marker.type = visualization_msgs::Marker::LINE_STRIP;
        corridor_marker.action = visualization_msgs::Marker::ADD;
        
        corridor_marker.scale.x = 0.1;
        
        corridor_marker.color.r = 1.0;
        corridor_marker.color.g = 1.0;
        corridor_marker.color.b = 0.0;
        corridor_marker.color.a = 0.8;
        
        corridor_marker.lifetime = ros::Duration(0.5);
        
        for (const auto& sphere : sphere_queue_)
        {
            geometry_msgs::Point p;
            p.x = sphere.center.x();
            p.y = sphere.center.y();
            p.z = sphere.center.z();
            corridor_marker.points.push_back(p);
        }
        
        corridor_pub_.publish(corridor_marker);
        
        nav_msgs::Path path_msg;
        path_msg.header.frame_id = "world";
        path_msg.header.stamp = ros::Time::now();
        
        for (const auto& sphere : sphere_queue_)
        {
            geometry_msgs::PoseStamped pose;
            pose.header = path_msg.header;
            pose.pose.position.x = sphere.center.x();
            pose.pose.position.y = sphere.center.y();
            pose.pose.position.z = sphere.center.z();
            pose.pose.orientation.w = 1.0;
            path_msg.poses.push_back(pose);
        }
        
        path_pub_.publish(path_msg);
    }
    
    // ============ 发布文字标签 ============
    void publishSphereLabels()
    {
        if (sphere_queue_.empty()) return;
        
        visualization_msgs::MarkerArray marker_array;
        int id = 100;
        
        int index = 0;
        for (const auto& sphere : sphere_queue_)
        {
            visualization_msgs::Marker text_marker;
            text_marker.header.frame_id = "world";
            text_marker.header.stamp = ros::Time::now();
            text_marker.ns = "sphere_labels";
            text_marker.id = id++;
            text_marker.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
            text_marker.action = visualization_msgs::Marker::ADD;
            
            text_marker.pose.position.x = sphere.center.x();
            text_marker.pose.position.y = sphere.center.y();
            text_marker.pose.position.z = sphere.center.z() + sphere.radius + 0.3;
            text_marker.pose.orientation.w = 1.0;
            
            if (sphere.is_current_goal)
            {
                text_marker.text = "Current\nR=" + std::to_string(sphere.radius).substr(0, 4) + "m";
            }
            else
            {
                text_marker.text = "S" + std::to_string(index) + "\nR=" + std::to_string(sphere.radius).substr(0, 4) + "m";
            }
            
            text_marker.scale.z = 0.3;
            
            text_marker.color.r = 1.0;
            text_marker.color.g = 1.0;
            text_marker.color.b = 1.0;
            text_marker.color.a = 1.0;
            
            text_marker.lifetime = ros::Duration(0.5);
            marker_array.markers.push_back(text_marker);
            
            index++;
        }
        
        text_pub_.publish(marker_array);
    }
    
    // ============ 新增：发布每个球心周围搜索半径内的所有点云 ============
    void publishSearchPoints()
    {
        if (sphere_queue_.empty() || cloud_filtered_->empty()) return;
        
        pcl::PointCloud<PointType>::Ptr all_search_points(new pcl::PointCloud<PointType>);
        
        for (const auto& sphere : sphere_queue_)
        {
            pcl::PointXYZ q(sphere.center.x(), sphere.center.y(), sphere.center.z());
            std::vector<int> indices;
            std::vector<float> sqr_dist;
            
            // 搜索半径设为球体半径 + 0.5m，以包含球体附近的点
            float search_radius = sphere.radius + 10.0;
            if (kdtree_->radiusSearch(q, search_radius, indices, sqr_dist) > 0)
            {
                for (int idx : indices)
                {
                    all_search_points->push_back(cloud_filtered_->points[idx]);
                }
            }
        }
        
        if (!all_search_points->empty())
        {
            sensor_msgs::PointCloud2 cloud_msg;
            pcl::toROSMsg(*all_search_points, cloud_msg);
            cloud_msg.header.frame_id = "world";
            cloud_msg.header.stamp = ros::Time::now();
            search_points_pub_.publish(cloud_msg);
        }
    }


    // ============ 计算偏航角 ============
    float computeYawFromDirection(const Vector3f& dir)
    {
        Vector3f dir_2d = dir;
        dir_2d.z() = 0;
        if (dir_2d.norm() < 0.1) return 0.0;
        dir_2d.normalize();
        return atan2(dir_2d.y(), dir_2d.x());
    }
    
    // ============ 从偏航角构造四元数 ============
    geometry_msgs::Quaternion quaternionFromYaw(float yaw)
    {
        tf2::Quaternion q;
        q.setRPY(0, 0, yaw);
        geometry_msgs::Quaternion q_msg;
        q_msg.w = q.w();
        q_msg.x = q.x();
        q_msg.y = q.y();
        q_msg.z = q.z();
        return q_msg;
    }
    
    // ============ 发布目标点 ============
    void publishCurrentGoal()
    {
        if (sphere_queue_.empty()) 
        {
            updateGoalQueue();
            if (sphere_queue_.empty()) return;
        }
        
        Vector3f current_goal = sphere_queue_.front().center;
        
        Vector3f flight_dir;
        if (current_vel_.norm() > 0.3)
        {
            flight_dir = current_vel_.normalized();
        }
        else
        {
            flight_dir = (current_goal - current_pos_).normalized();
        }
        
        geometry_msgs::PoseStamped goal_msg;
        goal_msg.header.stamp = ros::Time::now();
        goal_msg.header.frame_id = "world";
        goal_msg.pose.position.x = current_goal.x();
        goal_msg.pose.position.y = current_goal.y();
        goal_msg.pose.position.z = current_goal.z();
        
        float yaw = computeYawFromDirection(flight_dir);
        goal_msg.pose.orientation = quaternionFromYaw(yaw);
        
        goal_pub_.publish(goal_msg);
    }
    
    // ============ 定时器回调 ============
    void timerCallback(const ros::TimerEvent&)
    {
        if (pcl_cloud_global_->empty())
        {
            ROS_WARN_THROTTLE(1.0, "Waiting for point cloud...");
            return;
        }
        
        extractLocalCloud();      // 提取当前局部点云
        preprocessCloud();
        updateGoalQueue();
        optimizeFutureSpheres();    // 优化非当前目标球
        checkAndSwitchGoal();
        publishCurrentGoal();
        
        publishSafetySpheres();
        publishFlightCorridor();
        publishSphereLabels();
        publishTunnelAxis();
        publishNearestObstacles();  // 新增：发布最近障碍物可视化
        publishSearchPoints();  // 新增
    }
};

// ============ 主函数 ============
int main(int argc, char** argv)
{
    ros::init(argc, argv, "tunnel_goal_publisher");
    ros::NodeHandle nh;
    
    ROS_INFO("Starting Tunnel Goal Publisher with Multi-Method Fusion...");
    ROS_INFO("Subscribed to /Odometry, using world frame");
    ROS_INFO("Nearest obstacles visualization enabled");
    
    TunnelGoalPublisher node(nh);
    
    ros::spin();
    return 0;
}