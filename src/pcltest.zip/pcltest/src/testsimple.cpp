#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <sensor_msgs/PointCloud2.h>
#include <mutex>
#include <cmath>
#include <iostream>
#include <string>
#include <pcl/io/pcd_io.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <Eigen/Core>
#include <pcl/common/transforms.h>
#include <pcl/common/common.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/filters/voxel_grid.h>
#include <vector>
#include <Eigen/Geometry>
#include <pcl/kdtree/kdtree_flann.h>
#include <Eigen/Dense>
#include <pcl/filters/approximate_voxel_grid.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl_conversions/pcl_conversions.h>
#include "std_msgs/Float64.h"

typedef pcl::PointXYZ PointType;

#define VOLSIZE 0.2 //体素大小
#define FRONT_DISTANCE 0.2 //采x轴方向距离自己多远的点云重心
#define REPLAN_THRESH 0.5 //目标点间隔至少多远才能触发重规划
#define EXE_FINISH_DIST 0.2 //距离目标多远算执行完成
#define REPLAN_DURATION 5.0 //超过这个时间无论如何重新发布一个点
#define SEARCH_RADIUS 1.5  //大于LENGTH的一半会引发严重错误
#define MAX_ADJUST_DIS 0.5 //先验目标和后验目标的最大距离
#define LENGTH 2 //目标点距离自己多远

using namespace Eigen;
using namespace std;

bool pointWithin( Vector3f max_, Vector3f min_,const Vector3f& point,float inflate)
{
    Vector3f max = max_- Vector3f(1,1,1)*inflate;
    Vector3f min = min_+ Vector3f(1,1,1)*inflate;

    return (point.x()<=max.x()&&point.y()<=max.y()&&point.z()<=max.z()
        &&point.x()>=min.x()&&point.y()>=min.y()&&point.z()>=min.z());
        
}

class GoalPublisher
{
public:
	GoalPublisher(ros::NodeHandle& nh_)
	{
        lastPoint = Vector3f(0,0,0);
        lastCenter = Vector3f(0,0,0);
        finalPosition.pose.position.x = 0;
        pcl_cloud = pcl::PointCloud<pcl::PointXYZ>::Ptr(new pcl::PointCloud<PointType>);
        cloud_filtered = pcl::PointCloud<PointType>::Ptr (new pcl::PointCloud<PointType>());
        cloud_filtered2 = pcl::PointCloud<PointType>::Ptr (new pcl::PointCloud<PointType>());
        pass_filter.setFilterFieldName("x");  // 设置过滤字段为X
        pass_filter.setFilterLimits(FRONT_DISTANCE, FLT_MAX);  // 设置过滤范围为(0, +∞)
        pass_filter.setFilterLimitsNegative(false); 
        sor.setMeanK(100);           // 设置考虑的邻居数量
        sor.setStddevMulThresh(10); // 设置阈值倍数
        voxel_filter.setLeafSize(VOLSIZE, VOLSIZE, VOLSIZE);

		pose_sub_ = nh_.subscribe("/mavros/local_position/pose", 1, &GoalPublisher::poseCallback, this);
		goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1);
        goal_pub_2= nh_.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal0", 1);
        ext_dist_ = nh_.subscribe("/distance_landing_node/integrated_distance",1,&GoalPublisher::distCallback,this);
        ros::param::get("/distance_landing_node/distance_threshold",this->distance_limit_);
        ros::param::get("/distance_limit",this->distance_limit_);
		cloud = nh_.subscribe("/livox/points",1,&GoalPublisher::pointCloudCallback,this);
        timer_ = nh_.createTimer(ros::Duration(0.2), &GoalPublisher::timerCallback, this); // 5 Hz
        ROS_INFO("timer_created");
	}

private:
	ros::Subscriber pose_sub_;
	ros::Publisher goal_pub_;
    ros::Publisher goal_pub_2;
    ros::Subscriber ext_dist_;
	ros::Timer timer_;
    ros::Subscriber cloud;
	ros::ServiceClient takeoff_client_;

	geometry_msgs::PoseStamped current_pose_;
	geometry_msgs::Point home_position_;
	std::mutex pose_mutex_;


    pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud;
    pcl::VoxelGrid<PointType> voxel_filter;
    pcl::PointCloud<PointType>::Ptr cloud_filtered;
    pcl::PointCloud<PointType>::Ptr cloud_filtered2;
    pcl::PassThrough<pcl::PointXYZ> pass_filter;
    pcl::StatisticalOutlierRemoval<pcl::PointXYZ> sor;
    pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;


    pcl::PointXYZ min_point,max_point;
    Eigen::Vector3f pcaCenter;
    Eigen::Vector3f lastPoint,lastCenter;

    ros::Time updateTime;



	bool pose_received_ = false;
	bool goal_sent_to_home_ = false;
	bool initialized_ = false;
	bool landing_triggered_ = false;

	ros::Time start_time_;
	float total_distance_ = 0.0;
    float distance_limit_ = 0;
	geometry_msgs::PoseStamped finalPosition;

    geometry_msgs::Point last_position_;

    void distCallback(const std_msgs::Float64::ConstPtr& msg)
    {
        this->total_distance_ = msg->data;
    }
	
	void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg)
	{
		current_pose_.pose.position.x = (*msg).pose.position.x ;
		current_pose_.pose.position.y = (*msg).pose.position.y ;
		current_pose_.pose.position.z = (*msg).pose.position.z ;
        current_pose_.pose.orientation.w = (*msg).pose.orientation.w;
        current_pose_.pose.orientation.x = (*msg).pose.orientation.x;
        current_pose_.pose.orientation.y = (*msg).pose.orientation.y;
        current_pose_.pose.orientation.z = (*msg).pose.orientation.z;
		pose_received_ = true;

		if (!initialized_) {
			home_position_ = current_pose_.pose.position;
			last_position_ = current_pose_.pose.position;
			start_time_ = ros::Time::now();
			initialized_ = true;
			ROS_INFO("Home position set and tracking started.");
		}
	}
    void pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg) {
        pcl::fromROSMsg(*msg, *pcl_cloud);
    }
	
	void timerCallback(const ros::TimerEvent&)
	{
        geometry_msgs::PoseStamped last_pose_;
        if(this->pcl_cloud->empty())
        {
            ROS_INFO("NO PCL");
            return;
        }
        

        this->cloudFilter();
        this->cloudProcess();
        if(pcaCenter.norm()>LENGTH){
            pcaCenter = pcaCenter.normalized()*LENGTH;
        }
        
        this->gradAdjust();
        // this->pubPose(goal_pub_2,pcaCenter);
		this->pubPose(goal_pub_,pcaCenter);
	}

    void cloudFilter()
    {
        voxel_filter.setInputCloud(pcl_cloud);
        voxel_filter.filter(*cloud_filtered); //均匀化
        sor.setInputCloud(cloud_filtered);
        sor.filter(*cloud_filtered);    // 去掉离群点
    }

    void cloudProcess()
    {
        pass_filter.setInputCloud(cloud_filtered);
        pcl::getMinMax3D(*cloud_filtered, min_point, max_point);

        pass_filter.filter(*cloud_filtered2);
        Eigen::Vector4f pcaCentroid;
        pcl::compute3DCentroid(*cloud_filtered2, pcaCentroid);   
        pcaCenter = Eigen::Vector3f(pcaCentroid(0),pcaCentroid(1),pcaCentroid(2));

    }

    //以质心为先验目标点      梯度下降调整目标点位置    令目标点到其周围SEARCH_RADIUS半径内的点云点距离最远 使用指数形式目标
    void gradAdjust()
    {
        std::vector<int> pointIdxRadiusSearch;
        std::vector<float> pointRadiusSquaredDistance;
        kdtree.setInputCloud(cloud_filtered2);
        pcl::PointXYZ target_point(pcaCenter.x(), pcaCenter.y(), pcaCenter.z());
        pcl::PointCloud<pcl::PointXYZ>::Ptr localCloud(new pcl::PointCloud<pcl::PointXYZ>);

        auto dist = pcaCenter.norm();
        if (kdtree.radiusSearch(target_point, dist*0.7>SEARCH_RADIUS?SEARCH_RADIUS:dist*0.7, pointIdxRadiusSearch, pointRadiusSquaredDistance) > 0)
        {
            // 提取所有周围点
            for (size_t i = 0; i < pointIdxRadiusSearch.size(); ++i)
                localCloud->points.push_back(cloud_filtered2->points[pointIdxRadiusSearch[i]]);
        }
        else
            return;

        Eigen::Vector3f x = pcaCenter; // 初始目标点
        double sigma = 0.5;
        double eps = 0.1;
        double lr = 0.01; // 步长
        int max_iter = 100;

        for (int iter = 0; iter < max_iter; ++iter)
        {
            
            Eigen::Vector3f grad(0, 0, 0);
            for (const auto& p : localCloud->points)
            {
                Eigen::Vector3f p_i(p.x, p.y, p.z);
                Eigen::Vector3f diff = x - p_i;
                double dist2 = diff.squaredNorm();
                double weight = std::exp(-dist2 / (2.0 * sigma * sigma));
                grad += (diff / (sigma * sigma)) * weight;

            }
            x += lr * grad;
            if ((x - pcaCenter).norm() > SEARCH_RADIUS/2.0) break;
            
        }

        pcaCenter = x;
    }

    //通过向量算姿态
    Eigen::Quaternionf computeDir(Eigen::Vector3f dirVec)
    {
        dirVec.z() = 0;
        Eigen::Vector3f xb = dirVec.normalized();
        Eigen::Vector3f zb = Eigen::Vector3f(0,0,1);
        Eigen::Vector3f yb = zb.cross(xb).normalized();
        Eigen::Matrix3f RR;
        RR<<xb,yb,zb;
        return Eigen::Quaternionf(RR);
    }

    //把pcaTarget进行缩放，旋转和平移，到世界坐标系，然后发布
    void pubPose(const ros::Publisher& pub_,const Eigen::Vector3f& pcaTarget)
    {
        Eigen::Quaternionf q(
			current_pose_.pose.orientation.w,
			current_pose_.pose.orientation.x,
			current_pose_.pose.orientation.y,
			current_pose_.pose.orientation.z);

        Eigen::Vector3f pcaCenter2 = q*pcaTarget;

         //期望姿态是从自己指向目标点的向量
        Eigen::Vector3f dirVec = pcaTarget;
        Eigen::Quaternionf qtarget = q*computeDir(dirVec);
        Eigen::Vector3f posNow (current_pose_.pose.position.x,current_pose_.pose.position.y,current_pose_.pose.position.z);
        auto tempz = current_pose_.pose.position.z + pcaCenter2(2);
        // tempz = tempz>2.6?2.6:tempz;
        // tempz = tempz<2.2?2.2:tempz;
        // tempz = tempz>1.5?1.5:tempz;
        // tempz = tempz<1.3?1.3:tempz;
        tempz = tempz>1.3?1.3:tempz;
        tempz = tempz<1.2?1.2:tempz;
        tempz=1;
      


		geometry_msgs::PoseStamped goal;
		goal.header.stamp = ros::Time::now();
		goal.header.frame_id = "camera_init";
		goal.pose.position.x = current_pose_.pose.position.x + pcaCenter2(0);
		goal.pose.position.y = current_pose_.pose.position.y + pcaCenter2(1);
        goal.pose.position.z = tempz;
		
        goal.pose.orientation.w = qtarget.w();
        goal.pose.orientation.x = qtarget.x();
        goal.pose.orientation.y = qtarget.y();
        goal.pose.orientation.z = qtarget.z();
        auto tempPoint = Eigen::Vector3f(goal.pose.position.x,goal.pose.position.y,goal.pose.position.z);
        
		if( lastPoint.norm()==0                     //第一次进循环                                                                          
            ||goal.header.stamp-updateTime>ros::Duration(REPLAN_DURATION) //很长时间没更新了
            ||(lastPoint-posNow).norm()<EXE_FINISH_DIST
            ||(lastPoint-tempPoint).norm()>REPLAN_THRESH) //执行完成
            
        {

		    pub_.publish(goal);
            std::cout << goal.pose.position.x << "/" << goal.pose.position.y << "/" << goal.pose.position.z << " " << ros::Time::now() << std::endl;
            lastPoint = tempPoint;
            updateTime = ros::Time::now();
        }
    }

    void pubtest(const ros::Publisher& pub_,Eigen::Vector3f pcaTarget)
    {
        if(pub_.getTopic()=="/move_base_simple/goal")
        {
            ROS_WARN("this is no test bro!");
            return ;
        }
        Eigen::Quaternionf q(
			current_pose_.pose.orientation.w,
			current_pose_.pose.orientation.x,
			current_pose_.pose.orientation.y,
			current_pose_.pose.orientation.z);

        Eigen::Vector3f pcaCenter2 = q*pcaTarget;

         //期望姿态是从自己指向目标点的向量
        Eigen::Vector3f dirVec = pcaTarget;
        Eigen::Quaternionf qtarget = q*computeDir(dirVec);
        
		geometry_msgs::PoseStamped goal;
		goal.header.stamp = ros::Time::now();
		goal.header.frame_id = "camera_init";
		goal.pose.position.x = current_pose_.pose.position.x + pcaCenter2(0);
		goal.pose.position.y = current_pose_.pose.position.y + pcaCenter2(1);
		goal.pose.position.z = current_pose_.pose.position.z + pcaCenter2(2);
        goal.pose.orientation.w = qtarget.w();
        goal.pose.orientation.x = qtarget.x();
        goal.pose.orientation.y = qtarget.y();
        goal.pose.orientation.z = qtarget.z();
		pub_.publish(goal);
    }

};

int main(int argc, char** argv)
{
	ros::init(argc, argv, "goal_publisher_node");
    ros::NodeHandle _nh;
    ROS_INFO("program on");
	GoalPublisher node(_nh);
	ros::spin();
	return 0;
}
