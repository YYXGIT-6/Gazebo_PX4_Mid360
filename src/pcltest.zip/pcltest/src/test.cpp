#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <sensor_msgs/PointCloud2.h>
#include <mutex>
#include <cmath>
#include <iostream>
#include <string>
#include <pcl/io/pcd_io.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <Eigen/Core>
#include <pcl/common/transforms.h>
#include <pcl/common/common.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/filters/voxel_grid.h>
#include <vector>
#include <Eigen/Geometry>
#include <pcl/kdtree/kdtree_flann.h>
#include <Eigen/Dense>
#include <pcl/filters/approximate_voxel_grid.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl_conversions/pcl_conversions.h>

typedef pcl::PointXYZ PointType;

#define VOLSIZE 0.2 //体素大小
#define INFLATION 0.3 //bounding box缩小量
#define RADIUS 2 //每个探索点搜索半径
#define ANGLE_STEP 0.1 //横向探索点角度步长
#define SEARCH_HEIGHT 1 //探索点分布总高度
#define POINT_W 6 //多少个横向探索点
#define POINT_H 4 //多少个纵向探索点
#define SEARCH_DIS 4 //探索点与飞机距离
#define SELECT_N 5 //第一步留下多少个探索点
#define FRONT_DISTANCE 0.2 //采前面多远部分的点云重心
#define REPLAN_THRESH 1.0 //目标点距离多远才能触发重规划
#define REPLAN_THRESH_MAX 4.0 //目标点间隔最大多远能触发重规划
#define REPLAN_DURATION 5.0

using namespace Eigen;
using namespace std;

void sort_a_by_b(vector<Vector3f>& endpoints,vector<float>& scores)
{
    std::vector<std::pair<float, Vector3f>> combined;
    combined.reserve(scores.size());
    for (size_t i = 0; i < scores.size(); ++i) {
        combined.emplace_back(scores[i], endpoints[i]);
    }
    std::sort(combined.begin(), combined.end(), 
            [](const auto& a, const auto& b) { return a.first > b.first; });
    for (size_t i = 0; i < combined.size(); ++i) {
        scores[i] = combined[i].first;
        endpoints[i] = combined[i].second;
    }
}

bool pointWithin( Vector3f max_, Vector3f min_,const Vector3f& point,float inflate)
{
    Vector3f max = max_- Vector3f(1,1,1)*inflate;
    Vector3f min = min_+ Vector3f(1,1,1)*inflate;

    return (point.x()<=max.x()&&point.y()<=max.y()&&point.z()<=max.z()
        &&point.x()>=min.x()&&point.y()>=min.y()&&point.z()>=min.z());
        
}

class GoalPublisher
{
public:
	GoalPublisher()
	{
        selected = Vector3f(0,0,0);
        lastPoint = Vector3f(0,0,0);
        pcl_cloud = pcl::PointCloud<pcl::PointXYZ>::Ptr(new pcl::PointCloud<PointType>);
        cloud_filtered = pcl::PointCloud<PointType>::Ptr (new pcl::PointCloud<PointType>());
        pass_filter.setFilterFieldName("x");  // 设置过滤字段为X
        pass_filter.setFilterLimits(FRONT_DISTANCE, FLT_MAX);  // 设置过滤范围为(0, +∞)
        pass_filter.setFilterLimitsNegative(false); 
        sor.setMeanK(100);           // 设置考虑的邻居数量
        sor.setStddevMulThresh(10); // 设置阈值倍数
        voxel_filter.setLeafSize(VOLSIZE, VOLSIZE, VOLSIZE);

		pose_sub_ = nh_.subscribe("/mavros/local_position/odom", 1, &GoalPublisher::poseCallback, this);
		goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/ego_planner_node/move_base_simple/goal", 1);
		cloud = nh_.subscribe("/livox/lidar",1,&GoalPublisher::pointCloudCallback,this);
        timer_ = nh_.createTimer(ros::Duration(1), &GoalPublisher::timerCallback, this); // 20 Hz
	}

private:
	ros::NodeHandle nh_;
	ros::Subscriber pose_sub_;
	ros::Publisher goal_pub_;
	ros::Timer timer_;
    ros::Subscriber cloud;
	ros::ServiceClient takeoff_client_;

	geometry_msgs::PoseStamped current_pose_;
	geometry_msgs::Point home_position_;
	std::mutex pose_mutex_;

    pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud;
    pcl::VoxelGrid<PointType> voxel_filter;
    pcl::PointCloud<PointType>::Ptr cloud_filtered;
    pcl::PassThrough<pcl::PointXYZ> pass_filter;
    pcl::StatisticalOutlierRemoval<pcl::PointXYZ> sor;
    pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;

    pcl::PointXYZ min_point,max_point;
    Eigen::Vector3f selected;
    Eigen::Vector3f pcaCenter;
    Eigen::Vector3f lastPoint;
    ros::Time updateTime;



	bool pose_received_ = false;
	bool goal_sent_to_home_ = false;
	bool initialized_ = false;
	bool landing_triggered_ = false;

	ros::Time start_time_;
	double total_distance_ = 0.0;
	geometry_msgs::Point last_position_;
	
	void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg)
	{
		current_pose_ = *msg;
		pose_received_ = true;

		if (!initialized_) {
			home_position_ = current_pose_.pose.position;
			last_position_ = current_pose_.pose.position;
			start_time_ = ros::Time::now();
			initialized_ = true;
			ROS_INFO("Home position set and tracking started.");
		}
	}
    void pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg) {
        pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::fromROSMsg(*msg, *pcl_cloud);
    }
	
	void timerCallback(const ros::TimerEvent&)
	{
		if (!pose_received_ || !initialized_) return;
        if(this->pcl_cloud->empty())return;

        this->cloudFilter();
        this->cloudProcess();

		// 点云重心
		Eigen::Quaternionf q(
			current_pose_.pose.orientation.w,
			current_pose_.pose.orientation.x,
			current_pose_.pose.orientation.y,
			current_pose_.pose.orientation.z);

        // 探索点
        Eigen::Vector3f selected = q*selected;
        
		geometry_msgs::PoseStamped goal;
		goal.header.stamp = ros::Time::now();
		goal.header.frame_id = "map";
		goal.pose.position.x = current_pose_.pose.position.x + selected(0);
		goal.pose.position.y = current_pose_.pose.position.y + selected(1);
		goal.pose.position.z = current_pose_.pose.position.z + selected(2);
		goal.pose = current_pose_.pose;
        
        auto tempPoint = Eigen::Vector3f(goal.pose.position.x,goal.pose.position.y,goal.pose.position.z);
        if(((tempPoint-lastPoint).norm()>REPLAN_THRESH
            &&(tempPoint-lastPoint).norm()<REPLAN_THRESH_MAX)
            ||lastPoint.norm()==0||goal.header.stamp-updateTime>ros::Duration(REPLAN_DURATION))
        {
		    goal_pub_.publish(goal);
            lastPoint = tempPoint;
            updateTime = ros::Time::now();
        }
	}

    //点云过滤操作，得到cloud_filtered
    void cloudFilter()
    {
        voxel_filter.setInputCloud(pcl_cloud);
        voxel_filter.filter(*cloud_filtered); //均匀化
        sor.setInputCloud(cloud_filtered);
        sor.filter(*cloud_filtered);    // 去掉离群点
        kdtree.setInputCloud(cloud_filtered);
        pcl::getMinMax3D(*cloud_filtered, min_point, max_point);
    }

    //点云计算操作，得到pcaCenter重心、selected探索点
    void cloudProcess()
    {
        pcl::PointCloud<PointType>::Ptr cloud_filtered2(new pcl::PointCloud<PointType>());
        pass_filter.setInputCloud(cloud_filtered);
        pass_filter.filter(*cloud_filtered2);
        Eigen::Vector4f pcaCentroid;
        pcl::compute3DCentroid(*cloud_filtered2, pcaCentroid);   
        pcaCenter = Eigen::Vector3f(pcaCentroid(0),pcaCentroid(1),pcaCentroid(2));

        vector<Vector3f> endpoints,endpoints1;
        Eigen::Vector3f pcaCenter;
        vector<float> scores;
        int index;
        Quaternionf q(1, 0, 0, 0); 
        Vector3f pos(0, 0, 0);     
        endpoints = generateFrontRays(pos, q, POINT_W,POINT_H,SEARCH_DIS,ANGLE_STEP,SEARCH_HEIGHT);

        float interDisMean=0;
        float minDis=9999;


        //两米内附近点距离平均值最大
        for(int i=0;i<endpoints.size();i++)
        {
            if(pointWithin(Vector3f(max_point.x,max_point.y,max_point.z),
            Vector3f(min_point.x,min_point.y,min_point.z),endpoints[i],INFLATION))
                interDisMean = pointNearCloud(endpoints[i],RADIUS);
            else
                interDisMean = 0;
            scores.push_back(interDisMean);
            interDisMean=0;
        }
        sort_a_by_b(endpoints,scores);

        //平均值最大的n个点，选距裁减后点云重心最近的，剔除不在点云bounding box内的点
        //如果全都不在bounding box内就去整个点云的重心上
        for(int i=0;i<SELECT_N>endpoints.size()?endpoints.size():SELECT_N;i++)
        {
            interDisMean = (endpoints[i]-pcaCenter).norm();
            if(interDisMean<minDis)
            {
                minDis = interDisMean;
                selected = endpoints[i];
                index = i;
            }
        }
        if(scores[index]==0)
        {
            pcl::compute3DCentroid(*cloud_filtered, pcaCentroid);   
            selected = Vector3f(pcaCentroid(0),pcaCentroid(1),pcaCentroid(2));
        }
    }

    std::vector<Vector3f> generateFrontRays(const Vector3f& pos, 
                                       const Quaternionf& q, 
                                       int Lnum_lines = 6, 
                                       int Hnum_lines = 5,
                                       double length = 4,
                                       double widthAngle = 0.1,
                                       double height = 1) {
        std::vector<Vector3f> endpoints;
        double y=0,z=0,yAng=0;
        
        for(int i =0 ;i<Hnum_lines;i++)
        {

            for(int qq=0;qq<Lnum_lines;qq++)
            {

                y = tan(yAng)*length;
                endpoints.push_back(Vector3f(2,y,z).normalized()*length+pos);
                if(y!=0&&z!=0)
                    endpoints.push_back(Vector3f(2,-y,-z).normalized()*length+pos);
                if(y!=0)
                    endpoints.push_back(Vector3f(2,-y,z).normalized()*length+pos);
                if(z!=0)
                    endpoints.push_back(Vector3f(2,y,-z).normalized()*length+pos);
                yAng += widthAngle;
            }
            z+=height/Hnum_lines;
            yAng=0;
        }


        return endpoints;
    }

    float pointNearCloud(
        const Vector3f& base,
        float max_distance
    ){
        std::vector<int> point_indices;
        std::vector<float> point_distances;
        kdtree.radiusSearch(
                pcl::PointXYZ(base.x(), base.y(), base.z()),
                max_distance,  
                point_indices,
                point_distances);
        if(point_distances.empty())
            return max_distance;
        
        float sum = std::accumulate(point_distances.begin(),point_distances.end(),0.0f);
        float mean = sum/point_distances.size();
        return mean;
        
    }



};

int main(int argc, char** argv)
{
	ros::init(argc, argv, "goal_publisher_node");
	GoalPublisher node;
	ros::spin();
	return 0;
}