#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/TwistStamped.h>
#include <sensor_msgs/PointCloud2.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <nav_msgs/Path.h>  // 添加这个头文件！
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <mutex>
#include <cmath>
#include <iostream>
#include <string>
#include <deque>
#include <pcl/io/pcd_io.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/common/transforms.h>
#include <pcl/common/common.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl_conversions/pcl_conversions.h>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include <Eigen/Dense>
#include <nav_msgs/Odometry.h>

typedef pcl::PointXYZ PointType;

// ============ 可调参数 ============
#define VOXEL_SIZE 0.2
#define MIN_SAFE_RADIUS 0.6
#define GOAL_STEP 2.5
#define QUEUE_SIZE 3
#define SWITCH_DIST 1.0
#define SEARCH_HORIZON 6.0
#define MAX_RADIUS 5.0
#define REPLAN_INTERVAL 0.2
#define SPEED_SMOOTH_FACTOR 0.3
// ================================

using namespace Eigen;
using namespace std;

struct SphereInfo
{
    Vector3f center;
    float radius;
    bool is_current_goal;
    ros::Time timestamp;
};

class TunnelGoalPublisher
{
public:
    TunnelGoalPublisher(ros::NodeHandle& nh_)
    {
        // ============ 初始化 ============
        current_pos_ = Vector3f(0, 0, 0);
        current_vel_ = Vector3f(1, 0, 0);
        smoothed_dir_ = Vector3f(1, 0, 0);
        
        // ============ PCL对象初始化 ============
        pcl_cloud_.reset(new pcl::PointCloud<PointType>);
        cloud_filtered_.reset(new pcl::PointCloud<PointType>);
        cloud_downsampled_.reset(new pcl::PointCloud<PointType>);
        kdtree_.reset(new pcl::KdTreeFLANN<PointType>);
        
        // 滤波器设置
        voxel_filter_.setLeafSize(VOXEL_SIZE, VOXEL_SIZE, VOXEL_SIZE);
        
        pass_filter_.setFilterFieldName("x");
        pass_filter_.setFilterLimits(0.5, SEARCH_HORIZON);
        pass_filter_.setFilterLimitsNegative(false);
        
        pass_filter_y_.setFilterFieldName("y");
        pass_filter_y_.setFilterLimits(-4.0, 4.0);
        pass_filter_y_.setFilterLimitsNegative(false);
        
        pass_filter_z_.setFilterFieldName("z");
        pass_filter_z_.setFilterLimits(-1.0, 3.0);
        pass_filter_z_.setFilterLimitsNegative(false);
        
        sor_.setMeanK(50);
        sor_.setStddevMulThresh(3.0);
        
        // ============ ROS通信初始化 ============
        // pose_sub_ = nh_.subscribe("/mavros/local_position/pose", 1, 
        //                           &TunnelGoalPublisher::poseCallback, this);
        pose_sub_ = nh_.subscribe("/Odometry", 1, 
                            &TunnelGoalPublisher::poseCallback, this);
        vel_sub_ = nh_.subscribe("/mavros/local_position/velocity_local", 1,
                                 &TunnelGoalPublisher::velocityCallback, this);
        cloud_sub_ = nh_.subscribe("/cloud_registered", 1,
                                   &TunnelGoalPublisher::pointCloudCallback, this);
        
        goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1);
        
        // ============ 可视化Publisher ============
        sphere_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/visualization/safety_spheres", 1);
        corridor_pub_ = nh_.advertise<visualization_msgs::Marker>("/visualization/flight_corridor", 1);
        text_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/visualization/sphere_labels", 1);
        path_pub_ = nh_.advertise<nav_msgs::Path>("/visualization/center_path", 1); 
        
        timer_ = nh_.createTimer(ros::Duration(REPLAN_INTERVAL), 
                                 &TunnelGoalPublisher::timerCallback, this);
        
        ROS_INFO("Tunnel Goal Publisher with Visualization Initialized");
    }

private:
    // ============ ROS通信成员 ============
    ros::Subscriber pose_sub_;
    ros::Subscriber vel_sub_;
    ros::Subscriber cloud_sub_;
    ros::Publisher goal_pub_;
    ros::Timer timer_;
    
    // ============ 可视化Publisher ============
    ros::Publisher sphere_pub_;
    ros::Publisher corridor_pub_;
    ros::Publisher text_pub_;
    ros::Publisher path_pub_;
    
    // ============ 状态变量 ============
    Vector3f current_pos_;
    Vector3f current_vel_;
    Vector3f smoothed_dir_;
    std::deque<SphereInfo> sphere_queue_;
    ros::Time last_cloud_time_;
    
    // ============ PCL相关 ============
    pcl::PointCloud<PointType>::Ptr pcl_cloud_;
    pcl::PointCloud<PointType>::Ptr cloud_filtered_;
    pcl::PointCloud<PointType>::Ptr cloud_downsampled_;
    pcl::KdTreeFLANN<PointType>::Ptr kdtree_;
    
    // ============ 滤波器 ============
    pcl::VoxelGrid<PointType> voxel_filter_;
    pcl::PassThrough<PointType> pass_filter_;
    pcl::PassThrough<PointType> pass_filter_y_;
    pcl::PassThrough<PointType> pass_filter_z_;
    pcl::StatisticalOutlierRemoval<PointType> sor_;

    // ============ 回调函数 ============
    // void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg)
    // {
    //     current_pos_ = Vector3f(msg->pose.position.x,
    //                             msg->pose.position.y,
    //                             msg->pose.position.z);
    // }
    void poseCallback(const nav_msgs::Odometry::ConstPtr& msg)
    {
        // 从Odometry消息的pose.pose中提取位置（和原PoseStamped的pose结构一致）
        current_pos_ = Vector3f(msg->pose.pose.position.x,
                                msg->pose.pose.position.y,
                                msg->pose.pose.position.z);
    }
    
    void velocityCallback(const geometry_msgs::TwistStamped::ConstPtr& msg)
    {
        Vector3f raw_vel(msg->twist.linear.x,
                         msg->twist.linear.y,
                         msg->twist.linear.z);
        
        if (raw_vel.norm() > 0.1)
        {
            current_vel_ = raw_vel;
            smoothed_dir_ = SPEED_SMOOTH_FACTOR * raw_vel.normalized() + 
                          (1 - SPEED_SMOOTH_FACTOR) * smoothed_dir_;
            smoothed_dir_.normalize();
        }
    }
    
    void pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg)
    {
        pcl::fromROSMsg(*msg, *pcl_cloud_);
        last_cloud_time_ = ros::Time::now();
    }
    
    // ============ 点云预处理 ============
    void preprocessCloud()
    {
        if (pcl_cloud_->empty()) return;
        
        cloud_downsampled_->clear();
        voxel_filter_.setInputCloud(pcl_cloud_);
        voxel_filter_.filter(*cloud_downsampled_);
        
        cloud_filtered_->clear();
        sor_.setInputCloud(cloud_downsampled_);
        sor_.filter(*cloud_filtered_);
        
        pass_filter_.setInputCloud(cloud_filtered_);
        pass_filter_.filter(*cloud_filtered_);
        
        pass_filter_y_.setInputCloud(cloud_filtered_);
        pass_filter_y_.filter(*cloud_filtered_);
        
        pass_filter_z_.setInputCloud(cloud_filtered_);
        pass_filter_z_.filter(*cloud_filtered_);
        
        if (!cloud_filtered_->empty())
        {
            kdtree_->setInputCloud(cloud_filtered_);
        }
    }
    
    // ============ 核心函数1：获取局部最大安全半径 ============
    float getSafeRadius(const Vector3f& query, float max_radius = MAX_RADIUS)
    {
        if (cloud_filtered_->empty() || kdtree_->getInputCloud()->empty())
            return MIN_SAFE_RADIUS;
        
        pcl::PointXYZ q(query.x(), query.y(), query.z());
        std::vector<int> indices(1);
        std::vector<float> sqr_dist(1);
        
        if (kdtree_->nearestKSearch(q, 1, indices, sqr_dist) > 0)
        {
            float dist = std::sqrt(sqr_dist[0]);
            dist = std::max(0.0f, dist - 0.3f);
            return std::min(dist, max_radius);
        }
        return MIN_SAFE_RADIUS;
    }
    
    // ============ 核心函数2：生成下一个球心 ============
    // Vector3f generateNextSphereCenter(const Vector3f& start, 
    //                                   const Vector3f& direction, 
    //                                   float step = GOAL_STEP)
    // {
    //     Vector3f dir = direction.normalized();
    //     Vector3f candidate;
    //     float radius = 0.0f;
        
    //     for (float try_step = step; try_step >= 0.5f; try_step -= 0.5f)
    //     {
    //         candidate = start + dir * try_step;
    //         radius = getSafeRadius(candidate);
            
    //         if (radius >= MIN_SAFE_RADIUS)
    //         {
    //             break;
    //         }
    //     }
        
    //     candidate = optimizeSphereCenter(candidate, dir);
    //     return candidate;
    // }

    // ============ 改进版：扇形采样生成球心 ============
    Vector3f generateNextSphereCenter(const Vector3f& start, 
                                    const Vector3f& direction, 
                                    float step = GOAL_STEP)
    {
        Vector3f dir = direction.normalized();
        
        // 构建垂直平面内的基向量
        Vector3f up = Vector3f(0, 0, 1);
        Vector3f right = dir.cross(up).normalized();
        Vector3f vertical = right.cross(dir).normalized();
        
        // 扇形采样参数
        float horizontal_angles[] = {-30, -20, -10, 0, 10, 20, 30}; // 水平偏角（度）
        float vertical_angles[] = {-15, -10, -5, 0, 5, 10, 15};     // 垂直偏角（度）
        
        Vector3f best_candidate;
        float best_score = -1e6;
        float best_radius = 0;
        
        // 转换为弧度
        for (float h_deg : horizontal_angles)
        {
            for (float v_deg : vertical_angles)
            {
                // 1. 先水平旋转
                float h_rad = h_deg * M_PI / 180.0;
                Vector3f horizontal_rotated = dir * cos(h_rad) + right * sin(h_rad);
                
                // 2. 再垂直旋转
                float v_rad = v_deg * M_PI / 180.0;
                Vector3f ray_dir = horizontal_rotated * cos(v_rad) + vertical * sin(v_rad);
                ray_dir.normalize();
                
                // 沿该方向采样
                for (float try_step = step; try_step >= 1.0f; try_step -= 0.5f)
                {
                    Vector3f candidate = start + ray_dir * try_step;
                    float radius = getSafeRadius(candidate);
                    
                    // 评分：半径大 + 方向接近原方向 + 距离适中
                    float dir_similarity = ray_dir.dot(dir);  // 越接近原方向越好
                    float distance_score = try_step / step;   // 越远越好（但要在安全范围内）
                    float score = radius * 2.0 + dir_similarity * 1.5 + distance_score * 0.5;
                    
                    if (score > best_score && radius >= MIN_SAFE_RADIUS)
                    {
                        best_score = score;
                        best_candidate = candidate;
                        best_radius = radius;
                    }
                    
                    // 找到足够好的点就跳出内层循环
                    if (radius >= step * 0.8) break;
                }
            }
        }
        
        // 如果没有找到任何有效点，回退策略
        if (best_score < 0)
        {
            ROS_WARN("No valid sphere found, using fallback strategy");
            return start + dir * (MIN_SAFE_RADIUS * 1.5);
        }
        
        return best_candidate;
    }
    
    // ============ 核心函数3：优化球心位置 ============
    Vector3f optimizeSphereCenter(const Vector3f& init_center, const Vector3f& forward_dir)
    {
        Vector3f best_center = init_center;
        float best_radius = getSafeRadius(init_center);
        
        Vector3f up = Vector3f(0, 0, 1);
        Vector3f right = forward_dir.cross(up).normalized();
        Vector3f vertical = right.cross(forward_dir).normalized();
        
        float search_range = 0.8f;
        float step = 0.3f;
        
        for (float dx = -search_range; dx <= search_range; dx += step)
        {
            for (float dy = -search_range; dy <= search_range; dy += step)
            {
                Vector3f candidate = init_center + right * dx + vertical * dy;
                float radius = getSafeRadius(candidate);
                float forward_bias = (candidate - current_pos_).dot(forward_dir) * 0.2f;
                float score = radius + forward_bias;
                
                if (score > best_radius)
                {
                    best_radius = radius;
                    best_center = candidate;
                }
            }
        }
        
        return best_center;
    }
    
    // ============ 核心函数4：更新目标点队列和球信息 ============
    void updateGoalQueue()
    {
        if (cloud_filtered_->empty()) return;
        
        Vector3f forward_dir;
        if (current_vel_.norm() > 0.2)
        {
            forward_dir = smoothed_dir_;
        }
        else
        {
            forward_dir = Vector3f(1, 0, 0);
        }
        
        // 队列为空：初始化
        if (sphere_queue_.empty())
        {
            Vector3f first_goal = generateNextSphereCenter(current_pos_, forward_dir, GOAL_STEP);
            
            if ((first_goal - current_pos_).norm() < 1.5)
            {
                first_goal = current_pos_ + forward_dir * 2.0;
            }
            
            float radius = getSafeRadius(first_goal);
            SphereInfo info = {first_goal, radius, true, ros::Time::now()};
            sphere_queue_.push_back(info);
            
            ROS_INFO("Initial sphere: [%.2f, %.2f, %.2f], radius: %.2f", 
                     first_goal.x(), first_goal.y(), first_goal.z(), radius);
        }
        
        // 补充满队列
        while ((int)sphere_queue_.size() < QUEUE_SIZE)
        {
            Vector3f last_goal = sphere_queue_.back().center;
            Vector3f next_goal = generateNextSphereCenter(last_goal, forward_dir, GOAL_STEP);
            
            if ((next_goal - last_goal).norm() < 0.5)
            {
                next_goal = last_goal + forward_dir * GOAL_STEP;
            }
            
            float radius = getSafeRadius(next_goal);
            SphereInfo info = {next_goal, radius, false, ros::Time::now()};
            sphere_queue_.push_back(info);
            
            ROS_INFO("Added sphere %lu: [%.2f, %.2f, %.2f], radius: %.2f", 
                     sphere_queue_.size(), next_goal.x(), next_goal.y(), next_goal.z(), radius);
        }
    }
    
    // ============ 检查并切换目标点 ============
    void checkAndSwitchGoal()
    {
        if (sphere_queue_.empty()) return;
        
        Vector3f current_goal = sphere_queue_.front().center;
        float dist_to_goal = (current_pos_ - current_goal).norm();
        ROS_INFO("Distance between goal and current_pos: %.2f", dist_to_goal);

        
        if (dist_to_goal < SWITCH_DIST)
        {
            sphere_queue_.pop_front();
            
            // 更新新的队首为当前目标
            if (!sphere_queue_.empty())
            {
                sphere_queue_.front().is_current_goal = true;
            }
            
            ROS_INFO("Goal reached, switch to next. Distance: %.2f", dist_to_goal);
            
            if (sphere_queue_.empty())
            {
                updateGoalQueue();
            }
        }
    }
    
    // ============ 可视化函数1：发布安全球体 ============
    void publishSafetySpheres()
    {
        if (sphere_queue_.empty()) return;
        
        visualization_msgs::MarkerArray marker_array;
        int id = 0;
        
        for (const auto& sphere : sphere_queue_)
        {
            // 球体标记
            visualization_msgs::Marker sphere_marker;
            sphere_marker.header.frame_id = "world";
            sphere_marker.header.stamp = ros::Time::now();
            sphere_marker.ns = "safety_spheres";
            sphere_marker.id = id++;
            sphere_marker.type = visualization_msgs::Marker::SPHERE;
            sphere_marker.action = visualization_msgs::Marker::ADD;
            
            sphere_marker.pose.position.x = sphere.center.x();
            sphere_marker.pose.position.y = sphere.center.y();
            sphere_marker.pose.position.z = sphere.center.z();
            sphere_marker.pose.orientation.w = 1.0;
            
            sphere_marker.scale.x = sphere.radius * 2.0;
            sphere_marker.scale.y = sphere.radius * 2.0;
            sphere_marker.scale.z = sphere.radius * 2.0;
            
            // 颜色设置：当前目标为绿色，其他为蓝色
            if (sphere.is_current_goal)
            {
                sphere_marker.color.r = 0.0;
                sphere_marker.color.g = 1.0;
                sphere_marker.color.b = 0.0;
                sphere_marker.color.a = 0.3;
            }
            else
            {
                sphere_marker.color.r = 0.0;
                sphere_marker.color.g = 0.0;
                sphere_marker.color.b = 1.0;
                sphere_marker.color.a = 0.2;
            }
            
            sphere_marker.lifetime = ros::Duration(0.5);
            marker_array.markers.push_back(sphere_marker);
            
            // 球体边框
            visualization_msgs::Marker border_marker;
            border_marker.header.frame_id = "world";
            border_marker.header.stamp = ros::Time::now();
            border_marker.ns = "sphere_borders";
            border_marker.id = id++;
            border_marker.type = visualization_msgs::Marker::SPHERE;
            border_marker.action = visualization_msgs::Marker::ADD;
            
            border_marker.pose.position.x = sphere.center.x();
            border_marker.pose.position.y = sphere.center.y();
            border_marker.pose.position.z = sphere.center.z();
            border_marker.pose.orientation.w = 1.0;
            
            border_marker.scale.x = sphere.radius * 2.0;
            border_marker.scale.y = sphere.radius * 2.0;
            border_marker.scale.z = sphere.radius * 2.0;
            
            border_marker.color.r = 1.0;
            border_marker.color.g = 1.0;
            border_marker.color.b = 1.0;
            border_marker.color.a = 0.1;
            
            border_marker.lifetime = ros::Duration(0.5);
            marker_array.markers.push_back(border_marker);
        }
        
        sphere_pub_.publish(marker_array);
    }
    
    // ============ 可视化函数2：发布飞行走廊 ============
    void publishFlightCorridor()
    {
        if (sphere_queue_.size() < 2) return;
        
        visualization_msgs::Marker corridor_marker;
        corridor_marker.header.frame_id = "world";
        corridor_marker.header.stamp = ros::Time::now();
        corridor_marker.ns = "flight_corridor";
        corridor_marker.id = 0;
        corridor_marker.type = visualization_msgs::Marker::LINE_STRIP;
        corridor_marker.action = visualization_msgs::Marker::ADD;
        
        corridor_marker.scale.x = 0.1;
        
        corridor_marker.color.r = 1.0;
        corridor_marker.color.g = 1.0;
        corridor_marker.color.b = 0.0;
        corridor_marker.color.a = 0.8;
        
        corridor_marker.lifetime = ros::Duration(0.5);
        
        for (const auto& sphere : sphere_queue_)
        {
            geometry_msgs::Point p;
            p.x = sphere.center.x();
            p.y = sphere.center.y();
            p.z = sphere.center.z();
            corridor_marker.points.push_back(p);
        }
        
        corridor_pub_.publish(corridor_marker);
        
        // ============ 修复：使用nav_msgs/Path ============
        nav_msgs::Path path_msg;
        path_msg.header.frame_id = "world";
        path_msg.header.stamp = ros::Time::now();
        
        for (const auto& sphere : sphere_queue_)
        {
            geometry_msgs::PoseStamped pose;
            pose.header = path_msg.header;
            pose.pose.position.x = sphere.center.x();
            pose.pose.position.y = sphere.center.y();
            pose.pose.position.z = sphere.center.z();
            pose.pose.orientation.w = 1.0;
            path_msg.poses.push_back(pose);
        }
        
        path_pub_.publish(path_msg);
    }
    
    // ============ 可视化函数3：发布文字标签 ============
    void publishSphereLabels()
    {
        if (sphere_queue_.empty()) return;
        
        visualization_msgs::MarkerArray marker_array;
        int id = 100;
        
        int index = 0;
        for (const auto& sphere : sphere_queue_)
        {
            visualization_msgs::Marker text_marker;
            text_marker.header.frame_id = "world";
            text_marker.header.stamp = ros::Time::now();
            text_marker.ns = "sphere_labels";
            text_marker.id = id++;
            text_marker.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
            text_marker.action = visualization_msgs::Marker::ADD;
            
            text_marker.pose.position.x = sphere.center.x();
            text_marker.pose.position.y = sphere.center.y();
            text_marker.pose.position.z = sphere.center.z() + sphere.radius + 0.3;
            text_marker.pose.orientation.w = 1.0;
            
            if (sphere.is_current_goal)
            {
                text_marker.text = "Current Target\nR=" + std::to_string(sphere.radius).substr(0, 4) + "m";
            }
            else
            {
                text_marker.text = "Sphere " + std::to_string(index) + "\nR=" + std::to_string(sphere.radius).substr(0, 4) + "m";
            }
            
            text_marker.scale.z = 0.3;
            
            text_marker.color.r = 1.0;
            text_marker.color.g = 1.0;
            text_marker.color.b = 1.0;
            text_marker.color.a = 1.0;
            
            text_marker.lifetime = ros::Duration(0.5);
            marker_array.markers.push_back(text_marker);
            
            index++;
        }
        
        text_pub_.publish(marker_array);
    }
    
    // ============ 计算偏航角 ============
    float computeYawFromDirection(const Vector3f& dir)
    {
        Vector3f dir_2d = dir;
        dir_2d.z() = 0;
        if (dir_2d.norm() < 0.1) return 0.0;
        dir_2d.normalize();
        return atan2(dir_2d.y(), dir_2d.x());
    }
    
    // ============ 从偏航角构造四元数 ============
    geometry_msgs::Quaternion quaternionFromYaw(float yaw)
    {
        tf2::Quaternion q;
        q.setRPY(0, 0, yaw);
        geometry_msgs::Quaternion q_msg;
        q_msg.w = q.w();
        q_msg.x = q.x();
        q_msg.y = q.y();
        q_msg.z = q.z();
        return q_msg;
    }
    
    // ============ 发布目标点 ============
    void publishCurrentGoal()
    {
        if (sphere_queue_.empty()) 
        {
            updateGoalQueue();
            if (sphere_queue_.empty()) return;
        }
        
        Vector3f current_goal = sphere_queue_.front().center;
        
        Vector3f flight_dir;
        if (current_vel_.norm() > 0.3)
        {
            flight_dir = current_vel_.normalized();
        }
        else
        {
            flight_dir = (current_goal - current_pos_).normalized();
        }
        
        geometry_msgs::PoseStamped goal_msg;
        goal_msg.header.stamp = ros::Time::now();
        goal_msg.header.frame_id = "world";
        goal_msg.pose.position.x = current_goal.x();
        goal_msg.pose.position.y = current_goal.y();
        goal_msg.pose.position.z = current_goal.z();
        
        float yaw = computeYawFromDirection(flight_dir);
        goal_msg.pose.orientation = quaternionFromYaw(yaw);
        
        goal_pub_.publish(goal_msg);
    }
    
    // ============ 定时器回调 ============
    void timerCallback(const ros::TimerEvent&)
    {
        if (pcl_cloud_->empty())
        {
            ROS_WARN_THROTTLE(1.0, "Waiting for point cloud...");
            return;
        }
        
        preprocessCloud();
        updateGoalQueue();
        checkAndSwitchGoal();
        publishCurrentGoal();
        
        // ============ 发布所有可视化 ============
        publishSafetySpheres();
        publishFlightCorridor();
        publishSphereLabels();
    }
};

// ============ 主函数 ============
int main(int argc, char** argv)
{
    ros::init(argc, argv, "tunnel_goal_publisher");
    ros::NodeHandle nh;
    
    ROS_INFO("Starting Tunnel Goal Publisher with Visualization...");
    TunnelGoalPublisher node(nh);
    
    ros::spin();
    return 0;
}