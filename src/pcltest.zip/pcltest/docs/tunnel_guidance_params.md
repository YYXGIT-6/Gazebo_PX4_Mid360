# Tunnel Guidance 2.2.3 参数说明

本文档对应 `src/test_guidance2.2.3.cpp` 中的 `goal_publisher_node` 参数。当前代码优先读取新的分组参数名，同时兼容旧的扁平参数名。

## 点云层级

当前版本为了避免参数混乱，建议按下面的点云层级理解：

1. `local_submap_`
   - 内部滑动点云缓存，保存最近一段时间的世界系点云。
   - 不直接做 PCA、墙面或高度估计。

2. `local_map_tunnel`
   - 从 `local_submap_` 中按稳定隧道 yaw 转到隧道局部坐标后裁剪出来。
   - 由 `tunnel/local_map/*` 控制范围。
   - RViz 中 `/tunnel/local_submap_cloud` 显示的是这一级点云转回世界系后的结果。

3. `structure_cloud`
   - 从 `local_map_tunnel` 里进一步裁剪出的结构估计点云。
   - 由 `tunnel/structure/*` 控制范围。
   - 用于墙面估计、中心线估计，并作为 PCA 的上游输入。

4. `pca_direction_points`
   - 从 `structure_cloud` 里再次筛选出的左右侧墙 PCA 方向估计点。
   - 由 `tunnel/pca/*` 控制。
   - RViz 中 `/tunnel/pca_direction_points` 显示的就是实际参与 PCA 的点。

5. `height_cloud`
   - 高度估计不走 `structure_cloud`，而是直接使用 `local_map_tunnel`。
   - 由 `tunnel/height/*` 在 `local_map_tunnel` 内再次筛选地面/顶部候选点。

所以关键关系是：

```text
local_submap_
  -> local_map_tunnel          tunnel/local_map/*
      -> structure_cloud       tunnel/structure/*
          -> pca_direction_points  tunnel/pca/*
      -> height candidates     tunnel/height/*
```

## 参数命名规则

所有新参数都位于 `tunnel/<group>/<name>`：

- `tunnel/mode/*`：运行模式。
- `tunnel/control/*`：最终目标点、限幅、平滑、高度目标。
- `tunnel/debug_frame_structure/*`：当前帧结构裁剪，只用于 debug/备用。
- `tunnel/local_map/*`：滑动局部地图转到隧道坐标后的大范围裁剪。
- `tunnel/structure/*`：墙面、中心线、PCA 上游结构点云。
- `tunnel/pca/*`：真正参与 PCA 方向估计的点筛选和置信度。
- `tunnel/yaw/*`：稳定隧道轴向 yaw 的更新策略。
- `tunnel/height/*`：最终 z 控制使用的地面/顶部估计。

旧参数名仍然兼容。如果同时设置新旧参数，新参数优先。

## mode 参数

| 参数 | 默认值 | 作用 |
| --- | ---: | --- |
| `tunnel/mode/use_structure_goal` | `true` | 是否允许使用结构中心线目标点。 |
| `tunnel/mode/debug_only` | `false` | 只发布 debug 信息，不真正发布控制目标。 |
| `tunnel/mode/goal_mode` | `SUBMAP_ONLY` | 目标点模式。当前推荐 `SUBMAP_ONLY`，主输入来自局部子地图。 |

## control 参数

这些参数直接影响最终发布给无人机的目标点。

| 参数 | 默认值 | 作用 |
| --- | ---: | --- |
| `tunnel/control/lookahead_distance` | `2.0` | 目标点前视距离。 |
| `tunnel/control/max_lateral_correction` | `0.8` | 横向 y 修正最大幅度。 |
| `tunnel/control/lateral_confidence_threshold` | `0.75` | 使用横向结构目标所需的置信度门限。 |
| `tunnel/control/height_confidence_threshold` | `0.6` | 高度估计参与 z 控制所需的置信度门限。 |
| `tunnel/control/direction_confidence_threshold` | `0.6` | 方向估计参与目标选择所需的置信度门限。 |
| `tunnel/control/goal_smooth_alpha` | `0.8` | 目标点平滑系数，越大越保守。 |
| `tunnel/control/max_y_step` | `0.12` | 单次横向目标变化最大步长。 |
| `tunnel/control/max_goal_step` | `0.35` | 单次目标点整体变化最大步长。 |
| `tunnel/control/desired_relative_height` | `1.5` | 期望距离地面的相对高度。 |
| `tunnel/control/desired_ceiling_clearance` | `0.6` | 期望顶部净空，避免离顶部过近。 |
| `tunnel/control/max_height_step` | `1.0` | 目标点 z 相对机体的最大变化。 |
| `tunnel/control/use_world_z_guard` | `false` | 是否启用世界系 z 上下限保护。 |
| `tunnel/control/min_goal_z` | `0.8` | 世界系目标 z 下限，仅在 `use_world_z_guard=true` 时生效。 |
| `tunnel/control/max_goal_z` | `1.8` | 世界系目标 z 上限，仅在 `use_world_z_guard=true` 时生效。 |
| `tunnel/control/structure_goal_hold_time_sec` | `2.0` | 结构目标暂时失效时，保持上一结构目标的时间。 |

调参建议：

- 无人机左右晃动明显：适当增大 `goal_smooth_alpha`，或减小 `max_y_step`。
- 横向纠偏太慢：适当增大 `max_y_step` 或 `max_lateral_correction`。
- 高度跳变明显：减小 `max_height_step`，或增大 `height/smooth_alpha`。

## debug_frame_structure 参数

这组参数只影响当前帧结构裁剪，不是 `SUBMAP_ONLY` 下的主控制输入。它主要用于和局部子地图估计做对照。

| 参数 | 默认值 | 作用 |
| --- | ---: | --- |
| `tunnel/debug_frame_structure/x_min` | `0.2` | 当前帧结构裁剪 x 最小值。 |
| `tunnel/debug_frame_structure/x_max` | `5.0` | 当前帧结构裁剪 x 最大值。 |
| `tunnel/debug_frame_structure/y_abs_max` | `3.0` | 当前帧结构裁剪左右宽度。 |
| `tunnel/debug_frame_structure/z_abs_max` | `2.0` | 当前帧结构裁剪上下高度。 |

如果当前运行 `goal_mode=SUBMAP_ONLY`，一般不需要优先调这组。

## local_map 参数

这组参数控制 `local_map_tunnel` 的范围。它是结构估计和高度估计共同的上游点云。

| 参数 | 默认值 | 作用 |
| --- | ---: | --- |
| `tunnel/local_map/time_window_sec` | `7.0` | 滑动子地图保留最近多少秒点云。 |
| `tunnel/local_map/back_distance` | `3.0` | 隧道坐标下保留机体后方距离。 |
| `tunnel/local_map/front_distance` | `8.0` | 隧道坐标下保留机体前方距离。 |
| `tunnel/local_map/side_distance` | `10.0` | 隧道坐标下左右保留范围。 |
| `tunnel/local_map/z_distance` | `8.0` | 隧道坐标下上下保留范围。 |
| `tunnel/local_map/voxel_size` | `0.15` | 局部地图降采样体素大小。 |
| `tunnel/local_map/max_points` | `60000` | 局部地图最大点数。 |
| `tunnel/local_map/publish_cloud` | `true` | 是否发布 `/tunnel/local_submap_cloud`。 |
| `tunnel/local_map/cloud_frame_id` | 空 | 本地子地图显示 frame。为空时默认使用代码内设置。 |

调参建议：

- 点云太稀或结构估计不稳定：适当增大 `time_window_sec` 或减小 `voxel_size`。
- 延迟变大、CPU 压力大：减小 `time_window_sec`、`front_distance`、`side_distance` 或增大 `voxel_size`。
- 隧道很宽时：`side_distance` 要大于实际半宽，否则墙面点会被提前裁掉。

## structure 参数

这组参数决定从 `local_map_tunnel` 中取哪些点作为结构估计输入。墙面、中心线和 PCA 的上游都受它影响。

| 参数 | 默认值 | 作用 |
| --- | ---: | --- |
| `tunnel/structure/x_min` | `-1.0` | 结构估计使用的 x 最小值。 |
| `tunnel/structure/x_max` | `8.0` | 结构估计使用的 x 最大值。 |
| `tunnel/structure/y_abs_max` | `5.0` | 结构估计左右最大范围。 |
| `tunnel/structure/z_abs_max` | `2.0` | 结构估计上下最大范围。 |
| `tunnel/structure/wall_min_y` | `0.4` | 墙面点最小横向距离，过滤靠近中心的点。 |
| `tunnel/structure/min_wall_points` | `80` | 左右墙粗估计所需最小点数。 |
| `tunnel/structure/nominal_tunnel_width` | `2.4` | 名义隧道宽度，墙面缺失时用于兜底。 |
| `tunnel/structure/tunnel_wall_clearance` | `0.35` | 与墙面保持的安全距离。 |
| `tunnel/structure/centerline_bin_start_x` | `0.5` | 中心线分段统计起始 x。 |
| `tunnel/structure/centerline_bin_end_x` | `5.0` | 中心线分段统计结束 x。 |
| `tunnel/structure/centerline_bin_size_x` | `0.5` | 中心线 x 分段长度。 |
| `tunnel/structure/min_points_per_side` | `20` | 每个 x 分段内单侧墙所需最小点数。 |
| `tunnel/structure/max_width_change` | `0.5` | 相邻/历史宽度允许变化量。 |
| `tunnel/structure/max_center_jump` | `0.4` | 中心线 y 允许跳变量。 |
| `tunnel/structure/centerline_hold_time_sec` | `2.5` | 中心线失效时保持历史结果的时间。 |
| `tunnel/structure/centerline_reliable_confidence_threshold` | `0.6` | 判定中心线可靠的置信度门限。 |
| `tunnel/structure/centerline_min_reliable_points` | `3` | 判定中心线可靠所需的最小中心线点数。 |
| `tunnel/structure/ground_candidate_ratio` | `0.2` | 粗略结构高度 debug 中取底部候选点比例。 |
| `tunnel/structure/min_ground_points` | `60` | 粗略地面 debug 所需最小点数。 |
| `tunnel/structure/ceiling_candidate_ratio` | `0.2` | 粗略结构高度 debug 中取顶部候选点比例。 |
| `tunnel/structure/min_ceiling_points` | `60` | 粗略顶部 debug 所需最小点数。 |

注意：

- `structure/x_min` 到 `structure/z_abs_max` 会影响墙面、中心线和 PCA 上游点云。
- 但是最终高度控制不使用 `structure/ground_*` 或 `structure/ceiling_*`，最终高度控制使用 `height/*`。
- 如果墙面经常估计失败，优先检查 `structure/y_abs_max` 是否覆盖到墙，以及 `wall_min_y` 是否太大。

## pca 参数

这组参数决定真正用于 XY PCA 主轴估计的点。2.2.3 中 PCA 不再把左右侧墙点混在一起整体估计，而是左墙单独 PCA、右墙单独 PCA，然后根据每侧的置信度和点数支持进行融合。当前推荐 `use_wall_only=true`，也就是只用侧墙点，不用顶部/底部和中间杂点。

| 参数 | 默认值 | 作用 |
| --- | ---: | --- |
| `tunnel/pca/direction_smooth_alpha` | `0.8` | PCA/中心线融合方向的平滑系数。 |
| `tunnel/pca/min_direction_points` | `120` | 左右墙方向融合时用于计算点数支持的参考点数。 |
| `tunnel/pca/min_anisotropy` | `1.8` | PCA 主方向各向异性门限，越大越严格。 |
| `tunnel/pca/use_wall_only` | `true` | 是否只用侧墙点做 PCA。 |
| `tunnel/pca/min_wall_points` | `60` | 单侧墙独立 PCA 所需最小点数。 |
| `tunnel/pca/wall_min_y` | `0.8` | PCA 点必须距离中心线的最小横向距离。 |
| `tunnel/pca/z_min` | `-1.0` | PCA 点 z 下限。 |
| `tunnel/pca/z_max` | `1.8` | PCA 点 z 上限。 |

PCA 实际用点条件：

```text
先通过 tunnel/structure/* 得到 structure_cloud
再分成左墙和右墙：
  左墙: y >= pca/wall_min_y
  右墙: y <= -pca/wall_min_y
并且两侧点都需要满足：
  pca/z_min <= z <= pca/z_max
  单侧点数 >= pca/min_wall_points
  anisotropy >= pca/min_anisotropy

左墙和右墙都会各自得到一个 PCA 方向。
如果两侧都可靠，先对齐方向符号，再按置信度和点数支持融合。
如果只有一侧可靠，会降低置信度后使用单侧方向。
```

调参建议：

- `/tunnel/pca_direction_points` 太少：减小 `pca/wall_min_y`，放宽 `pca/z_min/z_max`，或增大 `structure/y_abs_max`。
- 单侧墙能看到但 PCA 仍失效：适当降低 `pca/min_wall_points`。
- PCA 方向跳动：增大 `pca/min_anisotropy` 或 `pca/direction_smooth_alpha`。
- 一侧墙点很多、另一侧很少导致方向偏：尽量让 `local_map/side_distance` 和 `structure/y_abs_max` 覆盖两侧墙；必要时提高 `pca/min_wall_points`，让单侧结果更谨慎。
- 隧道很宽：适当增大 `structure/y_abs_max` 和 `local_map/side_distance`，否则侧墙点进不来。
- 顶部/底部干扰方向：保持 `pca/use_wall_only=true`，并收紧 `pca/z_min/z_max`。

## yaw 参数

这组参数控制稳定隧道轴向 yaw 的更新。它的目的不是直接跟随无人机 yaw，而是用结构/PCA 方向逐步修正隧道延伸方向。

| 参数 | 默认值 | 作用 |
| --- | ---: | --- |
| `tunnel/yaw/smooth_alpha` | `0.88` | 隧道 yaw 平滑系数，越大越稳定但响应越慢。 |
| `tunnel/yaw/max_update_deg` | `20.0` | 单次正常更新允许的最大 yaw 改变量。 |
| `tunnel/yaw/force_update_deg` | `45.0` | 偏差特别大时强制更新门限。 |
| `tunnel/yaw/min_confidence` | `0.35` | 用于更新 yaw 的方向估计最低置信度。 |
| `tunnel/yaw/hold_time_sec` | `4.0` | 方向估计失效时保持历史 yaw 的时间。 |

调参建议：

- 轴向容易被错误点云带偏：增大 `smooth_alpha`，减小 `max_update_deg`，增大 `min_confidence`。
- 弯道或方向变化跟随太慢：减小 `smooth_alpha`，适当增大 `max_update_deg`。

## height 参数

这组参数控制最终 z 方向高度估计。它直接使用 `local_map_tunnel`，不依赖 `structure_cloud`。

| 参数 | 默认值 | 作用 |
| --- | ---: | --- |
| `tunnel/height/x_min` | `-3.0` | 高度估计使用的 x 最小值。 |
| `tunnel/height/x_max` | `8.0` | 高度估计使用的 x 最大值。 |
| `tunnel/height/x_bin_size` | `0.5` | 沿 x 分段统计的 bin 大小。 |
| `tunnel/height/center_y_abs` | `2.0` | 高度估计使用的中心区域半宽。 |
| `tunnel/height/z_abs_max` | `8.0` | 高度估计允许的上下范围。 |
| `tunnel/height/min_ground_points` | `40` | 地面平面拟合所需最小点数。 |
| `tunnel/height/min_ceiling_points` | `40` | 顶部平面拟合所需最小点数。 |
| `tunnel/height/min_valid_bins` | `3` | 至少需要多少个有效 x 分段。 |
| `tunnel/height/ground_low_ratio` | `0.20` | 每个 bin 中取最低一部分点作为地面候选。 |
| `tunnel/height/ceiling_high_ratio` | `0.20` | 每个 bin 中取最高一部分点作为顶部候选。 |
| `tunnel/height/smooth_alpha` | `0.85` | 地面/顶部高度平滑系数。 |
| `tunnel/height/hold_time_sec` | `3.0` | 近期高度估计的高置信保持时间。超时后仍保持历史高度，但置信度降低。 |
| `tunnel/height/max_abs_slope` | `0.35` | 地面/顶部平面允许的最大坡度。 |

高度失效策略：

- 如果当前帧高度估计成功，更新历史高度。
- 如果当前帧高度估计失败，但历史高度存在，继续使用历史高度。
- 历史高度超过 `height/hold_time_sec` 后不会立刻丢弃，只是以更低置信度使用。
- 不再 fallback 到 `TunnelStructureEstimator` 的粗略 ground/ceiling。

调参建议：

- 顶部/底部经常估计不出来：增大 `height/z_abs_max`，适当增大 `height/center_y_abs`，降低 `min_ground_points/min_ceiling_points`。
- 高度被侧墙或杂点污染：减小 `height/center_y_abs`，增大 `min_valid_bins`，或减小 `ground_low_ratio/ceiling_high_ratio`。
- 地面有坡度或隧道起伏：适当增大 `height/max_abs_slope`。

## 旧参数兼容表

| 新参数前缀 | 旧参数示例 |
| --- | --- |
| `tunnel/mode/*` | `tunnel/use_structure_goal`, `tunnel/debug_only`, `tunnel/goal_mode` |
| `tunnel/control/*` | `tunnel/lookahead_distance`, `tunnel/max_y_step`, `tunnel/desired_relative_height` |
| `tunnel/debug_frame_structure/*` | `tunnel/struct_x_min`, `tunnel/struct_y_abs_max` |
| `tunnel/structure/*` | `tunnel/submap_xy_x_min`, `tunnel/wall_min_y`, `tunnel/centerline_bin_start_x` |
| `tunnel/pca/*` | `tunnel/pca_use_wall_only`, `tunnel/pca_min_wall_points`, `tunnel/pca_wall_min_y`, `tunnel/direction_pca_min_anisotropy` |
| `tunnel/yaw/*` | `tunnel/tunnel_yaw_smooth_alpha`, `tunnel/tunnel_yaw_min_confidence` |
| `tunnel/local_map/*` | `tunnel/local_map_time_window_sec`, `tunnel/local_map_side_distance` |
| `tunnel/height/*` | `tunnel/height_x_min`, `tunnel/height_center_y_abs`, `tunnel/height_hold_time_sec` |

## 推荐优先调参顺序

1. 先看 `/tunnel/local_submap_cloud`，确认 `local_map/*` 范围足够覆盖隧道结构。
2. 再看结构估计是否稳定，调 `structure/x_min/x_max/y_abs_max/z_abs_max`。
3. 再看 `/tunnel/pca_direction_points`，调 `pca/wall_min_y/z_min/z_max/min_wall_points`。
4. 如果方向箭头稳定但无人机修正太激进，调 `yaw/*` 和 `control/*`。
5. 最后单独看 `/tunnel/ground_ceiling_marker` 和 `/tunnel/height_state`，调 `height/*`。
